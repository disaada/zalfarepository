<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_donatur extends CI_Model {

	public function GetDonatur(){
        $query=$this->db->query("SELECT * FROM t_donatur");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_donatur');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_donatur',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_donatur',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_donatur');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_donatur',$data);
    }
}
