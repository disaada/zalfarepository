<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_komentar_detail extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_komentar');
		$key = $this->uri->segment(4);
		$getquerytable			= $this->m_komentar->GetKomentarDetail($key);
   		$judul      			= $this->m_komentar->GetJudulArtikel($key);
   		//$getartikeltable		= $this->m_komentar->Getartikel($key);
		$isi['content'] 		= 'website/v_komentar_detail';
		$isi['back_link'] 		= 'website/c_komentar';
		$isi['base_link'] 		= 'website/c_komentar_detail/index/'.$key.'';
		$isi['judul'] 			= 'Komentar';
		$isi['sub_judul'] 		= 'Detail Komentar';
		$isi['data'] 			= $getquerytable;
		$isi['id']  			= $key;
		$isi['judul_artikel']	= $judul;
		//$isi['data_artikel']	= $getartikeltable;
		$this->load->view('v_home',$isi);
	}
	public function tambah_data()
	{
		$this->m_squrity->getsqurity();
		date_default_timezone_set("Asia/Jakarta");
        $tanggal = date('Y-m-d');  
        $jam = date("h:i:s a");  
		$data['id_artikel']		= $this->input->post('id_artikel');
		$data['komentar']		= $this->input->post('komentar');
		$data['nama']			= 'Admin';
		$data['email']			= 'kontak.muqtahfidz@gmail.com';
		$data['status']			= 'diterima';
		$data['tanggal']		= $tanggal;
		$data['jam']			= $jam;
		$id 					= $this->input->post('id_artikel');

		$this->load->model('website/m_komentar');
		$this->m_komentar->GetInsert($data);
		$this->session->set_flashdata('info','tambah');
		redirect('website/c_komentar_detail/index/'.$id.'');
	}

	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key 					= $this->input->post('id');
		$data['nama_kelompok']	= $this->input->post('nama_kelompok');
		$data['id_pementor']	= $this->input->post('id_pementor');
		$id_kampus 				= $this->input->post('id_kampus');

		$this->load->model('m_kelompok');
		$this->m_kelompok->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('c_kelompok_detail/index/'.$id_kampus.'');		
	}

	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data['status'] 	= $this->uri->segment(4);
		$id 				= $this->uri->segment(6);

		$this->load->model('website/m_komentar');
		$this->m_komentar->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_komentar_detail/index/'.$id.'');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_komentar');

		$key 		= $this->uri->segment(4);
		$id    		= $this->uri->segment(5);
		$this->db->where('id',$key);
		$query = $this->db->get('t_komentar');
		if($query->num_rows()>0){
			$this->m_komentar->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('website/c_komentar_detail/index/'.$id.'');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */