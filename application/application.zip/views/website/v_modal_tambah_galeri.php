<!-- Modal -->
<div class="modal fade" id="tambah_user" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
      </div>
      <div class="modal-body">
        <form method="post" class="form-horizontal" 
              action="<?php echo base_url();?>index.php/<?php echo $base_link ?>/tambah_data"
              enctype="multipart/form-data">
          <!--<input type="hidden" name="id" value="">  -->
          <div class="form-group">
            <label class="control-label col-lg-3">Judul Foto</label>
            <div class="col-lg-9">
              <input type="text" id="judul_galeri" name="judul_galeri" placeholder="Judul Galeri" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>
          <div class="form-group">                        
              <label for="Group User" class="control-label col-lg-3">Album</label>
                <div class="col-lg-9">
                  <select style="width:397px" name="id_album" 
                          class="form-control selectpicker" 
                          data-style="btn-default"
                          tabindex="2" required>
                     <option value="">Pilih Album</option>
                       <?php
                          foreach ($data_album->result() as $row_album){
                              echo "<option value= $row_album->id> $row_album->judul_album</option>";
                          }
                        ?>
                </select>
              </div>
            </div> 
          <div class="form-group">
            <label class="control-label col-lg-3">Gambar Album</label>
            <div class="col-lg-9">
              <input type="file" name="filefoto" class="form-control">
              <font color='red'>*Jika tidak diubah maka dikosongkan | Maks file : 2mb</font>
            </div>
          </div>   
          <div class="form-group">
            <label class="control-label col-lg-3">Keterangan</label>
            <div class="col-lg-9">
              <input type="text" id="keterangan" name="keterangan" placeholder="Ketarangan" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">
          <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
        <button type="submit" class="btn-success btn">
          <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>