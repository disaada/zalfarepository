<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>     
        <a href="<?php echo base_url();?>index.php/website/c_artikel/tambah" class="btn btn-light" ><i class="fa fa-plus"></i>Tambah Data</a>--> 
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>

              <table id="example0" class="table display">
                    <thead>
                        <tr>
                           <th>No</th>  
                           <th>Judul Konten</th>            
                           <th>Kategori Konten</th>            
                           <th style='width: 30%'>Isi Konten</th>
                           <th style='text-align: center; width: 12%'>Aksi</th>
                        </tr>
                    </thead>                 
                    <tfoot>
                        <tr>
                           <th>No</th>  
                           <th>Judul Konten</th>            
                           <th style='width: 30%'>Isi Konten</th>
                           <th style='text-align: center; width: 12%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($data->result() as $row){  
                          $konten       = 'Ubah Konten';   
                          $konten_aksi  = 'ubah';
                          $isi_konten   = htmlentities(strip_tags($row->isi)); 
                          $isi          = substr($isi_konten,0,50); // ambil sebanyak 180 karakter
                          $isi          = substr($isi_konten,0,strrpos($isi," ")); // potong per spasi kalimat   
                          if(empty($isi_konten)){
                            $isi        = '<font color=red>Belum di isi !</font>';
                            $konten     = 'Isi Konten';
                            $konten_aksi= 'isi';
                          }
                        ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>       
                            <td><?php echo ucwords($row->konten); ?></td>                                     
                            <td><span class="right label label-default"><?php echo ucwords($row->kategori); ?></span></td>                                     
                            <td><?php echo $isi ?></td>        
                                            
                            <td align='center'>
                                <a href="<?php echo base_url();?>index.php/website/c_konten/edit/<?php echo $row->id; ?>/<?php echo $konten_aksi; ?>" 
                                   class='btn btn-sm btn-light' title='<?php echo $konten ?>'><i class='fa fa-pencil'></i><?php echo $konten ?></a>       
                                
                                
                            </td>  
                        </tr>      
                        <?php 
                            }
                        ?>              
                    </tbody>
                </table>                         
            
        </div>
      </div>
    </div>
  </div>


