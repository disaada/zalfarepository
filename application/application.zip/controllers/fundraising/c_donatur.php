<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_donatur extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','40','39'));
	}
	
	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('fundraising/m_donatur');
		$this->load->model('fundraising/m_donatur');
		$getquerytable		= $this->m_donatur->GetDonatur();
		//$getdatauser		= $this->m_fundraising->GetDataUsers();
		$isi['content'] 	= 'fundraising/v_donatur';
		$isi['base_link'] 	= 'fundraising/c_donatur';
		$isi['judul'] 		= 'Fundraising ';
		$isi['sub_judul'] 	= 'Donatur';
		$isi['data'] 		= $getquerytable;		
		$this->load->view('v_home',$isi);
	}
	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $data['nama_donatur']  	 = $this->input->post('nama_donatur');
	    $data['kota']  			 = $this->input->post('kota');
	    $data['alamat']          = $this->input->post('alamat');
	    $data['no_kontak']       = $this->input->post('no_kontak');
	    $data['no_rekening']     = $this->input->post('no_rekening');
	    $data['jenis_donatur']   = $this->input->post('jenis_donatur');
	    $data['status'] 		 = 'Belum terdaftar';

	    $this->load->model('fundraising/m_donatur');
	    $this->m_donatur->GetInsert($data);
	    $this->session->set_flashdata('info','tambah');
	    redirect('fundraising/c_donatur');
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data['nama_donatur']  	 = $this->input->post('nama_donatur');
	    $data['kota']  			 = $this->input->post('kota');
	    $data['alamat']          = $this->input->post('alamat');
	    $data['no_kontak']       = $this->input->post('no_kontak');
	    $data['no_rekening']     = $this->input->post('no_rekening');
	    $data['jenis_donatur']   = $this->input->post('jenis_donatur');

		$this->load->model('fundraising/m_donatur');
		$this->m_donatur->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('fundraising/c_donatur');		
	}

  	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data['status'] 	= $this->uri->segment(4);

		$this->load->model('fundraising/m_donatur');
		$this->m_donatur->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('fundraising/c_donatur');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('fundraising/m_donatur');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_donatur');
		if($query->num_rows()>0){
			$this->m_donatur->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('fundraising/c_donatur');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */