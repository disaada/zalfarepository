<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_periode_pendaftaran extends CI_Model {

	public function GetPeriode(){
        $query=$this->db->query("SELECT t_periode_pendaftaran.`id`,
        								t_periode_pendaftaran.`status`,
                                        t_periode_ajaran.`tahun_ajaran`,
                                        t_periode_ajaran.`semester`,
                                        t_rentang_daftar.`tgl_dibuka`,
                                        t_rentang_daftar.`tgl_ditutup`
                                FROM t_periode_pendaftaran 
                                INNER JOIN t_periode_ajaran ON t_periode_pendaftaran.`id_tahun_ajaran`=t_periode_ajaran.`id`
                                INNER JOIN t_rentang_daftar ON t_periode_pendaftaran.`id_rentang_daftar`=t_rentang_daftar.`id`");
        return $query;
    }

    public function GetTahun($key=NULL){
    	if($key)
 			$this->db->where('id',$key);
        $hasil = $this->db->get('t_periode_ajaran');
        return $hasil;
    }

    public function GetRentang($key=NULL){
    	if($key)
 			$this->db->where('id',$key);
        $hasil = $this->db->get('t_rentang_daftar');
        return $hasil;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_donatur');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_periode_pendaftaran',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_periode_pendaftaran',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_periode_pendaftaran');
    }

    public function GetReset($key,$data){
            $this->db->query("UPDATE t_periode_pendaftaran
            					SET status='$data'
            					WHERE id=$key");
            $this->db->query("UPDATE t_periode_pendaftaran
            					SET status='Tidak terpilih'
            					WHERE id<>$key");
    }

}

/* End of file m_periode_pendaftaran.php */
/* Location: ./application/models/muq/m_periode_pendaftaran.php */