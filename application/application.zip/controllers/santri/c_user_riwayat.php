<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_riwayat extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->m_squrity->check_access(array('43'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_riwayat');
		$getID		= $this->m_user_riwayat->GetSession($this->session->userdata('username'))->row_array();
		$getquerytable		= $this->m_user_riwayat->GetDataSantri($getID['id']);
		$isi['content'] 	= 'santri/v_user_riwayat';
		$isi['base_link'] 	= 'santri/c_user_riwayat';
		$isi['judul'] 		= 'Riwayat Pendidikan Santri';
		$isi['sub_judul'] 	= 'Data Riwayat Pendidikan Santri';
		$isi['data'] 		= $getquerytable->row_array();	
		
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_riwayat');
		$getID		= $this->m_user_riwayat->GetSession($this->session->userdata('username'))->row_array();		
		$key 					= $getID['id'];
		$isi['content'] 		= 'santri/v_form_riwayat';
		$isi['back_link'] 		= 'santri/c_user_riwayat';
		$isi['base_link'] 		= 'santri/c_user_riwayat/edit/'.$key.'';
		$isi['judul'] 			= 'Data Riwayat Pendidikan Santri';
		$isi['sub_judul'] 		= 'Edit Data';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_riwayat_pendidikan 
                                 WHERE id_pendaftaran=".$key."
                                ");
		$useQuery = $query->result();
		if($query->num_rows()>0)
		{
			$isi['option']				= 'edit';
			$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
			$isi['jurusan'] 			= ''; $isi['no_ijazah']			= '';
			$isi['pendidikan'] 			= ''; $isi['nama_pendidikan'] 	= '';
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_user_riwayat->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			$isi['option']				= 'tambah';
			$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
			$isi['jurusan'] 			= ''; $isi['no_ijazah']			= '';
			$isi['pendidikan'] 			= ''; $isi['nama_pendidikan'] 	= '';
			$isi['getData']				= $this->m_user_riwayat->GetDataSantri($key)->row_array();
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			//$isi['getData']				= $this->m_user_riwayat->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran			  	 	= $this->input->post('id_pendaftaran');
	    $add['nama']  			 		= $this->input->post('nama');
	    $add['tahun']    				= $this->input->post('tahun');
	    $add['tingkat']    				= $this->input->post('tingkat');
	    $add['no_ijazah']    			= $this->input->post('no_ijazah');
	    $add['jurusan']    				= $this->input->post('jurusan');

	    $this->load->model('santri/m_user_riwayat');

		if(!$id_pendaftaran=="" || !empty($add)){
			for ($i=0; $i < count($add['nama']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['nama']  			 		= $add['nama'][$i];
			    $new['tahun']    				= $add['tahun'][$i];
			    $new['tingkat']    				= $add['tingkat'][$i];
			    $new['no_ijazah']    			= $add['no_ijazah'][$i];
			    $new['jurusan']    				= $add['jurusan'][$i];
		    	$this->m_user_riwayat->GetInsert($new);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('santri/c_user_riwayat');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('santri/c_user_riwayat/edit');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id_edit');
		$data['nama']  	 					= $this->input->post('nama_edit');
	    $data['jurusan']  				 	= $this->input->post('jurusan_edit');
	    $data['tingkat'] 	         		= $this->input->post('tingkat_edit');
	    $data['tahun']       				= $this->input->post('tahun_edit');
	    $data['no_ijazah']     				= $this->input->post('no_ijazah_edit');

	    for ($i=0; $i < count($data['nama']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['nama']  			 		= $data['nama'][$i];
		    $insert['tahun']    				= $data['tahun'][$i];
		    $insert['tingkat']    				= $data['tingkat'][$i];
		    $insert['no_ijazah']    			= $data['no_ijazah'][$i];
		    $insert['jurusan']    				= $data['jurusan'][$i];

	    	$this->load->model('santri/m_user_riwayat');
			$this->m_user_riwayat->GetUpdate($data['id'][$i],$insert);
	    }

	    $id_pendaftaran			  	 	= $this->input->post('id_pendaftaran');
	    $add['nama']  			 		= $this->input->post('nama');
	    $add['tahun']    				= $this->input->post('tahun');
	    $add['tingkat']    				= $this->input->post('tingkat');
	    $add['no_ijazah']    			= $this->input->post('no_ijazah');
	    $add['jurusan']    				= $this->input->post('jurusan');
	    if(!empty($add['nama'])){
			for ($i=0; $i < count($add['nama']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['nama']  			 		= $add['nama'][$i];
			    $new['tahun']    				= $add['tahun'][$i];
			    $new['tingkat']    				= $add['tingkat'][$i];
			    $new['no_ijazah']    			= $add['no_ijazah'][$i];
			    $new['jurusan']    				= $add['jurusan'][$i];
		    	$this->m_user_riwayat->GetInsert($new);
		    }
		}

		$this->session->set_flashdata('info','edit');
		redirect('santri/c_user_riwayat');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_riwayat');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_user_riwayat->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('santri/c_user_riwayat');
		}		
		
	}

}

/* End of file c_user_riwayat.php */
/* Location: ./application/controllers/santri/c_user_riwayat.php */