<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_kebutuhan_detail extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    //hak akses
    /*=========================
      1 : super admin
      39  : admin
      40  : keuangan
      41  : editor
      42  : sekretaris
    ==========================*/
    $this->m_squrity->check_access(array('1','40','39'));
  }

  public function index()
  {   
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_kebutuhan');
    $key = $this->uri->segment(4);
    $getquerytable        = $this->m_kebutuhan->GetKebutuhanDetail($key);
    $getperiode           = $this->m_kebutuhan->GetPeriode($key);

    $isi['content']       = 'fundraising/v_kebutuhandetail';
    $isi['base_link']     = 'fundraising/c_kebutuhan_detail/index/'.$key.'';
    $isi['link_back']     = 'fundraising/c_kebutuhan';
    $isi['judul']         = 'Kebutuhan';
    $isi['sub_judul']     = 'Detail Kebutuhan';
    $isi['data']          = $getquerytable;
    $isi['periode']       = $getperiode;
    $isi['id']            = $key;
    //$isi['total']         = $this->m_kebutuhan->GettotKebutuhan($key);

    $data['total_kebutuhan']  = $this->m_kebutuhan->GettotKebutuhan($key);
    $this->m_kebutuhan->GetUpdateKeb($key,$data);

    $this->load->view('v_home',$isi);
  }
  public function tambah_data()
  {
    $this->m_squrity->getsqurity();
    $data['id_fundraising']  = $this->input->post('id_fundraising');
    $data['nama_kebutuhan']  = $this->input->post('nama_kebutuhan');
    $data['nominal']         = $this->input->post('nominal');
    $id                      = $this->input->post('id_fundraising');
    $this->load->model('fundraising/m_kebutuhan');
    $this->m_kebutuhan->GetInsert($data);
    $this->session->set_flashdata('info','tambah');
    redirect('fundraising/c_kebutuhan_detail/index/'.$id.'');
  }

  public function edit_data()
  {
    $this->m_squrity->getsqurity();
    $key                     = $this->input->post('id');
    $data['nama_kebutuhan']  = $this->input->post('nama_kebutuhan');
    $data['nominal']         = $this->input->post('nominal');
    $id                      = $this->input->post('id_fundraising');

    $this->load->model('fundraising/m_kebutuhan');
    $this->m_kebutuhan->GetUpdate($key,$data);
    $this->session->set_flashdata('info','edit');
    redirect('fundraising/c_kebutuhan_detail/index/'.$id.'');   
  }

  public function hapus_data()
  {
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_kebutuhan');

    $key    = $this->uri->segment(4);
    $id     = $this->uri->segment(5);
    $this->db->where('id',$key);
    $query = $this->db->get('t_kebutuhan');
    if($query->num_rows()>0){
      $this->m_kebutuhan->GetDelete($key);
      $this->session->set_flashdata('info','hapus');
      redirect('fundraising/c_kebutuhan_detail/index/'.$id.'');
    }   
    
  }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */