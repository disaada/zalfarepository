<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> -->     
         <a href="<?php echo base_url();?>index.php/muq/c_pengalaman_santri/tambah" class="btn btn-light" ><i class="fa fa-plus"></i>Tambah Data</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th style='width: 2%'>No</th>
                            <th style='width: 17%'>Nama</th>
                            <th style='width: 25%'>Jumlah Riwayat Pengalaman</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </thead>
                 
                    <tfoot>
                        <tr>
                            <th style='width: 2%'>No</th>
                            <th style='width: 17%'>Nama</th>
                            <th style='width: 25%'>Jumlah Riwayat Pengalaman</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                      <?php
                        $no=1;
                        foreach ($data->result() as $row){                       
                            $totalorg = $this->m_pengalaman_santri->countPengalaman($row->id)->result();
                        ?>  
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $row->nama_santri; ?></td>
                            <td><span class="label label-primary"><?php echo count($totalorg); ?> Pengalaman</span></td>  
                            <td>
                                <a id="<?php echo $row->id ?>"  href="#lihat_data<?php echo $row->id; ?>" data-toggle="modal"  
                                   class='btn btn-sm btn-light' title='lihat'><i class='fa fa-eye'></i></a>
                                  <!-- Modal -->
                                  <div class="modal fade" id="lihat_data<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                          <h4 class="modal-title">Data Pengalaman Organisasi <?php echo $row->nama_santri;   ?></h4>
                                        </div>
                                        <div class="modal-body">                                        
                                            
                                            <h4 class="modal-title">                                       
                                              <div class="row">
                                                <div class="col-lg-2">Nama</div>
                                                <div class="col-lg-10"><?php echo $row->nama_santri;   ?></div>
                                              </div>
                                              <div class="row">
                                                <div class="col-lg-2">Alamat</div>
                                                <div class="col-lg-10"><?php echo $row->alamat_pendaftaran_santri;   ?></div>
                                              </div>
                                              <br><br>
                                              <div class="row">
                                                <div class="col-lg-12 text-center">Pengalaman Berorganisasi</div>
                                              </div>

                                            </h4>

                                            <table class="table">
                                              <thead>
                                                <th>Organisasi</th>
                                                <th>Jabatan</th>
                                                <th>Tahun Awal</th>
                                                <th>Tahun Akhir</th>
                                              </thead>
                                                <tbody>
                                              <?php $query=$this->db->query("SELECT *   
                                                                             FROM t_santri_p_organisasi 
                                                                             WHERE id_pendaftaran=".$row->id."
                                                                            ");
                                                if($query->num_rows()>0)
                                                {
                                                  $putData       = $query->result(); 
                                                  foreach ($putData as $key) {?>
                                                    <tr>
                                                      <td><?php echo $key->organisasi;?></td>
                                                      <td><?php echo $key->jabatan;?></td>
                                                      <td><?php echo $key->tahun_awal;?></td>
                                                      <td><?php echo $key->tahun_akhir;?></td>
                                                    </tr>
                                                <?php 
                                                  }
                                                }
                                                else{
                                                  $putData       = null; ?>
                                                      <tr>
                                                        <td colspan="4" class="text-center">No data</td>
                                                      </tr>
                                                <?php } ?>
                                              </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-danger" data-dismiss="modal">
                                              <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                <a href="<?php echo base_url();?>index.php/muq/c_pengalaman_santri/edit/<?php echo $row->id; ?>" 
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-pencil'></i></a>
                            </td>  
                        </tr>
                        <?php
                            $no++; 
                            }
                        ?>  

                    </tbody>
                </table>   
        </div>
      </div>
    </div>
  </div>
