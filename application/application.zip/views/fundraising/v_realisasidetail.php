<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> -->     
        <a href="<?php echo base_url();?>index.php/<?php echo $link_back ?>" type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i>Kembali</a>
        <a href="#" class="btn btn-light" data-toggle="modal" data-target="#tambah_detail_kebutuhan"><i class="fa fa-plus"></i>Tambah Data</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
        	<div class="btn-group" role="group" aria-label="...">
              
        	    <a class="btn btn-light"><i class="fa fa-calendar"></i>
                 <b><?php echo $this->m_realisasi->NamaBulan($periode); ?> 
                    <?php echo substr($periode, 3, 4);?>
                 </b></a>
              
            </div>            
            <hr>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Realisasi Kebutuhan</th>
                            <th>Nominal(Rp.)</th>
                            <th>Tgl Realisasi</th>
                            <th>Keterangan</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </thead>                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Realisasi Kebutuhan</th>
                            <th>Nominal(Rp.)</th>
                            <th>Tgl Realisasi</th>
                            <th>Keterangan</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                         <?php
                        $no = 1;                                                
                        foreach ($data->result() as $row){
                      ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row->realisasi_kebutuhan ?></td>
                            <td>Rp. <?php echo number_format($row->nominal,2,',','.'); ?></td>
                            <td><?php echo $row->tgl_realisasi ?></td>
                            <td><?php echo $row->keterangan ?></td>
                            <td style='width: 13%'>
                                <a id="<?php echo $row->id ?>"  href="#edit_detail_kebutuhan<?php echo $row->id; ?>" data-toggle="modal"  class='btn btn-sm btn-light' title='Edit'><i class='fa fa-pencil'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="edit_detail_kebutuhan<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Edit <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">
                                        <form method="post" class="form-horizontal" 
                                              action="<?php echo base_url();?>index.php/fundraising/c_realisasi_detail/edit_data">
                                          <input type="hidden" name="id_fundraising" value="<?php echo $id; ?>">  
                                          <input type="hidden" name="id" value="<?php echo $row->id; ?>">  
                                        <div class="form-group">
            								            <label class="control-label col-lg-3">Realisasi Kebutuhan  </label>
            								            <div class="col-lg-9">
            								              <select style="width:397px" name="realisasi_kebutuhan" data-placeholder="Pilih Dari Kebutuhan ..." 
                                                  class           ="form-control selectpicker"
                                                  data-style      ="btn-default"
                                                  data-live-search="true">
                                                <?php
                                                    $data_realisasi = '';
                                                    $data=0;
                                                    foreach ($data_kebutuhan->result() as $row_kebutuhan){                                                      
                                                      if($row_kebutuhan->nama_kebutuhan==$row->realisasi_kebutuhan){
                                                          $data = 1;
                                                          echo "<option value=  ".$row_kebutuhan->id."> 
                                                                $row_kebutuhan->nama_kebutuhan</option>";
                                                      }                                                                                                              
                                                    }

                                                    if($data==0){
                                                      echo "<option value= ''> Pilih Dari Kebutuhan</option>";
                                                          $data_realisasi = $row->realisasi_kebutuhan;
                                                    } 

                                                    foreach ($data_kebutuhan->result() as $row_kebutuhan){                                                      
                                                      if($row_kebutuhan->nama_kebutuhan==$row->realisasi_kebutuhan){
                                                          continue;
                                                      }
                                                          echo "<option value=  ".$row_kebutuhan->id."> 
                                                                $row_kebutuhan->nama_kebutuhan</option>";                                                                                                                                                                    
                                                    }

                                                    if($data==1){
                                                      echo "<option value= ''>--- Kosongkan ---</option>";
                                                    } 

                                                ?>                                            
                                          </select>
                                          <font color=red><strong>*Opsi dikosongkan apabila inputan diluar data kebutuhan</strong></font>
            								             </div>                                        
              								          </div> 
                                        <div class="form-group">
                                          <label class="control-label col-lg-3">&nbsp; </label>
                                          <div class="col-lg-9">
                                            <input type="text" id="realisasi_kebutuhan" name="realisasi_kebutuhan_2" placeholder="Lainnya" 
                                                   class="form-control" value='<?php echo $data_realisasi ?>'>
                                                   <font color=red><strong>*opsi diisi jika data diluar realisasi kebutuhan</strong></font>
                                          </div>
                                        </div>
                                        <div class="form-group">
              								            <label class="control-label col-lg-3">Nominal  </label>
              								            <div class="col-lg-9">
              								              <input type="number" id="nominal" name="nominal" placeholder="Nominal" 
              								                     class="form-control" required
              								                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
              								                     oninput="setCustomValidity('')"
              								                     value='<?php echo $row->nominal ?>'>
              								            </div>
              								          </div> 
                                        <div class="form-group">
                                          <label class="control-label col-lg-3">Tanggal </label>
                                          <div class="col-lg-4">
                                            <input type="text" id="nominal" name="tgl_realisasi" placeholder="Tanggal Realisasi" class="form-control" 
                                                   oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                                                   oninput="setCustomValidity('')"
                                                   value='<?php echo $row->tgl_realisasi ?>'>
                                          </div>
                                          <div class="col-lg-5">
                                            <input type="text" readonly 
                                                   value="<?php echo $this->m_realisasi->NamaBulan($periode); ?> <?php echo substr($periode, 3, 4);?>" 
                                                   class="form-control" 
                                                   >
                                          </div>
                                        </div> 
                                        <div class="form-group">
                                          <label class="control-label col-lg-3">Keterangan </label>
                                          <div class="col-lg-9">
                                            <textarea name='keterangan' placeholder="Tulis keterangan ..."  
                                                     style="width:100%;" class="form-control"><?php echo $row->keterangan ?></textarea>
                                          </div>
                                        </div>                                           
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <button type="submit" class="btn-success btn">
                                            <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
                                      </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <a id="<?php echo $row->id ?>"  href="#hapus_detail_kebutuhan<?php echo $row->id; ?>" 
                                   data-toggle="modal"  class='btn btn-sm btn-light' title='Hapus'><i class='fa fa-trash'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="hapus_detail_kebutuhan<?php echo $row->id; ?>" 
                                	 tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Hapus <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">                                        
                                          Apakah anda yakin ingin menghapus data ini ?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <a class="btn-success btn" href="<?php echo base_url();?>index.php/fundraising/c_realisasi_detail/hapus_data/<?php echo $row->id; ?>/<?php echo $id; ?>"><i class='fa fa-trash-o'></i>&nbsp;Hapus</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>
                        </tr>      
                        <?php 
                            }
                        ?>     
                    </tbody>
                </table>               
            <?php
            	echo $this->load->view('fundraising/v_modal_tambah_detail_realiasi'); 
            ?>
            
      </div>
    </div>
  </div>
</div>