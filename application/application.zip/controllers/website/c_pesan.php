<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_pesan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_pesan');
		$getquerytable		= $this->m_pesan->GetPesan();
		$isi['content'] 	= 'website/v_pesan';
		$isi['base_link'] 	= 'website/c_pesan';
		$isi['judul'] 		= 'Pengaturan Website ';
		$isi['sub_judul'] 	= 'Pesan';
		$isi['data'] 		= $getquerytable;
		$this->load->view('v_home',$isi);
	}
	
	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 					= $this->uri->segment(5);
		$data['status_pesan'] 	= $this->uri->segment(4);

		$this->load->model('website/m_pesan');
		$this->m_pesan->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_pesan');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_pesan');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_pesan');
		if($query->num_rows()>0){
			$this->m_pesan->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('website/c_kpesan');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */