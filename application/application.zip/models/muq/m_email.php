<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_email extends CI_Model {

 
    function sendMail($to=NULL, $user=NULL, $pass = NULL) {
        $ci = get_instance();
        $ci->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = "testdatarangga@gmail.com";
        $config['smtp_pass'] = "katasandi123";
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";
        
        
        $ci->email->initialize($config);
 
        $ci->email->from('noreply@mahadusyaqilquran.id', 'MUQ No Reply');
        $ci->email->to($to);
        $ci->email->subject('Data Akun');
        /*$ci->email->message('Selamat anda berhasil mendaftar untuk menjadi santri di MUQ.\n
        					 Segera lengkapi kelengkapan data dengan login ke website menggunakan akun :\n
        					 Username :'.$user.'\n
        					 Password : '.$pass.'\n
        					 Terima Kasih.');*/
        $ci->email->message('<head><body><table class="container" cellspacing="0" cellpadding="0">
							<tr>
							<td>
							<div class="wrapper">

							<h1 class="header">Akun Pendaftaran Santri</h1>

							<img class="image" src="http://mahadusyaqilquran.id/assets/img/LOGOWEB2.png">
							<p class="text margin">
								Selamat anda telah berhasil melakukan pendaftaran di Ma\'had Usyaqil Qur\'an
							</p>
							<p class="text margin">
								Username : <b>'.$user.'</b>
							</p>
							<p class="text margin">
								Password : <b>'.$pass.'</b>
							</p>
							<p class="text margin">
								Mohon agar melengkapi kelengkapan di <a href="http://mahadusyaqilquran.id/admin">Form Isian Kelengkapan</a>
							</p>
							</div>
							</td>
							</tr>
							</table></body></head>');
        if ($this->email->send()) {
            echo 'Email sent.';
        } else {
            show_error($this->email->print_debugger());
        }
    }

}

/* End of file m_email.php */
/* Location: ./application/models/muq/m_email.php */