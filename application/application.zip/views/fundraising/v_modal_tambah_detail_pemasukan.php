<!-- Modal -->
<div class="modal fade" id="tambah_detail_kebutuhan" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
      </div>
      <div class="modal-body">
        <form method="post" class="form-horizontal" 
              action="<?php echo base_url();?>index.php/fundraising/c_pemasukan_detail/tambah_data">
          <input type="hidden" name="id_fundraising" value="<?php echo $id; ?>">  
          <div class="form-group">
            <label class="control-label col-lg-3">Nama Donatur  </label>
            <div class="col-lg-9">
              <select style="width:397px" name="id_donatur" 
                          class="form-control selectpicker" 
                          data-style="btn-default"
                          data-live-search="true"
                          tabindex="2" required>
                     <option value="">Pilih Donatur</option>
                       <?php
                          foreach ($data_donatur->result() as $row_donatur){
                              echo "<option value= $row_donatur->id> $row_donatur->nama_donatur</option>";
                          }
                        ?>
                </select>
            </div>
          </div>  
          <div class="form-group">
            <label class="control-label col-lg-3">Tanggal </label>
            <div class="col-lg-4">
              <input type="text" id="tgl_pemasukan" name="tgl_pemasukan" placeholder="Tanggal Pemasukan" class="form-control" 
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
            <div class="col-lg-5">
              <input type="text" readonly 
                     value="<?php echo $this->m_pemasukan->NamaBulan($periode); ?> <?php echo substr($periode, 3, 4);?>" 
                     class="form-control" 
                     >
            </div>
          </div> 
          <div class="form-group">
            <label class="control-label col-lg-3">Nominal(Rp.) </label>
            <div class="col-lg-9">
              <input type="number" id="nominal" name="nominal" placeholder="Nominal" class="form-control" 
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>    
          <div class="form-group">
            <label class="control-label col-lg-3">Keterangan </label>
            <div class="col-lg-9">
              <textarea name='keterangan' placeholder="Tulis keterangan ..."  
                       style="width:100%;" class="form-control"></textarea>
            </div>
          </div>          
      </div>
      <div class="modal-footer">
        <a href="<?php echo base_url();?>index.php/fundraising/c_donatur" class="btn btn-warning">
          <i class="fa fa-plus"></i>Tambah Donatur</a>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="button" class="btn btn-danger" data-dismiss="modal">
          <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
        <button type="submit" class="btn-success btn">
          <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>