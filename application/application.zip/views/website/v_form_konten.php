
  <div class="page-header">
    <h1 class="title"><?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>

<div class="container-default">
  <div class="row">

    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
           <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/website/c_konten/edit_data">
            <input type="hidden" name="id" value="<?php echo $id; ?>">  
            <div class="panel-body">
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Judul Konten</label>
                    <div class="col-lg-6">
                      <input  type="text" id="konten" name="konten"  class="form-control"
                              placeholder="Judul Konten"
                              readonly
                              value="<?php echo ucwords($konten); ?>"> 
                    </div>
              </div>
            </div>
             <div class="panel-body">
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Kategori</label>
                    <div class="col-lg-6">
                      <input  type="text" name="kategori"  class="form-control"
                              placeholder="kategori"
                              readonly
                              value="<?php echo ucwords($kategori); ?>"> 
                    </div>
              </div>
            </div>            
            <div class="panel-body">
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Isi Konten</label>
                    <div class="col-lg-10">
                      <p>
                          <textarea name='isi' id="summernote" placeholder="Enter text ..."  style="height:200px; width:100%;">
                              <?php echo $isi; ?>
                          </textarea>
                      </p>
                    </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>    



