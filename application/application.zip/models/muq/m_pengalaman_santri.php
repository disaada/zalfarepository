<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pengalaman_santri extends CI_Model {

	public function GetDataSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri");
        return $query;
    }

    public function GetDataPengalaman(){
        $query=$this->db->query("SELECT t_santri_p_organisasi.`id`,
                                        t_santri_p_organisasi.`id_pendaftaran`, 
                                        t_santri_p_organisasi.`organisasi`,
                                        t_santri_p_organisasi.`tahun_awal`,
                                        t_santri_p_organisasi.`tahun_akhir`,
                                        t_santri_p_organisasi.`jabatan`,
                                        t_pendaftaran_santri.`nama_santri`
                                 FROM t_santri_p_organisasi INNER JOIN t_pendaftaran_santri 
                                 ON t_santri_p_organisasi.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                 WHERE t_pendaftaran_santri.`nama_santri` <> 'Agen' 
                                ");
        return $query;
    }

    public function CountPengalaman($key){
        $this->db->where('id_pendaftaran',$key);
        $hasil = $this->db->get('t_santri_p_organisasi');
        return $hasil;
    }

    public function GetData($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,t_pendaftaran_santri.`nama_santri`
                                 FROM t_pendaftaran_santri INNER JOIN t_santri_p_organisasi 
                                 ON t_pendaftaran_santri.`id`=t_santri_p_organisasi.`id_pendaftaran`
                                 WHERE t_santri_p_organisasi.`id_pendaftaran`=".$key);
        return $query;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_santri_p_organisasi',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri_p_organisasi',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_santri_p_organisasi');
    }

}

/* End of file m_pengalaman_santri.php */
/* Location: ./application/models/muq/m_pengalaman_santri.php */