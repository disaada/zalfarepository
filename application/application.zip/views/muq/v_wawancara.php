<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data nilai wawancara berhasil ditambahkan.</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
        
        <div class="panel-body">
          <div class="form-group">
            <label for="Group User" class="control-label ">Pilih Periode :</label>             
            <div class="dropdown">

              <?php 
                if($periode=='all'){ ?>
                <button class="btn btn-light  btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                  ALL
                  <span class="caret"></span>
                </button>
              <?php
                }else {?>
                  <button class="btn btn-light  btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                  <?php
                    $get = $this->m_wawancara->periode($periode)->row_array();
                    echo tgl_indo($get['tgl_dibuka'])."-".tgl_indo($get['tgl_ditutup']);
                   ?>
                  <span class="caret"></span>
                </button> 
              <?php } ?>
              <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                <li role="presentation">
                  <a role="menuitem" tabindex="-1" 
                     href="<?php echo base_url();?>index.php/muq/c_wawancara">
                      ALL
                  </a>
                </li>
                <?php 
                  $get = $this->m_wawancara->periode()->result(); 
                  foreach ($get as $row) { ?>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" 
                         href="<?php echo base_url();?>index.php/muq/c_wawancara/periode/<?php echo $row->id; ?>">
                          <?php echo tgl_indo($row->tgl_dibuka)."-".tgl_indo($row->tgl_ditutup); ?>
                      </a>
                    </li>
                <?php }
                 ?>
              </ul>
            </div>
          </div>
          <?php 
          // cek periode
          if($periode=='all'){
            $linkperiode = '';
          }
          else{
            $linkperiode = '/'.$periode;
          }
          
          ?>
          <table class="table">
            <thead>
              <th>Jumlah Santri</th>
              <th>Belum Diwawancara</th>
              <th>Sudah Diwawancara</th>
              <th>Hasil Wawancara</th>
            </thead>
            <tfoot>
              <th>Jumlah Santri</th>
              <th>Belum Diwawancara</th>
              <th>Sudah Diwawancara</th>
              <th>Hasil Wawancara</th>
            </tfoot>

            <tbody>
              <tr>
                <td><span class="label label-primary"><?php echo $total; ?> Santri</span></td>
                <td>
                  <span class="label label-danger"><?php echo $belumwawancara; ?> Santri</span> &nbsp; 
                  <a href="<?php echo base_url();?>index.php/muq/c_wawancara/isian<?php echo $linkperiode;?>" 
                                   class='btn btn-xs btn-light' title='Isian'><i class='fa fa-pencil'></i> Isi Nilai</a>
                </td>
                <td>
                  <span class="label label-success"><?php echo $sudahwawancara; ?> Santri</span> &nbsp;
                  <a href="<?php echo base_url();?>index.php/muq/c_wawancara/edit<?php echo $linkperiode;?>" 
                                   class='btn btn-xs btn-light' title='Ubah'><i class='fa fa-pencil'></i> Ubah Nilai</a>
                </td>
                <td>
                  <span class="label label-warning"><?php echo $sudahwawancara; ?> Santri</span> &nbsp;
                  <a href="<?php echo base_url();?>index.php/muq/c_wawancara/view<?php echo $linkperiode;?>" 
                                   class='btn btn-xs btn-light' title='Lihat'><i class='fa fa-eye'></i> Lihat Nilai</a>
                </td>
              </tr>
            </tbody>
          </table>
          

        </div>

      </div>
    </div>
  </div>
</div>
