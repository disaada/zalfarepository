<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_wawancara extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_wawancara');
		$getTotal				= $this->m_wawancara->TotalSantri();
		$isi['content'] 		= 'muq/v_wawancara';
		$isi['base_link'] 		= 'muq/c_wawancara';
		$isi['judul'] 			= 'Wawancara Santri';
		$isi['sub_judul'] 		= 'Data Wawancara Santri';
		$isi['periode']			= 'all';

		$data 					= $this->m_wawancara->GetKelengkapan()->result();
		$santri = array();
		foreach ($data as $row) {
			$cekupload			= $this->m_wawancara->cekKelengkapan($row->id);
			if(!empty($cekupload)){
              $total_supload	= $this->m_wawancara->TotalUpload($row->id);
              if($total_supload>7){
              	array_push($santri, $row->id);
              }
            }
		}

		$ambil 					= $this->m_wawancara->DataWawancara()->result();
		$swawancara = array();
		$bwawancara = array();
		foreach ($santri as $row) {
			$ceknilai			= $this->m_wawancara->GetWawancara($row)->num_rows();
			if(!empty($ceknilai)){
              $total_isian 		= $this->m_wawancara->tWawancara($row);
              if($total_isian<>0){
              	array_push($swawancara, $row);
              }
              else{
              	array_push($bwawancara, $row);
              }
            }
		}

		$isi['total'] 			= count($santri);
		$isi['sudahwawancara']	= count($swawancara);
		$isi['belumwawancara']	= count($bwawancara);
		$this->load->view('v_home',$isi);
	}

	public function edit($key=NULL){
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_wawancara');
		$getTotal				= $this->m_wawancara->TotalSantri();
		$isi['content'] 		= 'muq/v_form_wawancara';
		$isi['base_link'] 		= 'muq/c_wawancara/edit';
		$isi['back_link'] 		= 'muq/c_wawancara';
		$isi['judul'] 			= 'Wawancara Santri';
		$isi['sub_judul'] 		= 'Data Wawancara Santri';
		$isi['option']			= 'edit';
		$isi['periode']			= $key;

		//$data 					= $this->m_wawancara->GetKelengkapan()->result();
		if(!empty($key)){
			$data 				= $this->m_wawancara->GetPeriode($key)->result();
		}
		else{
			$data 				= $this->m_wawancara->GetKelengkapan()->result();
		}

		$santri = array();
		foreach ($data as $row) {
			$cekupload			= $this->m_wawancara->cekKelengkapan($row->id);
			if(!empty($cekupload)){
              $total_supload 	= $this->m_wawancara->TotalUpload($row->id);
              if($total_supload>7){
              	array_push($santri, $row->id);
              }
            }
		}

		$ambil 					= $this->m_wawancara->DataWawancara()->result();
		$swawancara = array();
		foreach ($santri as $row) {
			$ceknilai			= $this->m_wawancara->GetWawancara($row)->num_rows();
			if(!empty($ceknilai)){
              $total_isian = $this->m_wawancara->tWawancara($row);
              if($total_isian<>0){
              	array_push($swawancara, $row);
              }
            }
		}

		$isi['santri'] = $swawancara;
		$this->load->view('v_home',$isi);
	}

	public function view($key=NULL){
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_wawancara');
		$getTotal				= $this->m_wawancara->TotalSantri();
		$isi['content'] 		= 'muq/v_view_wawancara';
		$isi['base_link'] 		= 'muq/c_wawancara/stat_data';
		$isi['back_link'] 		= 'muq/c_wawancara';
		$isi['judul'] 			= 'Wawancara Santri';
		$isi['sub_judul'] 		= 'Data Wawancara Santri';
		$isi['periode']			= $key;

		if(!empty($key)){
			$getData 			= $this->m_wawancara->GetWawancaraSortID($key);
		}
		else{
			$getData 			= $this->m_wawancara->GetWawancaraSort();
		}


		$isi['santri'] 			= $getData->result();
		$this->load->view('v_home',$isi);
	}

	public function isian($key=NULL){
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_wawancara');
		$getTotal				= $this->m_wawancara->TotalSantri();
		$isi['content'] 		= 'muq/v_form_wawancara';
		$isi['base_link'] 		= 'muq/c_wawancara/isian';
		$isi['back_link'] 		= 'muq/c_wawancara';
		$isi['judul'] 			= 'Isi Wawancara Santri';
		$isi['sub_judul'] 		= 'Isi Data Wawancara Santri';
		$isi['option']			= 'tambah';
		$isi['periode']			= $key;

		//$key 					= $this->uri->segment(4);
		if(!empty($key)){
			$data 				= $this->m_wawancara->GetPeriode($key)->result();
		}
		else{
			$data 				= $this->m_wawancara->GetKelengkapan()->result();
		}

		$santri = array();
		foreach ($data as $row) {
			$cekupload			= $this->m_wawancara->cekKelengkapan($row->id);
			if(!empty($cekupload)){
              $total_supload = $this->m_wawancara->TotalUpload($row->id);
              if($total_supload>7){
              	array_push($santri, $row->id);
              }
            }
		}

		$ambil 					= $this->m_wawancara->DataWawancara()->result();
		$bwawancara = array();
		foreach ($santri as $row) {
			$ceknilai			= $this->m_wawancara->GetWawancara($row)->num_rows();
			if(!empty($ceknilai)){
              $total_isian = $this->m_wawancara->tWawancara($row);
              if($total_isian==0){
              	array_push($bwawancara, $row);
              }
            }
		}

		$isi['santri'] = $bwawancara;
		$this->load->view('v_home',$isi);
	}
	
	public function tambah_data()
    {
    	$this->load->model('muq/m_wawancara');
	    $this->m_squrity->getsqurity();

	    $data['id_pendaftaran']  	 		= $this->input->post('id_pendaftaran');
	    $data['komitmen']  			 		= $this->input->post('komitmen');
	    $data['motivasi']          			= $this->input->post('motivasi');
	    $data['akhlak']       				= $this->input->post('akhlak');

		if(!$data['id_pendaftaran']==""){
			for ($i=0; $i < count($data['id_pendaftaran']) ; $i++) { 
		    	$insert['id_pendaftaran']  	 		= $data['id_pendaftaran'][$i];
			    $insert['komitmen']  			 	= $data['komitmen'][$i];
			    $insert['motivasi']    				= $data['motivasi'][$i];
			    $insert['akhlak']    				= $data['akhlak'][$i];
			    $insert['rata_rata']				= ($data['komitmen'][$i]+$data['motivasi'][$i]+$data['akhlak'][$i])/3;
			    $insert['komulatif']				= ($data['komitmen'][$i]+$data['motivasi'][$i]+$data['akhlak'][$i]);

			    if(!empty($data['komitmen'][$i]) || !empty($data['motivasi'][$i]) || !empty($data['akhlak'][$i])){
			    	$this->m_wawancara->GetInsert($insert);
			    }
		    }
		    $this->session->set_flashdata('info','tambah');
			redirect('muq/c_wawancara');			    
		}
		else{
			$this->session->set_flashdata('info','error');
		}
		    
  	}

  	public function edit_data()
	{
		$this->load->model('muq/m_wawancara');
	    $this->m_squrity->getsqurity();

	    $data['id_pendaftaran']  	 		= $this->input->post('id_pendaftaran');
	    $data['komitmen']  			 		= $this->input->post('komitmen');
	    $data['motivasi']          			= $this->input->post('motivasi');
	    $data['akhlak']       				= $this->input->post('akhlak');

		if(!$data['id_pendaftaran']==""){
			for ($i=0; $i < count($data['id_pendaftaran']) ; $i++) { 
		    	$insert['id_pendaftaran']  	 		= $data['id_pendaftaran'][$i];
			    $insert['komitmen']  			 	= $data['komitmen'][$i];
			    $insert['motivasi']    				= $data['motivasi'][$i];
			    $insert['akhlak']    				= $data['akhlak'][$i];
			    $insert['rata_rata']				= ($data['komitmen'][$i]+$data['motivasi'][$i]+$data['akhlak'][$i])/3;

			    if(!empty($data['komitmen'][$i]) || !empty($data['motivasi'][$i]) || !empty($data['akhlak'][$i])){
			    	$this->m_wawancara->GetUpdate($data['id_pendaftaran'][$i],$insert);
			    }
		    }
		    $this->session->set_flashdata('info','tambah');
			redirect('muq/c_wawancara');			    
		}
		else{
			$this->session->set_flashdata('info','error');
		}
	}

	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data['status']	 	= $this->uri->segment(4);

		$this->load->model('muq/m_wawancara');
		$this->m_wawancara->GetReset($key,$data);

		$this->session->set_flashdata('info','edit');
		redirect('muq/c_wawancara/view');		
	}

	public function periode($key=NULL){
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_wawancara');
		$getTotal				= $this->m_wawancara->TotalSantri();
		$isi['content'] 		= 'muq/v_wawancara';
		$isi['base_link'] 		= 'muq/c_wawancara';
		$isi['judul'] 			= 'Wawancara Santri';
		$isi['sub_judul'] 		= 'Data Wawancara Santri';
		$isi['periode']			= $key;

		//$key 					= $this->uri->segment(4);
		if(!empty($key)){
			$data 				= $this->m_wawancara->GetPeriode($key)->result();
		}
		else{
			$data 				= $this->m_wawancara->GetKelengkapan()->result();
		}

		
		$santri = array();
		foreach ($data as $row) {
			$cekupload			= $this->m_wawancara->cekKelengkapan($row->id);
			if(!empty($cekupload)){
              $total_supload = $this->m_wawancara->TotalUpload($row->id);
              if($total_supload>7){
              	array_push($santri, $row->id);
              }
            }
		}

		$ambil 					= $this->m_wawancara->DataWawancara()->result();
		$swawancara = array();
		$bwawancara = array();
		foreach ($santri as $row) {
			$ceknilai			= $this->m_wawancara->GetWawancara($row)->num_rows();
			if(!empty($ceknilai)){
              $total_isian = $this->m_wawancara->tWawancara($row);
              if($total_isian<>0){
              	array_push($swawancara, $row);
              }
              else{
              	array_push($bwawancara, $row);
              }
            }
		}

		$isi['total'] 			= count($santri);
		$isi['sudahwawancara']	= count($swawancara);
		$isi['belumwawancara']	= count($bwawancara);
		$this->load->view('v_home',$isi);
	}

}

/* End of file c_wawancara.php */
/* Location: ./application/controllers/muq/c_wawancara.php */