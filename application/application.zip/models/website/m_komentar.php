<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_komentar extends CI_Model {

	public function GetKomentarArtikel(){
        $query=$this->db->query("SELECT t_kategori_artikel.`nama_kategori`,t_artikel.`id`,t_artikel.`judul_artikel`
                                 FROM t_artikel INNER JOIN t_kategori_artikel
                                 ON t_artikel.`id_kategori`=t_kategori_artikel.`id`");  
        return $query;      
    }

    public function GetKomentarDetail($key){
        $query=$this->db->query("SELECT t_artikel.`judul_artikel`, t_komentar.`id`,t_komentar.`nama`,t_komentar.`email`,
                                        t_komentar.`komentar`,t_komentar.`tanggal`,t_komentar.`status`,t_komentar.`jam`,
                                        t_komentar.`id_artikel`
                                 FROM t_komentar INNER JOIN t_artikel
                                 ON (t_komentar.`id_artikel`=t_artikel.`id`)
                                 WHERE t_artikel.`id`=$key");  
        return $query;      
    }

    public function GetJudulArtikel($key){
        $query=$this->db->query("SELECT judul_artikel 
                                 FROM t_artikel
                                 WHERE id=$key");
        foreach ($query->result() as $row){
            $judul_artikel = $row->judul_artikel;        
        }
        return $judul_artikel;
    }

    public function GetArtikel(){
        $query=$this->db->query("SELECT id,judul_artikel 
                                 FROM t_artikel");
        return $query;
    }

    public function GetTotalKomentar($kode){
        $query=$this->db->query("SELECT COUNT(*) as total
                                 FROM t_komentar
                                 WHERE id_artikel=$kode");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_komentar',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_komentar',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_komentar');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_komentar',$data);
    }
}
