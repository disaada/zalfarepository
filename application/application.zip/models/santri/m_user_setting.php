<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user_setting extends CI_Model {

	public function GetData($key=NULL){
		$this->db->where('username', $key);
		$query = $this->db->get('t_user');
		return $query;
	}

	public function GetInsert($key=NULL, $data=NULL){
		$this->db->where('username', $key);
		$query = $this->db->update('t_user', $data);
		return $query;
	}	

}

/* End of file m_user_setting.php */
/* Location: ./application/models/santri/m_user_setting.php */