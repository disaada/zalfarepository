<?php 
    $info 	= $this->session->flashdata('info');  
    $jdl          = htmlentities(strip_tags($judul_artikel)); 
    $judulartikel = substr($jdl,0,50); // ambil sebanyak 180 karakter
    $judulartikel = substr($jdl,0,strrpos($judulartikel," ")); // potong per spasi kalimat     
    if(!empty($info)){
?>
    <?php 
        switch($info) {
          case 'tambah' :
            echo '<div class="notif" style="display:none" >
                    <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                      <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                    </div> 
                  </div>  ';        
          break;
          case 'edit' :
            echo '<div class="notif" style="display:none" >
                    <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                      <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                    </div> 
                  </div>';           
          break;
          case 'hapus' :
            echo '<div class="notif" style="display:none" >
                    <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                      <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                    </div> 
                  </div';           
          break;
        } 
    ?>       
<?php
    }
?>
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
          <ol class="breadcrumb">
            <li><h3 class="title"><?php echo strtoupper($sub_judul); ?></h3></li>
            <li><a href="<?php echo base_url();?>index.php/c_home">dashboard</a></li>
            <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
            <li class="active"><?php echo $sub_judul; ?></li>
          </ol>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
          </ul>
        <div class="panel-body table-responsive">
        	 <div class="btn-group" role="group" aria-label="...">
              <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i></a>
        	    <a class="btn btn-light"><i class="fa fa-file-text"></i><b><?php echo $judulartikel; ?> </b></a>
              <a href="#" class="btn btn-light" data-toggle="modal" data-target="#balas">
              <i class="fa fa-comments-o"></i>Balas</a>
              
              <!--<button type="button" class="btn btn-light" id="deleteTriger"><i class="fa fa-trash"></i>Delete</button>-->
              <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" type="button" class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>        	 
              <!--<a href="cetak/cetak-data-guru.php" target="_blank" type="button" class="btn btn-light"><i class="fa fa-file-pdf-o"></i>Print All</a>-->

            </div>
          
            <hr>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap </th>
                            <th>Email</th>
                            <th>Komentar</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Status</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </thead>                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap </th>
                            <th>Email</th>
                            <th>Komentar</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Status</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                      <?php
                        $no = 1;                                                
                        foreach ($data->result() as $row){
                          $kode           = $row->id;
                          $status = $row->status;
                          if($status=='Menunggu'){
                            $stat       = 'Menunggu';
                            $stat_color = 'danger';
                            $stat_lain  = 'Diterima';
                          }else{
                            $stat       = 'Diterima';
                            $stat_color = 'default';
                            $stat_lain  = 'Menunggu';
                          }   
                      ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row->nama ?></td>
                            <td><?php echo $row->email ?></td>
                            <td><?php echo $row->komentar ?></td>
                            <td><?php echo $row->tanggal ?></td>
                            <td><?php echo $row->jam ?></td>
                            <td style='text-align: center;'>
                              <div class="dropdown">
                                <button class="btn btn-<?php echo $stat_color; ?> btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                                  <?php echo $stat ?>
                                  <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                  <li role="presentation">
                                    <a role="menuitem" tabindex="-1" 
                                       href="<?php echo base_url();?>index.php/website/c_komentar_detail/stat_data/<?php echo $stat_lain ?>/<?php echo $row->id ?>/<?php echo $row->id_artikel ?>">
                                        <?php echo $stat_lain ?>
                                    </a>
                                  </li>
                                </ul>
                              </div>                              
                            </td>
                            <td style='width: 13%'>                                
                                <a id="<?php echo $row->id ?>"  href="#hapus_detail_komentar<?php echo $row->id; ?>" 
                                   data-toggle="modal"  class='btn btn-sm btn-light' title='Hapus'><i class='fa fa-trash'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="hapus_detail_komentar<?php echo $row->id; ?>" 
                                   tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Hapus <?php echo $sub_judul  ?></h4>
                                      </div>
                                      <div class="modal-body">                                        
                                          Apakah anda yakin ingin menghapus data ini ?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <a class="btn-default btn" href="<?php echo base_url();?>index.php/website/c_komentar_detail/hapus_data/<?php echo $row->id; ?>/<?php echo $row->id_artikel; ?>"><i class='fa fa-trash-o'></i>&nbsp;Hapus</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>
                        </tr>      
                        <?php 
                            }
                        ?> 
                    </tbody>
                </table>  
                <!-- Modal -->
                  <div class="modal fade" id="balas" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog ">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
                        </div>
                        <div class="modal-body">
                          <form method="post" class="form-horizontal" action="<?php echo base_url();?>index.php/website/c_komentar_detail/tambah_data">
                            <input type="hidden" name="id" value="<?php echo $row->id ?>">  
                            <input type="hidden" name="id_artikel" value="<?php echo $row->id_artikel ?>">  
                            <div class="form-group">
                              <label class="control-label col-lg-3">balas Komentar</label>
                              <div class="col-lg-9">
                               <textarea name='komentar' placeholder="Tulis komentar ..."  
                                         style="width:100%;" class="form-control" required></textarea>
                              </div>
                            </div>     
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">
                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                          <button type="submit" class="btn-success btn">
                            <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>
                       
      </div>
    </div>
  </div>
</div>