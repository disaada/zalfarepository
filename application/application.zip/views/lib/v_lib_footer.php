<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © 2016 <a href="https://www.facebook.com/irobby.moeslim" target="_blank">Mahad Usyaqil Quran</a> All rights reserved.
  </div>
  <div class="col-md-6 text-right">
    Developed by <a href="https://www.facebook.com/irobby.moeslim" target="_blank">MUQ IT</a>
  </div> 
</div>
<!-- End Footer -->