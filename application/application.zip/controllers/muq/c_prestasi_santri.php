<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_prestasi_santri extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_prestasi_santri');
		$getquerytable		= $this->m_prestasi_santri->GetDataSantri();
		$isi['content'] 	= 'muq/v_prestasi_santri';
		$isi['base_link'] 	= 'muq/c_prestasi_santri';
		$isi['judul'] 		= 'Riwayat prestasi Santri';
		$isi['sub_judul'] 	= 'Data Riwayat prestasi Santri';
		$isi['data'] 		= $getquerytable;	
		
		$this->load->view('v_home',$isi);
	}

	public function tambah()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_prestasi_santri');
		$isi['content'] 			= 'muq/v_form_prestasi';
		$isi['back_link'] 			= 'muq/c_prestasi_santri';
		$isi['base_link'] 			= 'muq/c_prestasi_santri/tambah';
		$isi['option'] 				= 'tambah';
		$isi['judul'] 				= 'Data Riwayat prestasi Santri';
		$isi['sub_judul'] 			= 'Tambah Data Riwayat Santri';
		$isi['id'] 					= '';
		$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
		$isi['prestasi'] 			= ''; $isi['instansi']			= '';
		$isi['getData']				= $this->m_prestasi_santri->GetDataSantri()->result();
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_prestasi_santri');		
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'muq/v_form_prestasi';
		$isi['back_link'] 		= 'muq/c_prestasi_santri';
		$isi['base_link'] 		= 'muq/c_prestasi_santri/edit/'.$key.'';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Riwayat prestasi Santri';
		$isi['sub_judul'] 		= 'Edit Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_prestasi 
                                 WHERE id_pendaftaran=".$key."
                                ");
		$useQuery = $query->result();
		if($query->num_rows()>0)
		{
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_prestasi_santri->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('muq/c_prestasi_santri/tambah','refresh');
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran			  	 		= $this->input->post('id_pendaftaran');
	    $data['prestasi']  			 		= $this->input->post('prestasi');
	    $data['tahun']    					= $this->input->post('tahun');
	    $data['instansi']    				= $this->input->post('instansi');

	    $this->load->model('muq/m_prestasi_santri');

		if(!$id_pendaftaran=="" || empty($data)){
			for ($i=0; $i < count($data['prestasi']) ; $i++) { 
		    	$insert['id_pendaftaran']= $id_pendaftaran;
			    $insert['prestasi']      = $data['prestasi'][$i];
			    $insert['tahun']         = $data['tahun'][$i];
			    $insert['instansi']      = $data['instansi'][$i];
		    	$this->m_prestasi_santri->GetInsert($insert);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('muq/c_prestasi_santri');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('muq/c_prestasi_santri/tambah');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id');
		$data['prestasi']  	 				= $this->input->post('prestasi');
	    $data['instansi']  				 	= $this->input->post('instansi');
	    $data['tahun']       				= $this->input->post('tahun');

	    for ($i=0; $i < count($data['prestasi']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['prestasi']  			 	= $data['prestasi'][$i];
		    $insert['tahun']    				= $data['tahun'][$i];
		    $insert['instansi']    				= $data['instansi'][$i];

	    	$this->load->model('muq/m_prestasi_santri');
			$this->m_prestasi_santri->GetUpdate($data['id'][$i],$insert);
	    }
		
		$this->session->set_flashdata('info','edit');
		redirect('muq/c_prestasi_santri');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_prestasi_santri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_prestasi_santri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('muq/c_prestasi_santri');
		}		
		
	}

}

/* End of file c_riwayat_santri.php */
/* Location: ./application/controllers/muq/c_riwayat_santri.php */