<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user_data extends CI_Model {

	public function GetAktifSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.*,
                                        t_asrama.`nama_asrama`,
                                        t_jenis_santri.`jenis_santri`,
                                        t_santri.`tgl_masuk`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_asrama ON t_santri.`id_asrama`=t_asrama.`id` 
                                INNER JOIN t_jenis_santri ON t_santri.`id_jenis_santri`=t_jenis_santri.`id` 
                                ");
        return $query;
    }

    public function GetEditSantri($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.*,
                                        t_asrama.`nama_asrama`,
                                        t_jenis_santri.`jenis_santri`,
                                        t_santri.`tgl_masuk`,
                                        t_santri.`id_asrama`,
                                        t_santri.`id_jenis_santri`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_asrama ON t_santri.`id_asrama`=t_asrama.`id` 
                                INNER JOIN t_jenis_santri ON t_santri.`id_jenis_santri`=t_jenis_santri.`id` 
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function GetDataSantri(){
        $query=$this->db->query("SELECT * FROM t_pendaftaran_santri WHERE status='0'");
        return $query;
    }

    public function GetDataMukim($where=null){
        if($where)
            $this->db->where('id',$key);
        $hasil = $this->db->get('t_asrama');
        return $hasil;
    }

    public function GetJenisSantri($where=null){
        if($where)
            $this->db->where('id',$key);
        $hasil = $this->db->get('t_jenis_santri');
        return $hasil;
    }

    public function GetData($key){
        $this->db->where('notelp',$key);
        $hasil = $this->db->get('t_pendaftaran_santri');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pendaftaran_santri',$data);
    }

    public function GetUpdateSantri($key,$data){
            $this->db->where('id_pendaftaran',$key);
            $this->db->update('t_santri',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_pendaftaran_santri');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_santri',$data);
    }

}

/* End of file m_user_data.php */
/* Location: ./application/models/muq/m_user_data.php */