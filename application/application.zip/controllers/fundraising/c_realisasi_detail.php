<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_realisasi_detail extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    //hak akses
    /*=========================
      1 : super admin
      39  : admin
      40  : keuangan
      41  : editor
      42  : sekretaris
    ==========================*/
    $this->m_squrity->check_access(array('1','40','39'));
  }

  public function index()
  {   
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_realisasi');
    $key = $this->uri->segment(4);
    $getquerytable        = $this->m_realisasi->GetRealisasiDetail($key);
    $getperiode           = $this->m_realisasi->GetPeriode($key);
    $getkebutuhan         = $this->m_realisasi->GetKebutuhan($key);

    $isi['content']       = 'fundraising/v_realisasidetail';
    $isi['base_link']     = 'fundraising/c_realisasi_detail/index/'.$key.'';
    $isi['link_back']     = 'fundraising/c_realisasi';
    $isi['judul']         = 'Fundraising';
    $isi['sub_judul']     = 'Detail Realisasi Kebutuhan';
    $isi['data']          = $getquerytable;
    $isi['data_kebutuhan']= $getkebutuhan;
    $isi['periode']       = $getperiode;
    $isi['id']            = $key;
    //$isi['total']         = $this->m_kebutuhan->GettotKebutuhan($key);

    $data['total_realisasi']  = $this->m_realisasi->GettotRealisasi($key);
    $this->m_realisasi->GetUpdateReali($key,$data);

    $this->load->view('v_home',$isi);
  }
  public function tambah_data()
  {
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_realisasi');
    $realisasi2                   = $this->input->post('realisasi_kebutuhan_2');
    $selectid                     = $this->input->post('realisasi_kebutuhan');

    $data['id_fundraising']       = $this->input->post('id_fundraising');    
    if(!empty($realisasi2)){
      $data['realisasi_kebutuhan']= $realisasi2;
    }else{
      $data['realisasi_kebutuhan']= $this->m_realisasi->GetSelectKebutuhan($selectid);
    }
    $data['nominal']              = $this->input->post('nominal');
    $data['tgl_realisasi']        = $this->input->post('tgl_realisasi');
    $data['keterangan']           = $this->input->post('keterangan');
    $id                           = $this->input->post('id_fundraising');
    $this->load->model('fundraising/m_realisasi');
    $this->m_realisasi->GetInsert($data);
    $this->session->set_flashdata('info','tambah');
    redirect('fundraising/c_realisasi_detail/index/'.$id.'');
  }

  public function edit_data()
  {
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_realisasi');
    $realisasi2  = $this->input->post('realisasi_kebutuhan_2');
    $selectid                     = $this->input->post('realisasi_kebutuhan');

    $key                          = $this->input->post('id');
    $data['id_fundraising']       = $this->input->post('id_fundraising');
    if(!empty($realisasi2)){
      $data['realisasi_kebutuhan']= $realisasi2;
    }else{
      $data['realisasi_kebutuhan'] = $this->m_realisasi->GetSelectKebutuhan($selectid);
    }
    $data['nominal']              = $this->input->post('nominal');
    $data['keterangan']           = $this->input->post('keterangan');
    $data['tgl_realisasi']        = $this->input->post('tgl_realisasi');
    $id                           = $this->input->post('id_fundraising');

    $this->load->model('fundraising/m_realisasi');
    $this->m_realisasi->GetUpdate($key,$data);
    $this->session->set_flashdata('info','edit');
    redirect('fundraising/c_realisasi_detail/index/'.$id.'');   
  }

  public function hapus_data()
  {
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_realisasi');

    $key    = $this->uri->segment(4);
    $id     = $this->uri->segment(5);
    $this->db->where('id',$key);
    $query = $this->db->get('t_realisasi');
    if($query->num_rows()>0){
      $this->m_realisasi->GetDelete($key);
      $this->session->set_flashdata('info','hapus');
      redirect('fundraising/c_realisasi_detail/index/'.$id.'');
    }   
    
  }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */