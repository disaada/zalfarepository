  <div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $sub_judul ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo  $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>-->
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
           <a href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri/mypdf/<?php echo $id; ?>" 
           class="btn btn-light"><i class="fa fa-file-pdf-o"></i>Print PDF</a>
      </div>
    </div>
  </div>
<style>
  table.borderless td,table.borderless th, table.borderless tr{
     border: none !important;
  }
  hr{
    margin:0;
     padding:0;
  }
</style>
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title text-center">
          <h4>I. <?php echo $sub_judul; ?></h4>
        </div>
        <div class="panel-body">
          <table class="borderless trhead" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
              <tr>
                <td colspan="3">
                  <h6><strong>A. KETERANGAN DATA DIRI SANTRI</strong></h6>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="25%">1. Nama Lengkap</td>
                <td width="2%">:</td>
                <td><?php echo $nama_santri; ?></td>
              </tr>
              <tr>
                <td width="25%">2. Tempat dan Tanggal Lahir</td>
                <td width="2%">:</td>
                <td><?php echo $tempat_lahir; ?>, <?php echo tgl_indo($tgl_lahir); ?></td>
              </tr>
              <tr>
                <td width="25%">3. Jenis Kelamin</td>
                <td width="2%">:</td>
                <td><?php echo $jk; ?></td>
              </tr>
              <tr>
                <td width="25%">4. No Telepon</td>
                <td width="2%">:</td>
                <td><?php echo $notelp; ?></td>
              </tr>
              <tr>
                <td width="25%">5. Email</td>
                <td width="2%">:</td>
                <td><?php echo $email; ?></td>
              </tr>
              <tr>
                <td width="25%">6. Alamat Lengkap</td>
                <td width="2%">:</td>
                <td><?php echo $alamat_santri; ?></td>
              </tr>
              <tr>
                <td width="25%">7. Pendidikan Terakhir</td>
                <td width="2%">:</td>
                <td><?php echo $pendidikan_terakhir; ?></td>
              </tr>
              <tr>
                <td colspan="3">
                  <h6><strong>B. KETERANGAN DATA KELUARGA</strong></h6>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="25%">8. Nama Ayah</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ayah; ?></td>
              </tr>
              <tr>
                <td width="25%">9. Nama Ibu</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ibu; ?></td>
              </tr>
              <tr>
                <td width="25%">10. Nama Wali</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ortu_wali; ?></td>
              </tr>
              <tr>
                <td width="25%">11. No Telepon Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $notelp_ortu; ?></td>
              </tr>
              <tr>
                <td width="25%">12. Alamat Lengkap Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $alamat_ortu; ?></td>
              </tr>
              <tr>
                <td width="25%">13. Pendidikan Terakhir</td>
                <td width="2%">:</td>
                <td><?php echo $pendidikan_terakhir_ortu; ?></td>
              </tr>
              <tr>
                <td colspan="3">
                  <h6><strong>C. KETERANGAN DATA TAMBAHAN</strong></h6>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="25%">14. Golongan Darah</td>
                <td width="2%">:</td>
                <td><?php echo $goldar; ?></td>
              </tr>
              <tr>
                <td width="25%">15. Anak Ke</td>
                <td width="2%">:</td>
                <td><?php echo $anakke; ?> dari <?php echo $saudara; ?> saudara</td>
              </tr>
              <tr>
                <td width="25%">16. Pekerjaan Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $pekerjaan_ortu; ?></td>
              </tr>
              <tr>
                <td width="25%">17. Penghasilan Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $penghasilanortuperbulan; ?> Juta</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="panel panel-default">
        <div class="panel-title text-center">
          <h4>II. DATA DETAIL RIWAYAT PENDIDIKAN</h4>
        </div>
        <div class="panel-body">
          <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="0">
            <thead>
              <th>No</th>
              <th>Tingkat</th>
              <th>Nama Sekolah</th>
              <th>Jurusan</th>
              <th>No. Ijazah</th>
              <th>Tahun Lulus</th>
            </thead>

            <tbody>
              <?php $nomor = 1;
              foreach ($pendidikan->result() as $data_pend) { ?>
                  <tr>
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data_pend->tingkat; ?></td>
                    <td><?php echo $data_pend->nama_sekolah; ?></td>
                    <td><?php echo $data_pend->jurusan; ?></td>
                    <td><?php echo $data_pend->no_ijazah; ?></td>
                    <td><?php echo $data_pend->tahun; ?></td>
                  </tr>
              <?php $nomor++; } ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="panel panel-default">
        <div class="panel-title text-center">
          <h4>III. DATA DETAIL RIWAYAT PENDIDIKAN</h4>
        </div>
        <div class="panel-body">
          <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="0">
            <thead>
              <th>No</th>
              <th>Prestasi</th>
              <th>Instansi Penyelenggara</th>
              <th>Tahun</th>
            </thead>

            <tbody>
              <?php $nomor = 1;
              foreach ($prestasi->result() as $data_prestasi) { ?>
                  <tr>
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data_prestasi->prestasi; ?></td>
                    <td><?php echo $data_prestasi->instansi; ?></td>
                    <td><?php echo $data_prestasi->tahun; ?></td>
                  </tr>
              <?php $nomor++; } ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="panel panel-default">
        <div class="panel-title text-center">
          <h4>IV. DATA DETAIL PENGALAMAN BERORGANISASI</h4>
        </div>
        <div class="panel-body">
          <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="0">
            <thead>
              <th>No</th>
              <th>Organisasi</th>
              <th>Jabatan</th>
              <th>Awal Jabatan</th>
              <th>Akhir Jabatan</th>
            </thead>

            <tbody>
              <?php $nomor = 1;
              foreach ($organisasi->result() as $data_organisasi) { ?>
                  <tr>
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data_organisasi->organisasi; ?></td>
                    <td><?php echo $data_organisasi->jabatan; ?></td>
                    <td><?php echo $data_organisasi->tahun_awal; ?></td>
                    <td><?php echo $data_organisasi->tahun_akhir; ?></td>
                  </tr>
              <?php $nomor++; } ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>    



