<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_riwayat_santri extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_riwayat_santri');
		$getquerytable		= $this->m_riwayat_santri->GetDataSantri();
		$isi['content'] 	= 'muq/v_riwayat_santri';
		$isi['base_link'] 	= 'muq/c_riwayat_santri';
		$isi['judul'] 		= 'Riwayat Pendidikan Santri';
		$isi['sub_judul'] 	= 'Data Riwayat Pendidikan Santri';
		$isi['data'] 		= $getquerytable;	
		
		$this->load->view('v_home',$isi);
	}

	public function tambah()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_riwayat_santri');
		$isi['content'] 			= 'muq/v_form_riwayat';
		$isi['back_link'] 			= 'muq/c_riwayat_santri';
		$isi['base_link'] 			= 'muq/c_riwayat_santri/tambah';
		$isi['option'] 				= 'tambah';
		$isi['judul'] 				= 'Data Riwayat Pendidikan Santri';
		$isi['sub_judul'] 			= 'Tambah Data Riwayat Santri';
		$isi['id'] 					= '';
		$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
		$isi['jurusan'] 			= ''; $isi['no_ijazah']			= '';
		$isi['pendidikan'] 			= ''; $isi['nama_pendidikan'] 	= '';
		$isi['getData']				= $this->m_riwayat_santri->GetDataSantri()->result();
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_riwayat_santri');		
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'muq/v_form_riwayat';
		$isi['back_link'] 		= 'muq/c_riwayat_santri';
		$isi['base_link'] 		= 'muq/c_riwayat_santri/edit/'.$key.'';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Riwayat Pendidikan Santri';
		$isi['sub_judul'] 		= 'Edit Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_riwayat_pendidikan 
                                 WHERE id_pendaftaran=".$key."
                                ");
		$useQuery = $query->result();
		if($query->num_rows()>0)
		{
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_riwayat_santri->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('muq/c_riwayat_santri/tambah','refresh');
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran			  	 			= $this->input->post('id_pendaftaran');
	    $data['nama']  			 			= $this->input->post('nama');
	    $data['tahun']    					= $this->input->post('tahun');
	    $data['tingkat']    				= $this->input->post('tingkat');
	    $data['no_ijazah']    				= $this->input->post('no_ijazah');
	    $data['jurusan']    				= $this->input->post('jurusan');

	    $this->load->model('muq/m_riwayat_santri');

		if(!$id_pendaftaran=="" || empty($data)){
			for ($i=0; $i < count($data['nama']) ; $i++) { 
		    	$insert['id_pendaftaran']  	 			= $id_pendaftaran;
			    $insert['nama']  			 		= $data['nama'][$i];
			    $insert['tahun']    				= $data['tahun'][$i];
			    $insert['tingkat']    				= $data['tingkat'][$i];
			    $insert['no_ijazah']    			= $data['no_ijazah'][$i];
			    $insert['jurusan']    				= $data['jurusan'][$i];
		    	$this->m_riwayat_santri->GetInsert($insert);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('muq/c_riwayat_santri');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('muq/c_riwayat_santri/tambah');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id');
		$data['nama']  	 					= $this->input->post('nama');
	    $data['jurusan']  				 	= $this->input->post('jurusan');
	    $data['tingkat'] 	         		= $this->input->post('tingkat');
	    $data['tahun']       				= $this->input->post('tahun');
	    $data['no_ijazah']     				= $this->input->post('no_ijazah');

	    for ($i=0; $i < count($data['nama']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['nama']  			 		= $data['nama'][$i];
		    $insert['tahun']    				= $data['tahun'][$i];
		    $insert['tingkat']    				= $data['tingkat'][$i];
		    $insert['no_ijazah']    			= $data['no_ijazah'][$i];
		    $insert['jurusan']    				= $data['jurusan'][$i];

	    	$this->load->model('muq/m_riwayat_santri');
			$this->m_riwayat_santri->GetUpdate($data['id'][$i],$insert);
	    }
		
		$this->session->set_flashdata('info','edit');
		redirect('muq/c_riwayat_santri');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_riwayat_santri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_riwayat_santri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('muq/c_riwayat_santri');
		}		
		
	}

}

/* End of file c_riwayat_santri.php */
/* Location: ./application/controllers/muq/c_riwayat_santri.php */