<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> -->     
        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
            <label for="Group User" class="control-label ">Pilih Tahun :</label>             
            <div class="btn-group" role="group" aria-label="...">

              <select style="width:497px" name="id_album" 
                          class="form-control selectpicker " 
                          data-style="btn-light input-sm"
                          tabindex="2" required>
                     <option value="">2016</option>
                       
                </select>

            </div><br>
            <hr>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Jumlah Kebutuhan</th>
                            <th>Biaya(Rp)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Jumlah Kebutuhan</th>
                            <th>Biaya(Rp)</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($data->result() as $row){
                          $periode    = $row->periode;
                          $key        = $row->id;
                          $Bulan      = $this->m_fundraising->NamaBulan($periode);
                          $jmlkbthn   = $this->m_kebutuhan->GetTotalKebutuhan($key);
                          $biayakbthn = number_format($this->m_kebutuhan->GetBiayaKebutuhan($key),2,',','.');
                          if($biayakbthn==Null){$biayakbthn=0;}
                        ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $Bulan ?></td>
                            <td ><?php echo $jmlkbthn ?></td>
                            <td>Rp. <?php echo $biayakbthn ?></td>
                            <td> 
                                <a href="<?php echo base_url();?>index.php/fundraising/c_kebutuhan_detail/index/<?php echo $key; ?>" type="button" 
                                   class="btn btn-light btn-sm"><i class="fa fa-hand-o-right"></i>Lihat data</a>   
                            </td>
                        </tr>
                        <?php 
                            }
                        ?>        
                    </tbody>
                </table>                         
            
        </div>
      </div>
    </div>
  </div><br><br><br><br><br>
