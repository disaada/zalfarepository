<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_kelengkapan_santri extends CI_Model {

	public function GetKelengkapan(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri");
        return $query;
    }

    public function cekKelengkapan($key){
        $this->db->where('id_pendaftaran',$key);
        $query = $this->db->get('t_kelengkapan_santri');
        
        $total = $query->num_rows();
        return $total;
    }

    public function TotalUpload($key){
        $query=$this->db->query("SELECT * FROM t_kelengkapan_santri WHERE id_pendaftaran=$key");
        $total = 0;
        foreach ($query->result() as $row){
            if(!empty($row->filefotoktp))$total++;
            if(!empty($row->filefotoijazah))$total++;        
            if(!empty($row->filefotosehat))$total++;        
            if(!empty($row->filefotoobat))$total++;        
            if(!empty($row->filefotoberwarna))$total++;        
            if(!empty($row->filefotosuratijin))$total++;        
            if(!empty($row->filefotoaktalahir))$total++;        
            if(!empty($row->filefotokk))$total++;        
            if(!empty($row->filefotopindahan))$total++;                
        }
        return $total;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_donatur');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id_pendaftaran',$key);
    		$this->db->update('t_kelengkapan_santri',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_kelengkapan_santri',$data);
    }
    
}

