<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_kategori_artikel extends CI_Model {

	public function GetKategoriArtikel(){
        $query=$this->db->query("SELECT * FROM t_kategori_artikel");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_kategori_artikel');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_kategori_artikel',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_kategori_artikel',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_kategori_artikel');
    }
}
