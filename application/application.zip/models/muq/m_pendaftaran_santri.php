<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pendaftaran_santri extends CI_Model {

	public function GetAktifSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`jk`,
                                        t_mukim.`tempat`,
                                        t_santri.`tanggal_masuk`,
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_mukim ON t_santri.`id_mukim`=t_mukim.`id`");
        return $query;
    }

    public function GetEditSantri($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.*,
                                        t_mukim.`tempat`,
                                        t_santri.`tanggal_masuk`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_mukim ON t_santri.`id_mukim`=t_mukim.`id` 
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function CheckUser($key=NULL){
        $query=$this->db->query("SELECT * FROM t_user
                                WHERE username=".$key);
        return $query;
    }

    public function GetPeriode(){
        $query=$this->db->query("SELECT t_periode_pendaftaran.`id`,
                                        t_periode_pendaftaran.`status`,
                                        t_periode_ajaran.`tahun_ajaran`,
                                        t_periode_ajaran.`semester`,
                                        t_rentang_daftar.`tgl_dibuka`,
                                        t_rentang_daftar.`tgl_ditutup`
                                FROM t_periode_pendaftaran 
                                INNER JOIN t_periode_ajaran ON t_periode_pendaftaran.`id_tahun_ajaran`=t_periode_ajaran.`id`
                                INNER JOIN t_rentang_daftar ON t_periode_pendaftaran.`id_rentang_daftar`=t_rentang_daftar.`id` 
                                WHERE t_periode_pendaftaran.`status`='Terpilih'");
        return $query;
    }

    public function GetDataSantri(){
        $query=$this->db->query("SELECT * FROM t_pendaftaran_santri WHERE status='0'");
        return $query;
    }

    public function GetDataMukim($where=null){
        if($where)
            $this->db->where('id',$key);
        $hasil = $this->db->get('t_mukim');
        return $hasil;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_donatur');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_pendaftaran_santri',$data);
    }

    public function GetInsert($data){
            $this->db->insert('t_pendaftaran_santri',$data);
    }

    public function GetInsertUser($data){
            $this->db->insert('t_user',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_pendaftaran_santri');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pendaftaran_santri',$data);
    }

}

/* End of file m_pendaftaran_santri.php */
/* Location: ./application/models/muq/m_pendaftaran_santri.php */