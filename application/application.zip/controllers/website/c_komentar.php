<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_komentar extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_komentar');
		$getquerytable		= $this->m_komentar->GetKomentarArtikel();
		$isi['content'] 	= 'website/v_komentar';
		$isi['base_link'] 	= 'website/c_komentar';
		$isi['judul'] 		= 'Pengaturan Website ';
		$isi['sub_judul'] 	= 'Komentar';
		$isi['data'] 		= $getquerytable;
		$this->load->view('v_home',$isi);
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */