<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_setting extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('43'));
		$this->m_squrity->getsqurity();
	}

	public function index()
	{		
		$isi['content'] 	= 'santri/v_user_setting';
		$isi['base_link'] 	= 'santri/c_user_setting';
		$isi['back_link'] 	= 'c_home';
		$isi['judul'] 		= 'Pengaturan Santri';
		$isi['sub_judul'] 	= 'Pengaturan Santri';

	
		$this->load->view('v_home',$isi);
	}

	public function edit_data(){
		$this->load->model('santri/m_user_setting');
		$user = $this->session->userdata('username');
		$getquerytable= $this->m_user_setting->GetData($user);
		$data         = $getquerytable->row_array();

		$lastpassword = $this->input->post('lastpassword');
		$newpassword  = $this->input->post('newpassword');
		$confpassword = $this->input->post('confpassword');		

		if(!empty($lastpassword) || !empty($newpassword) || !empty($confpassword)){
			if($data['password'] != md5($lastpassword)){
				$this->session->set_flashdata('info','last');
				redirect('santri/c_user_setting');
			}
			else if($newpassword != $confpassword){
				$this->session->set_flashdata('info','conf');
				redirect('santri/c_user_setting');
			}
			else{
				$insert['password'] = md5($confpassword);
				$this->m_user_setting->GetInsert($user, $insert);

				$this->session->set_flashdata('info','success');
				redirect('santri/c_user_setting');
			}
		}
		else{
			$this->session->set_flashdata('info','empty');
			redirect('santri/c_user_setting');
		}
	}

}

/* End of file c_user_setting.php */
/* Location: ./application/controllers/santri/c_user_setting.php */