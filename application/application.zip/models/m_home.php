<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_home extends CI_Model {

    public function GetHari(){
        $hari=date("w");
        switch ($hari){
            case 0 : $hari="Minggu";
                Break;
            case 1 : $hari="Senin";
                Break;
            case 2 : $hari="Selasa";
                Break;
            case 3 : $hari="Rabu";
                Break;
            case 4 : $hari="Kamis";
                Break;
            case 5 : $hari="Jum'at";
                Break;
            case 6 : $hari="Sabtu";
                Break;
        }
        return $hari;
    }
    
    public function GetJumlahGuser(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_group_users");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahUser(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_user");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahAlbum(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_album");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahGaleri(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_galeri");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahKvideo(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_kategori_video");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahVideo(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_video");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahKartikel(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_kategori_artikel");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahArtikel(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_artikel");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahKomentar(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_komentar");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetJumlahPesan(){
        $query=$this->db->query("SELECT COUNT(*) as total FROM t_pesan");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }
}
