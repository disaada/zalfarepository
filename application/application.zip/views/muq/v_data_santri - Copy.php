<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <?php 
        if(count($arSantri)==0){
          echo '<button class="btn btn-light" title="Tambah Data" disabled><i class="fa fa-plus"></i> Tambah Data</button>';
        }
        else{
          echo '<a href="#tambah_data" data-toggle="modal"  
                 class="btn btn-light" title="Tambah Data"><i class="fa fa-plus"></i> Tambah Data</a>';
        }
        ?>

        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="tambah_data" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
        </div>
        <div class="modal-body">                                        
         <form method="post" class="form-horizontal" 
                action="<?php echo base_url();?>index.php/muq/c_data_santri/tambah_data">

              <div class="form-group">
                  <label for="id_pendaftaran" class="control-label col-lg-3">Nama Santri</label>
                  <div class="col-lg-9">
                    <select name            ="id_pendaftaran" 
                            class           ="form-control selectpicker"
                            data-style      ="btn-light"
                            data-live-search="true">
                        <?php 
                          if(empty($id_pendaftaran)){
                            $nama_santri = '--- Pilih Santri ---'; 
                          }else
                            $nama_santri = $id_pendaftaran; 
                        ?>
                        <option value="<?php echo $id_pendaftaran ?>"><?php echo $nama_santri ?></option>
                        <?php
                            foreach ($arSantri as $row) {
                              $santri = $this->m_data_santri->GetDataSantri($row)->row_array();
                              echo "<option value='".$santri['id']."'>".$santri['nama_santri']."</option>";
                            }
                        ?>                              
                    </select> 
                  </div>
              </div>
              <div class="form-group">
                  <label for="id_jenis_santri" class="control-label col-lg-3">Jenis Santri</label>
                  <div class="col-lg-9">
                    <select name            ="id_jenis_santri" 
                            class           ="form-control selectpicker"
                            data-style      ="btn-light"
                            data-live-search="true">
                        <?php 
                          if(empty($id_jenis_santri)){
                            $jenis_santri = '--- Pilih Jenis Santri ---'; 
                          }else
                            $jenis_santri = $id_jenis_santri; 
                        ?>
                        <option value="<?php echo $id_jenis_santri ?>"><?php echo $jenis_santri ?></option>
                        <?php
                            foreach ($getJenis as $j_santri) {
                              print("<option value=\"$j_santri->id\">$j_santri->jenis_santri</option>");
                            }
                        ?>                              
                    </select> 
                  </div>
              </div>
              <div class="form-group">
                  <label for="id_asrama" class="control-label col-lg-3">Asrama</label>
                  <div class="col-lg-9">
                    <select name            ="id_asrama" 
                            class           ="form-control selectpicker"
                            data-style      ="btn-light"
                            data-live-search="true">

                        <?php 
                          if(empty($id_asrama)){
                            $tempat = '--- Pilih Asrama ---'; 
                          }else
                            $tempat = $id_asrama; 
                        ?>
                        <option value="<?php echo $id_asrama ?>"><?php echo $tempat ?></option>
                      <?php
                          foreach ($getMukim as $mukim) {
                            print("<option value=\"$mukim->id\">$mukim->nama_asrama</option>");
                          }
                      ?>                                  
                    </select> 
                  </div>
              </div>              
              <div class="form-group">
                  <label for="tgl_masuk" class="control-label col-lg-3">Tanggal Masuk</label>
                  <div class="col-lg-9">
                    <div class="input-prepend input-group">
                      <span class="add-on input-group-addon"><i class="fa fa-calendar"></i></span>
                      <input type="date" name="tgl_masuk" required class="form-control"> 
                    </div>
                  </div>
              </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">
              <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>

          <button type="submit" class="btn btn-primary">
              <i class="fa fa-save" title='tambah'></i>&nbsp;Tambah</button>
        </div>
      </form>
      </div>
    </div>
  </div>


<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th style='width: 17%'>Nama</th>
                            <th style='width: 15%'>Jenis Kelamin</th>
                            <th style='width: 15%'>Jenis Santri</th>
                            <th style='width: 20%'>Tanggal Masuk</th>
                            <th>Asrama</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </thead>
                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th style='width: 17%'>Nama</th>
                            <th style='width: 15%'>Jenis Kelamin</th>
                            <th style='width: 15%'>Jenis Santri</th>
                            <th style='width: 20%'>Tanggal Masuk</th>
                            <th>Asrama</th>
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                      <?php
                        $no=1;
                        foreach ($data->result() as $row){
                        ?>  
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $row->nama_santri; ?></td>
                            <td><?php echo $row->jk; ?></td>  
                            <td><?php echo $row->jenis_santri; ?></td>  
                            <td><?php echo tgl_indo($row->tgl_masuk); ?></td>  
                            <td><?php echo $row->nama_asrama; ?></td> 
                            <td>
                                <a href="<?php echo base_url();?>index.php/muq/c_data_santri/edit/<?php echo $row->id; ?>" 
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-pencil'></i></a>
                                
                                <a id="<?php echo $row->id ?>"  href="#hapus_artikel<?php echo $row->id; ?>" data-toggle="modal"  
                                   class='btn btn-sm btn-light' title='Hapus'><i class='fa fa-trash'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="hapus_artikel<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Hapus <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">                                        
                                          Apakah anda yakin ingin menghapus data ini ?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <a class="btn-default btn" href="<?php echo base_url();?>index.php/muq/c_data_santri/hapus_data/<?php echo $row->id; ?>">
                                            <i class='fa fa-trash-o'></i>&nbsp;Hapus
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>  
                        </tr>
                        <?php
                            $no++; 
                            }
                        ?>           
                    </tbody>
                </table>   
        </div>
      </div>
    </div>
  </div>
  <br><br><br>
  <br><br><br>
  <br><br><br>
