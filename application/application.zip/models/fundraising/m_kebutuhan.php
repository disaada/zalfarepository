<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_kebutuhan extends CI_Model {

	public function GetPerkebutuhan(){
        $query=$this->db->query("SELECT * FROM t_kebutuhan");
        return $query;
    }

    public function GetKebutuhanDetail($key){
        $query=$this->db->query("SELECT * FROM t_kebutuhan where id_fundraising=$key");
        return $query;
    }

    public function GetidFundraising(){
        $query=$this->db->query("SELECT id FROM t_fundraising
                                 WHERE periode = DATE_FORMAT(NOW(),'%m-%Y')");
        return $query;
    }

    public function GettotKebutuhan($key){
        $query=$this->db->query("SELECT SUM(nominal) AS total 
                                 FROM t_kebutuhan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetPeriode($key){
        $query=$this->db->query("SELECT periode FROM t_fundraising where id=$key");
        foreach ($query->result() as $row){
            $periode = $row->periode;        
        }
        return $periode;
    }

    public function GetTotalKebutuhan($key){
        $query=$this->db->query("SELECT COUNT(*) AS total FROM t_kebutuhan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetBiayaKebutuhan($key){
        $query=$this->db->query("SELECT SUM(nominal) AS total FROM t_kebutuhan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function NamaBulan($periode){
        $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
     
        $bulan = substr($periode, 0, 2);
     
        $result = $BulanIndo[(int)$bulan-1];     
        return $result;
    }

    public function GetData($tanggal){
        $this->db->where('periode',$tanggal);
        $hasil = $this->db->get('t_fundraising');
        return $hasil;
    }

    public function GetInsert($data){
            $this->db->insert('t_kebutuhan',$data);
    }

    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_kebutuhan',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_kebutuhan');
    }

    public function GetUpdateKeb($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_fundraising',$data);
    }
}
