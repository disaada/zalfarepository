<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_video extends CI_Model {

	public function GetVideo(){
        $query=$this->db->query("SELECT t_kategori_video.`nama_kategori`,t_video.`id`,t_video.`tampilkan`,
                                           t_video.`id_kategori`,t_video.`judul_video`,t_video.`link`   
                                    FROM t_video INNER JOIN t_kategori_video
                                    ON t_video.`id_kategori`=t_kategori_video.`id`
                                ");
        return $query;
    }

    public function GetDataKvideo(){
        $query=$this->db->query("SELECT id,nama_kategori FROM t_kategori_video ORDER BY id");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_video');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_video',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_video',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_video');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_video',$data);
    }
}
