<?php
if ($option=='tambah'){
  $link_form='tambah_data';
}else
  $link_form='edit_data';
?>
  <div class="page-header">
    <h1 class="title"><?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>

<div class="container-default">
  <div class="row">

    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
           <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/website/c_artikel/<?php echo $link_form;?>"
                 enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $id; ?>">  
            <div class="panel-body">
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Judul Artikel</label>
                    <div class="col-lg-6">
                      <input  type="text" id="judul_artikel" name="judul_artikel"  class="form-control"
                              placeholder="Judul Artikel"
                              autofocus required
                              oninvalid="this.setCustomValidity('Judul Artikel harus di isi')"
                              oninput="setCustomValidity('')"  
                              value="<?php echo $judul_artikel; ?>"> 
                    </div>
              </div>
            </div>
             <div class="panel-body">
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Gambar</label>
                    <div class="col-lg-6">
                      <input type="file" name="filefoto" class="form-control">
                    </div>
              </div>
            </div>
            <div class="panel-body">
                <div class="form-group">
                  <label for="Group User" class="control-label col-lg-2">kategori Video</label>
                    <div class="col-lg-6">
                        <select style="width:397px" name="id_kategori" data-placeholder="Pilih Kategori ..." 
                                class="form-control selectpicker" 
                                data-style="btn-default"
                                tabindex="2" required>
                            <option value="<?php echo $id_kategori?>"><?php echo $nama_kategori ?></option>
                             <?php
                              foreach ($data_kategori->result() as $row_kategori){
                                 if ($nama_kategori==$row_kategori->nama_kategori)
                                  {
                                    continue;
                                  }
                                 echo "<option value= $row_kategori->id> $row_kategori->nama_kategori</option>";
                              }
                                          ?>
                            </select>
                    </div>
              </div>
            </div>
            <div class="panel-body">
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Isi Artikel</label>
                    <div class="col-lg-10">
                      <p>
                          <textarea name='isi_artikel' id="summernote" placeholder="Enter text ..."  style="height:200px; width:100%;">
                              <?php echo $isi_artikel; ?>
                          </textarea>
                      </p>
                    </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>    



