<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
        
        <div class="panel-body">
          <!-- <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/muq/c_wawancara/stat_data"
                 enctype="multipart/form-data"> -->
          <table class="table" id="example0">
            <thead>
              <th width="5%">No.</th>
              <th>Nama Santri</th>
              <th width="10%">Komitmen</th>
              <th width="10%">Motivasi</th>
              <th width="10%">Akhlak</th>
              <th width="10%">Komulatif</th>
              <th width="15%">Rata - Rata</th>
              <th width="15%">Opsi</th>
            </thead>

            <tfoot>
              <th width="5%">No.</th>
              <th>Nama Santri</th>
              <th width="10%">Komitmen</th>
              <th width="10%">Motivasi</th>
              <th width="10%">Akhlak</th>
              <th width="10%">Komulatif</th>
              <th width="15%">Rata - Rata</th>
              <th width="15%">Opsi</th>
            </tfoot>
          
          <?php 
            $nomor = 1;
            foreach ($santri as $key) {
              $status   = $key->status;
              
          ?>
            
            <tr>
              <input type="hidden" name="id_pendaftaran[]" value="<?php echo $key->pendaftaran_id; ?>">
              <td class="text-center"><?php echo $nomor; ?></td>
              <td><?php echo $key->nama_santri; ?></td>
              <td class="text-center"><?php echo $key->komitmen; ?></td>
              <td class="text-center"><?php echo $key->motivasi; ?></td>
              <td class="text-center"><?php echo $key->akhlak; ?></td>
              <td class="text-center"><?php echo $key->komulatif; ?></td>
              <td class="text-center"><?php echo $key->rata_rata; ?></td>
              <td>            
                <div class="dropdown">
        <?php
              $hasil = array(
                '0'  => array(
                          'status' => 'Diterima',
                          'url'    => 'Diterima'
                        ),
                '1'  => array(
                          'status' => 'Tidak Diterima',
                          'url'    => 'Tidak'
                        ),
                '2'  => array(
                          'status' => 'Menunggu Konfirmasi',
                          'url'    => 'Menunggu'
                        )
              );
       ?>
              <?php
                if ($status=='Diterima'){
                  $pilStatus = '<span class="label label-default">'.$status.'</span>';
                }
                else if ($status=='Tidak'){
                  $pilStatus = '<button class="btn btn-danger  btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                                  Tidak Diterima
                                  <span class="caret"></span>
                                </button>';
                }
                else if ($status=='Menunggu'){
                  $pilStatus = '<button class="btn btn-warning  btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                                  Menunggu Konfirmasi
                                  <span class="caret"></span>
                                </button>';
                }
                else{
                  $pilStatus = '<button class="btn btn-light  btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                                  -- Pilih Hasil --
                                  <span class="caret"></span>
                                </button>';
                }
                echo $pilStatus;
              ?>
                
                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
              <?php
                  foreach ($hasil as $row) {
                    echo '<li role="presentation">
                            <a role="menuitem" tabindex="-1" onclick="javascript: return confirm(\'Apakah anda yakin dengan perubahan status ini ?\')"
                              href="'.base_url().'index.php/muq/c_wawancara/stat_data/'.$row['url'].'/'.$key->id_pendaftaran.'">
                               '.$row['status'].'
                            </a>
                          </li>';
                  }
              ?>    
                </ul>
                </div>
              </td>
            </tr>

          <?php 
            $nomor++;
          } ?>

          </table>
        </div>

      </div>
    </div>
  </div>
</div>
