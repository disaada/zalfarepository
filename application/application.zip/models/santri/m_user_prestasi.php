<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user_prestasi extends CI_Model {

	public function GetDataSantri($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri  
                                WHERE t_pendaftaran_santri.`id` = ".$key);
        return $query;
    }

    public function GetDataPrestasi(){
        $query=$this->db->query("SELECT t_santri_prestasi.`id`,
                                        t_santri_prestasi.`id_pendaftaran`, 
                                        t_santri_prestasi.`prestasi`,
                                        t_santri_prestasi.`tahun`,
                                        t_santri_prestasi.`instansi`,
                                        t_pendaftaran_santri.`nama_santri`
                                 FROM t_santri_prestasi INNER JOIN t_pendaftaran_santri 
                                 ON t_santri_prestasi.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                 WHERE t_pendaftaran_santri.`id` = ".$key);
        return $query;
    }

    public function CountPrestasi($key){
        $this->db->where('id_pendaftaran',$key);
        $hasil = $this->db->get('t_santri_prestasi');
        return $hasil;
    }

    public function GetData($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,t_pendaftaran_santri.`nama_santri`
                                 FROM t_pendaftaran_santri INNER JOIN t_santri_prestasi 
                                 ON t_pendaftaran_santri.`id`=t_santri_prestasi.`id_pendaftaran`
                                 WHERE t_santri_prestasi.`id_pendaftaran`=".$key);
        return $query;
    }

    public function GetSession($key=NULL){
        $this->db->where('notelp',$key);
        $hasil = $this->db->get('t_pendaftaran_santri');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_santri_prestasi',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri_prestasi',$data);
    }
    public function GetInsertBatch($data){
    		$this->db->insert('t_santri_prestasi',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_santri_prestasi');
    }

}

/* End of file m_user_prestasi.php */
/* Location: ./application/models/santri/m_user_prestasi.php */