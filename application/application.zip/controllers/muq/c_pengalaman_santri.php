<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_pengalaman_santri extends CI_Controller {

	
	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_pengalaman_santri');
		$getquerytable		= $this->m_pengalaman_santri->GetDataSantri();
		$isi['content'] 	= 'muq/v_pengalaman_santri';
		$isi['base_link'] 	= 'muq/c_pengalaman_santri';
		$isi['judul'] 		= 'Pengalaman Berorganisasi Santri';
		$isi['sub_judul'] 	= 'Data pengalaman Organisasi Santri';
		$isi['data'] 		= $getquerytable;		
		$this->load->view('v_home',$isi);
	}

	public function tambah()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_pengalaman_santri');
		$isi['content'] 			= 'muq/v_form_pengalaman';
		$isi['back_link'] 			= 'muq/c_pengalaman_santri';
		$isi['base_link'] 			= 'muq/c_pengalaman_santri/tambah';
		$isi['option'] 				= 'tambah';
		$isi['judul'] 				= 'Data Pengalaman Organisasi Santri';
		$isi['sub_judul'] 			= 'Tambah Data Santri';
		$isi['id'] 					= '';
		$isi['id_pendaftaran'] 		= ''; $isi['tahun_awal'] 			= '';
		$isi['organisasi'] 			= ''; $isi['tahun_akhir']			= '';
		$isi['jabatan'] 			= ''; 
		$isi['getData']				= $this->m_pengalaman_santri->GetDataSantri()->result();
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_pengalaman_santri');		
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'muq/v_form_pengalaman';
		$isi['back_link'] 		= 'muq/c_pengalaman_santri';
		$isi['base_link'] 		= 'muq/c_pengalaman_santri/edit/'.$key.'';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Santri';
		$isi['sub_judul'] 		= 'Edit Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_p_organisasi 
                                 WHERE id_pendaftaran=".$key."
                                ");
		if($query->num_rows()>0)
		{
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_pengalaman_santri->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('muq/c_pengalaman_santri/tambah','refresh');
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran			  	 		= $this->input->post('id_pendaftaran');
	    $data['organisasi']  			 	= $this->input->post('organisasi');
	    $data['jabatan']    				= $this->input->post('jabatan');
	    $data['tahun_awal']    				= $this->input->post('tahun_awal');
	    $data['tahun_akhir']    			= $this->input->post('tahun_akhir');

	    $this->load->model('muq/m_pengalaman_santri');

	    if(!$id_pendaftaran=="" || $data==""){
		    for ($i=0; $i < count($data['organisasi']) ; $i++) { 
		    	$insert['id_pendaftaran']= $id_pendaftaran;
			    $insert['organisasi']    = $data['organisasi'][$i];
			    $insert['jabatan']       = $data['jabatan'][$i];
			    $insert['tahun_awal']    = $data['tahun_awal'][$i];
			    $insert['tahun_akhir']   = $data['tahun_akhir'][$i];
		    	$this->m_pengalaman_santri->GetInsert($insert);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('muq/c_pengalaman_santri');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('muq/c_riwayat_santri/tambah');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id');
		$data['organisasi']  	 			= $this->input->post('organisasi');
	    $data['tahun_awal']  				= $this->input->post('tahun_awal');
	    $data['tahun_akhir'] 	         	= $this->input->post('tahun_akhir');
	    $data['jabatan']       				= $this->input->post('jabatan');

	    for ($i=0; $i < count($data['organisasi']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['organisasi']  			 	= $data['organisasi'][$i];
		    $insert['jabatan']    				= $data['jabatan'][$i];
		    $insert['tahun_akhir']    			= $data['tahun_akhir'][$i];
		    $insert['tahun_awal']    			= $data['tahun_awal'][$i];

	    	$this->load->model('muq/m_pengalaman_santri');
			$this->m_pengalaman_santri->GetUpdate($data['id'][$i],$insert);
	    }
		
		$this->session->set_flashdata('info','edit');
		redirect('muq/c_pengalaman_santri');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_pengalaman_santri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_pengalaman_santri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('muq/c_pengalaman_santri');
		}		
		
	}

}

/* End of file c_pengalaman_santri.php */
/* Location: ./application/controllers/muq/c_pengalaman_santri.php */