<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li class="active"><?php echo $judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> --> 
      <?php if((date('Y-m-d') >= $periode['tgl_dibuka']) && (date('Y-m-d') < $periode['tgl_ditutup'])){ ?>    
         <a href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri/tambah" class="btn btn-light" ><i class="fa fa-plus"></i>Tambah Data</a>
      <?php } else{ ?>
         <a disabled class="btn btn-light" ><i class="fa fa-plus"></i>Tambah Data</a>
      <?php  } ?>
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
    <?php if((date('Y-m-d') >= $periode['tgl_dibuka']) && (date('Y-m-d') < $periode['tgl_ditutup'])){ ?>
      &nbsp;
    <?php } else{ ?>
      <div class="alert alert-warning"><h4>Pendaftaran santri akan dibuka pada <strong><?php echo tgl_indo($periode['tgl_dibuka']); ?></strong> dan berakhir pada <strong><?php echo tgl_indo($periode['tgl_ditutup']); ?></strong></h4></div>
    <?php } ?>
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th style='width: 17%'>Nama</th>
                            <th style='width: 25%'>Alamat</th>
                            <th style='width: 11%'>Np. Telp</th>
                            <th>Tanggal Daftar</th>
                            <th style='width: 20%'>Aksi</th>
                        </tr>
                    </thead>
                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>No. Telp</th>
                            <th>Tanggal Daftar</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                      <?php
                        $no=1;
                        foreach ($data->result() as $row){
                         
                        ?>  
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $row->nama_santri; ?></td>
                            <td><?php echo $row->alamat_pendaftaran_santri; ?></td>  
                            <td><?php echo $row->notelp; ?></td>  
                            <td><?php echo tgl_indo($row->tgl_daftar); ?></td> 
                            <td>
                                <a href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri/view/<?php echo $row->id; ?>" 
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-eye'></i></a>

                                <a href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri/edit/<?php echo $row->id; ?>" 
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-pencil'></i></a>
                                
                                <a id="<?php echo $row->id ?>"  href="#hapus_artikel<?php echo $row->id; ?>" data-toggle="modal"  
                                   class='btn btn-sm btn-light' title='Hapus'><i class='fa fa-trash'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="hapus_artikel<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Hapus <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">                                        
                                          Apakah anda yakin ingin menghapus data ini ?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <a class="btn-default btn" href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri/hapus_data/<?php echo $row->id; ?>">
                                            <i class='fa fa-trash-o'></i>&nbsp;Hapus
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>  
                        </tr>
                        <?php
                            $no++; 
                            }
                        ?>           
                    </tbody>
                </table>   
        </div>
      </div>
    </div>
  </div>
