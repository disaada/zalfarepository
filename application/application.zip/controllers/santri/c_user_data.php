<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_data extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('43'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_data');
		$user                      = $this->session->userdata('username');
		$getquerytable             = $this->m_user_data->GetData($user);
		$isi['content']            = 'santri/v_user_data';
		$isi['base_link']          = 'santri/c_user_data';
		$isi['back_link']          = 'santri/c_user_data/view';
		$isi['judul']              = 'Data Santri';
		$isi['pendidikan_terakhir']='';
		$isi['sub_judul']          = 'Data Pendaftaran Santri';
		$isi['data']               = $getquerytable->row_array();

		//print_r($isi['data']);		
		$this->load->view('v_home',$isi);
	}

	public function view()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_data');		
		$key 					= $this->session->userdata('username');
		$isi['content'] 		= 'santri/v_user_view';
		$isi['back_link'] 		= 'santri/c_user_data';
		$isi['base_link'] 		= 'santri/c_user_data/view/'.$key.'';
		$isi['option'] 			= 'view';
		$isi['judul'] 			= 'Data Pendaftaran Santri';
		$isi['sub_judul'] 		= 'Detail Data Pendaftaran Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_pendaftaran_santri 
                                 WHERE notelp=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				
				$isi['id']                      = $row->id;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tempat_lahir']            = $row->tempat_lahir;
				$isi['jk']                      = $row->jk;
				$isi['anakke']                  = $row->anakke;
				$isi['email_fb']                = $row->emailfb_santri;
				$isi['notelp']                  = $row->notelp;
				$isi['nama_ayah']               = $row->nama_ayah;
				$isi['pendidikan_terakhir']     = $row->pendidikan_terakhir_santri;
				$isi['email']                   = $row->email;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tgl_lahir']               = $row->tgl_lahir;
				$isi['goldar']                  = $row->goldar;
				$isi['notelp_ortu']             = $row->notelp_ortu;
				$isi['nama_ortu_wali']          = $row->nama_wali;
				$isi['nama_ibu']                = $row->nama_ibu;
				$isi['penghasilanortuperbulan'] = $row->penghasilanortuperbulan;
				$isi['pendidikan_terakhir_ortu']= $row->pendidikanterakhir_ortu;
				$isi['alamat_santri']           = $row->alamat_pendaftaran_santri;
				$isi['pekerjaan_ortu']          = $row->pekerjaan_ortu;
				$isi['alamat_ortu']             = $row->alamat_ortu;
				$isi['saudara']                 = $row->saudara;

			}
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('santri/c_user_data/view','refresh');
		}
		
	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data['nama_santri']  	 			= $this->input->post('nama_santri');
	    $data['tempat_lahir']  			 	= $this->input->post('tempat_lahir');
	    $data['tgl_lahir']          		= $this->input->post('tgl_lahir');
	    $data['jk']       					= $this->input->post('jk');
	    $data['goldar']     				= $this->input->post('goldar');
	    $data['anakke']   					= $this->input->post('anakke');
	    $data['saudara'] 		 			= $this->input->post('saudara');
	    $data['alamat_pendaftaran_santri']	= $this->input->post('alamat_pendaftaran_santri');
	    $data['alamat_ortu'] 	 			= $this->input->post('alamat_ortu');
	    $data['pendidikan_terakhir_santri'] = $this->input->post('pendidikan_terakhir_santri');
	    $data['nama_wali'] 				 	= $this->input->post('nama_wali');
	    $data['notelp_ortu'] 		 		= $this->input->post('notelp_ortu');
	    $data['pendidikanterakhir_ortu'] 	= $this->input->post('pendidikanterakhir_ortu');
	    $data['pekerjaan_ortu'] 		 	= $this->input->post('pekerjaan_ortu');
	    $data['nama_ayah'] 		 			= $this->input->post('nama_ayah');
	    $data['nama_ibu'] 		 			= $this->input->post('nama_ibu');
	    $data['penghasilanortuperbulan']    = $this->input->post('penghasilanortuperbulan');
	    $data['notelp']    					= $this->input->post('notelp');
	    $data['email']    					= $this->input->post('email');
	    $data['emailfb_santri']    			= $this->input->post('emailfb_santri');

		$this->load->model('santri/m_user_data');
		$this->m_user_data->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('santri/c_user_data');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_pendaftaran_santri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_pendaftaran_santri');
		if($query->num_rows()>0){
			$this->m_pendaftaran_santri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('santri/c_pendaftaran_santri');
		}		
		
	}

	function mypdf($key=NULL){
		$this->load->library('pdf');
		$query=$this->db->query("SELECT *   
                                 FROM t_pendaftaran_santri 
                                 WHERE id=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				
				$isi['id']                      = $key;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tempat_lahir']            = $row->tempat_lahir;
				$isi['jk']                      = $row->jk;
				$isi['anakke']                  = $row->anakke;
				$isi['email_fb']                = $row->emailfb_santri;
				$isi['notelp']                  = $row->notelp;
				$isi['nama_ayah']               = $row->nama_ayah;
				$isi['pendidikan_terakhir']     = $row->pendidikan_terakhir_santri;
				$isi['email']                   = $row->email;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tgl_lahir']               = $row->tgl_lahir;
				$isi['goldar']                  = $row->goldar;
				$isi['notelp_ortu']             = $row->notelp_ortu;
				$isi['nama_ortu_wali']          = $row->nama_wali;
				$isi['nama_ibu']                = $row->nama_ibu;
				$isi['penghasilanortuperbulan'] = $row->penghasilanortuperbulan;
				$isi['pendidikan_terakhir_ortu']= $row->pendidikanterakhir_ortu;
				$isi['alamat_santri']           = $row->alamat_pendaftaran_santri;
				$isi['pekerjaan_ortu']          = $row->pekerjaan_ortu;
				$isi['alamat_ortu']             = $row->alamat_ortu;
				$isi['saudara']                 = $row->saudara;

			}
			$nama = $query->row_array();
			$this->pdf->load_view('muq/print_pdf',$isi);
			$this->pdf->render();
			$this->pdf->stream($nama['nama_santri'].".pdf");
		}
		else{
			redirect('santri/c_user_data/view','refresh');
		}
	 }

}

/* End of file c_user_data.php */
/* Location: ./application/controllers/santri/c_user_data.php */