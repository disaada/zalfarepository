<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_pendaftaran_santri extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_data_santri');
		$this->load->model('muq/m_pendaftaran_santri');
		$getquerytable		= $this->m_data_santri->GetDataSantri();
		$isi['content'] 	= 'muq/v_pendaftaran_santri';
		$isi['base_link'] 	= 'muq/c_pendaftaran_santri';
		$isi['judul'] 		= 'Pendaftaran Santri';
		$isi['sub_judul'] 	= 'Data Pendaftaran Santri';
		$isi['data'] 		= $getquerytable;
		$isi['periode']		= $this->m_pendaftaran_santri->GetPeriode()->row_array();		
		$this->load->view('v_home',$isi);
	}

	public function tambah()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_data_santri');
		$isi['content'] 			= 'muq/v_form_pendaftaran';
		$isi['back_link'] 			= 'muq/c_pendaftaran_santri';
		$isi['base_link'] 			= 'muq/c_pendaftaran_santri/tambah';
		$isi['option'] 				= 'tambah';
		$isi['judul'] 				= 'Data Pendaftaran Santri';
		$isi['sub_judul'] 			= 'Tambah Data Pendaftaran Santri';
		$isi['id']					= '';$isi['nama_santri']    	= '';
		$isi['tempat_lahir']		= '';$isi['tgl_lahir']			= '';
		$isi['jk']					= '';$isi['goldar']				= '';
		$isi['anakke']				= '';$isi['saudara']			= '';
		$isi['email_fb']	        = '';$isi['notelp']				= '';
		$isi['notelp_ortu']			= '';$isi['nama_ortu_wali'] 	= '';
		$isi['pekerjaan_ortu']		= '';$isi['nama_ibu']			= '';
		$isi['nama_ayah']   		= '';$isi['penghasilanortuperbulan']	= '';
		$isi['pendidikan_terakhir'] = '';$isi['pendidikan_terakhir_ortu']	= '';
		$isi['email'] 				= '';$isi['alamat_santri']						= '';
		$isi['alamat_ortu']			= '';
		$this->load->view('v_home',$isi);
	}

	public function view()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_data_santri');		
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'muq/v_detail_pendaftaran';
		$isi['back_link'] 		= 'muq/c_pendaftaran_santri';
		$isi['base_link'] 		= 'muq/c_pendaftaran_santri/view/'.$key.'';
		$isi['option'] 			= 'view';
		$isi['judul'] 			= 'Data Pendaftaran Santri';
		$isi['sub_judul'] 		= 'Detail Data Pendaftaran Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_pendaftaran_santri 
                                 WHERE id=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				
				$isi['id']                      = $key;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tempat_lahir']            = $row->tempat_lahir;
				$isi['jk']                      = $row->jk;
				$isi['anakke']                  = $row->anakke;
				$isi['email_fb']                = $row->emailfb_santri;
				$isi['notelp']                  = $row->notelp;
				$isi['nama_ayah']               = $row->nama_ayah;
				$isi['pendidikan_terakhir']     = $row->pendidikan_terakhir_santri;
				$isi['email']                   = $row->email;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tgl_lahir']               = $row->tgl_lahir;
				$isi['goldar']                  = $row->goldar;
				$isi['notelp_ortu']             = $row->notelp_ortu;
				$isi['nama_ortu_wali']          = $row->nama_wali;
				$isi['nama_ibu']                = $row->nama_ibu;
				$isi['penghasilanortuperbulan'] = $row->penghasilanortuperbulan;
				$isi['pendidikan_terakhir_ortu']= $row->pendidikanterakhir_ortu;
				$isi['alamat_santri']           = $row->alamat_pendaftaran_santri;
				$isi['pekerjaan_ortu']          = $row->pekerjaan_ortu;
				$isi['alamat_ortu']             = $row->alamat_ortu;
				$isi['saudara']                 = $row->saudara;

			}
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('muq/c_pendaftaran_santri','refresh');
		}
		
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_data_santri');		
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'muq/v_form_pendaftaran';
		$isi['back_link'] 		= 'muq/c_pendaftaran_santri';
		$isi['base_link'] 		= 'muq/c_pendaftaran_santri/edit/'.$key.'';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Pendaftaran Santri';
		$isi['sub_judul'] 		= 'Edit Data Pendaftaran Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_pendaftaran_santri 
                                 WHERE id=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				
				$isi['id']                      = $key;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tempat_lahir']            = $row->tempat_lahir;
				$isi['jk']                      = $row->jk;
				$isi['anakke']                  = $row->anakke;
				$isi['email_fb']                = $row->emailfb_santri;
				$isi['notelp']                  = $row->notelp;
				$isi['nama_ayah']               = $row->nama_ayah;
				$isi['pendidikan_terakhir']     = $row->pendidikan_terakhir_santri;
				$isi['email']                   = $row->email;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tgl_lahir']               = $row->tgl_lahir;
				$isi['goldar']                  = $row->goldar;
				$isi['notelp_ortu']             = $row->notelp_ortu;
				$isi['nama_ortu_wali']          = $row->nama_wali;
				$isi['nama_ibu']                = $row->nama_ibu;
				$isi['penghasilanortuperbulan'] = $row->penghasilanortuperbulan;
				$isi['pendidikan_terakhir_ortu']= $row->pendidikanterakhir_ortu;
				$isi['alamat_santri']           = $row->alamat_pendaftaran_santri;
				$isi['pekerjaan_ortu']          = $row->pekerjaan_ortu;
				$isi['alamat_ortu']             = $row->alamat_ortu;
				$isi['saudara']                 = $row->saudara;

			}
			$this->load->view('v_home',$isi);
		}
		else{
			redirect('muq/c_pendaftaran_santri','refresh');
		}
		
	}

	
	public function tambah_data()
    {
    	$this->load->model('muq/m_pendaftaran_santri');
	    $this->m_squrity->getsqurity();
	    $getPeriod = $this->m_pendaftaran_santri->GetPeriode()->row_array();

	    $data['nama_santri']  	 			= $this->input->post('nama_santri');
	    $data['tempat_lahir']  			 	= $this->input->post('tempat_lahir');
	    $data['tgl_lahir']          		= $this->input->post('tgl_lahir');
	    $data['jk']       					= $this->input->post('jk');
	    $data['goldar']     				= $this->input->post('goldar');
	    $data['anakke']   					= $this->input->post('anakke');
	    $data['saudara'] 		 			= $this->input->post('saudara');
	    $data['alamat_pendaftaran_santri']	= $this->input->post('alamat');
	    $data['alamat_ortu'] 	 			= $this->input->post('alamat_ortu');
	    $data['pendidikan_terakhir_santri'] = $this->input->post('pendidikan_terakhir');
	    $data['nama_wali'] 				 	= $this->input->post('nama_ortu_wali');
	    $data['notelp_ortu'] 		 		= $this->input->post('notelp_ortu');
	    $data['pendidikanterakhir_ortu'] 	= $this->input->post('pendidikan_terakhir_ortu');
	    $data['pekerjaan_ortu'] 		 	= $this->input->post('pekerjaan_ortu');
	    $data['nama_ayah'] 		 			= $this->input->post('nama_ayah');
	    $data['nama_ibu'] 		 			= $this->input->post('nama_ibu');
	    $data['penghasilanortuperbulan']    = $this->input->post('penghasilanortuperbulan');
	    $data['notelp']    					= $this->input->post('notelp');
	    $data['email']    					= $this->input->post('email');
	    $data['emailfb_santri']    			= $this->input->post('email_fb');
	    $data['tgl_daftar']    				= date('Y-m-d');
	    $data['status']						= 0;
	    $data['id_periode']                 = $getPeriod['id'];

	    $password = "muq-".rand_passwd();
        $usernames = $this->input->post('notelp');
        $email = $this->input->post('email');

        //cek username
        $cek = $this->m_pendaftaran_santri->CheckUser($usernames);
        if($cek->num_rows()==0){
            //insert pendaftaran santri
        	$this->m_pendaftaran_santri->GetInsert($data);


            //create user santri
            $users['nama_user'] = $this->input->post('nama_santri');
            $users['username']  = $usernames;
            $users['id_group']  = '43';
            $users['password']  = md5($password);
            $users['status']    = 'aktif';
            $this->load->model('settings/m_users');
			$this->m_users->GetInsert($users);

            $this->load->model('muq/m_email');
            $this->m_email->sendMail($email,$usernames,$password);

            $this->session->set_flashdata('info','tambah');
            redirect('muq/c_pendaftaran_santri');
        }
        else{
            $this->session->set_flashdata('info','gagal');
            redirect('muq/c_pendaftaran_santri');
        }
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data['nama_santri']  	 			= $this->input->post('nama_santri');
	    $data['tempat_lahir']  			 	= $this->input->post('tempat_lahir');
	    $data['tgl_lahir']          		= $this->input->post('tgl_lahir');
	    $data['jk']       					= $this->input->post('jk');
	    $data['goldar']     				= $this->input->post('goldar');
	    $data['anakke']   					= $this->input->post('anakke');
	    $data['saudara'] 		 			= $this->input->post('saudara');
	    $data['alamat_pendaftaran_santri']	= $this->input->post('alamat');
	    $data['alamat_ortu'] 	 			= $this->input->post('alamat_ortu');
	    $data['pendidikan_terakhir_santri'] = $this->input->post('pendidikan_terakhir');
	    $data['nama_wali'] 				 	= $this->input->post('nama_ortu_wali');
	    $data['notelp_ortu'] 		 		= $this->input->post('notelp_ortu');
	    $data['pendidikanterakhir_ortu'] 	= $this->input->post('pendidikan_terakhir_ortu');
	    $data['pekerjaan_ortu'] 		 	= $this->input->post('pekerjaan_ortu');
	    $data['nama_ayah'] 		 			= $this->input->post('nama_ayah');
	    $data['nama_ibu'] 		 			= $this->input->post('nama_ibu');
	    $data['penghasilanortuperbulan']    = $this->input->post('penghasilanortuperbulan');
	    $data['notelp']    					= $this->input->post('notelp');
	    $data['email']    					= $this->input->post('email');
	    $data['emailfb_santri']    			= $this->input->post('email_fb');

		$this->load->model('muq/m_data_santri');
		$this->m_data_santri->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('muq/c_pendaftaran_santri');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_pendaftaran_santri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_pendaftaran_santri');
		if($query->num_rows()>0){
			$this->m_pendaftaran_santri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('muq/c_pendaftaran_santri');
		}		
		
	}

	function mypdf($key=NULL){
		$this->load->library('pdf');
		$query=$this->db->query("SELECT *   
                                 FROM t_pendaftaran_santri 
                                 WHERE id=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				
				$isi['id']                      = $key;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tempat_lahir']            = $row->tempat_lahir;
				$isi['jk']                      = $row->jk;
				$isi['anakke']                  = $row->anakke;
				$isi['email_fb']                = $row->emailfb_santri;
				$isi['notelp']                  = $row->notelp;
				$isi['nama_ayah']               = $row->nama_ayah;
				$isi['pendidikan_terakhir']     = $row->pendidikan_terakhir_santri;
				$isi['email']                   = $row->email;
				$isi['nama_santri']             = $row->nama_santri;
				$isi['tgl_lahir']               = $row->tgl_lahir;
				$isi['goldar']                  = $row->goldar;
				$isi['notelp_ortu']             = $row->notelp_ortu;
				$isi['nama_ortu_wali']          = $row->nama_wali;
				$isi['nama_ibu']                = $row->nama_ibu;
				$isi['penghasilanortuperbulan'] = $row->penghasilanortuperbulan;
				$isi['pendidikan_terakhir_ortu']= $row->pendidikanterakhir_ortu;
				$isi['alamat_santri']           = $row->alamat_pendaftaran_santri;
				$isi['pekerjaan_ortu']          = $row->pekerjaan_ortu;
				$isi['alamat_ortu']             = $row->alamat_ortu;
				$isi['saudara']                 = $row->saudara;

			}
			$nama = $query->row_array();
			$this->pdf->load_view('muq/print_pdf',$isi);
			$this->pdf->render();
			$this->pdf->stream($nama['nama_santri'].".pdf");
		}
		else{
			redirect('muq/c_pendaftaran_santri','refresh');
		}
	 }

}

/* End of file c_pendaftaran_santri.php */
/* Location: ./application/controllers/muq/c_pendaftaran_santri.php */