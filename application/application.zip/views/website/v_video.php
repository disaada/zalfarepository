<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> -->     
        <a href="#" class="btn btn-light" data-toggle="modal" data-target="#tambah_user"><i class="fa fa-plus"></i>Tambah Data</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
              <table id="example0" class="table display">
                    <thead>
                        <tr>
                           <th>No</th>  
                           <th>Judul Video</th>     
                           <th>kategori</th>            
                           <th>Link</th>
                           <th>Tampilkan</th>
                           <th style='text-align: center; width: 15%'>Aksi</th>
                        </tr>
                    </thead>                 
                    <tfoot>
                        <tr>
                           <th>No</th>  
                           <th>Judul Video</th> 
                           <th>Kategori</th>                  
                           <th>Link</th> 
                           <th>Tampilkan</th>    
                           <th style='text-align: center; width: 15%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($data->result() as $row){ 
                        $status = $row->tampilkan;
                          if($status=='Ya'){
                            $stat       = 'Ya';
                            $stat_color = 'success';
                            $stat_lain  = 'Tidak';
                          }else{
                            $stat       = 'Tidak';
                            $stat_color = 'danger';
                            $stat_lain  = 'Ya';
                          } 
                          $date = date('m/d/Y h:i:s', time());                        
                        ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>       
                            <td><?php echo $row->judul_video; ?></td>                                                       
                            <td><?php echo $row->nama_kategori ?></td>  
                            <td><a href='<?php echo $row->link; ?>' target="_blank"><?php echo $row->link; ?></a></td>         
                            <td>
                              <div class="dropdown">
                                <button class="btn btn-<?php echo $stat_color; ?> btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
                                  <?php echo $stat ?>
                                  <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                  <li role="presentation">
                                    <a role="menuitem" tabindex="-1" 
                                       href="<?php echo base_url();?>index.php/website/c_video/stat_data/<?php echo $stat_lain ?>/<?php echo $row->id ?>">
                                        <?php echo $stat_lain ?>
                                    </a>
                                  </li>
                                </ul>
                              </div>                              
                            </td>                      
                            <td align='center'>
                                <a id="<?php echo $row->id ?>"  href="#edit_video<?php echo $row->id; ?>" data-toggle="modal"  
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-pencil'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="edit_video<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Edit <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">
                                        <form method="post" class="form-horizontal" action="<?php echo base_url();?>index.php/website/c_video/edit_data">
                                          <input type="hidden" name="id" value="<?php echo $row->id; ?>">  
                                          <div class="form-group">                        
                                             <label for="Username" class="control-label col-lg-3">Judul Video</label>
                                                <div class="col-lg-9">
                                                  <input  type="text" id="judul_video" name="judul_video"  class="form-control"
                                                          placeholder="Judul Video"
                                                          autofocus required
                                                          oninvalid="this.setCustomValidity('Input hanya boleh huruf a-z tanpa spasi!')"
                                                          oninput="setCustomValidity('')"
                                                          value="<?php echo $row->judul_video; ?>"> 
                                                </div>
                                          </div> 
                                          <div class="form-group">                        
                                             <label for="Username" class="control-label col-lg-3">Link</label>
                                                <div class="col-lg-9">
                                                  <input  type="text" id="link" name="link"  class="form-control"
                                                          placeholder="Link"
                                                          autofocus required
                                                          oninvalid="this.setCustomValidity('Input hanya boleh huruf a-z tanpa spasi!')"
                                                          oninput="setCustomValidity('')"
                                                          value="<?php echo $row->link; ?>"> 
                                                </div>
                                          </div> 
                                          <div class="form-group">                        
                                            <label for="Group User" class="control-label col-lg-3">Kategori Video</label>
                                              <div class="col-lg-9">
                                                  <select style="width:397px" name="id_kategori" 
                                                          class="form-control selectpicker" 
                                                          data-style="btn-primary"
                                                          tabindex="2" required>
                                                     <option value="<?php echo $row->id_kategori?>"><?php echo $row->nama_kategori ?></option>
                                                       <?php
							                              foreach ($data_kategori->result() as $row_kategori){
							                              	 if ($row->nama_kategori==$row_kategori->nama_kategori)
                                                              {
                                                                continue;
                                                              }
							                                   echo "<option value= $row_kategori->id> $row_kategori->nama_kategori</option>";
							                              }
                                                        ?>
                                              </select>
                                              </div>
                                        </div>       
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <button type="submit" class="btn-success btn">
                                            <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
                                      </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <a id="<?php echo $row->id ?>"  href="#hapus_video<?php echo $row->id; ?>" data-toggle="modal"  
                                   class='btn btn-sm btn-light' title='Hapus'><i class='fa fa-trash'></i></a>
                                <!-- Modal -->
                                <div class="modal fade" id="hapus_video<?php echo $row->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                  <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Hapus <?php echo $sub_judul   ?></h4>
                                      </div>
                                      <div class="modal-body">                                        
                                          Apakah anda yakin ingin menghapus data ini ?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                                            <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
                                        <a class="btn-default btn" href="<?php echo base_url();?>index.php/website/c_video/hapus_data/<?php echo $row->id; ?>">
                                            <i class='fa fa-trash-o'></i>&nbsp;Hapus
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                            </td>  
                        </tr>      
                        <?php 
                            }
                        ?>              
                    </tbody>
                </table>               
            <?php echo $this->load->view('website/v_modal_tambah_video'); ?>
            
        </div>
      </div>
    </div>
  </div>


