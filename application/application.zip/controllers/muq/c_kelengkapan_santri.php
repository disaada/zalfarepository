<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_kelengkapan_santri extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        //hak akses
        /*=========================
          1 : super admin
          39  : admin
          40  : keuangan
          41  : editor
          42  : sekretaris
        ==========================*/
        $this->m_squrity->check_access(array('1','42','39'));
    }

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_kelengkapan_santri');
		$getquerytable		= $this->m_kelengkapan_santri->Getkelengkapan();
		//$getdatauser		= $this->m_fundraising->GetDataUsers();
		$isi['content'] 	= 'muq/v_kelengkapan_santri';
		$isi['base_link'] 	= 'muq/c_kelengkapan_santri';
		$isi['judul'] 		= 'Data Kelengkapan ';
		$isi['sub_judul'] 	= 'Data Kelengkapan Santri';
		$isi['data'] 		= $getquerytable;		
		$this->load->view('v_home',$isi);
	}
	
	public function upload()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_kelengkapan_santri');		
		$key 					= $this->uri->segment(4);
		$nama 					= $this->uri->segment(5);
		$isi['content'] 		= 'muq/v_form_kelengkapan_santri';
		$isi['back_link'] 		= 'muq/c_kelengkapan_santri';
		$isi['base_link'] 		= 'muq/c_kelengkapan_santri/upload/'.$key.'';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Santri';
		$isi['sub_judul'] 		= 'Upload Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_kelengkapan_santri 
                                 WHERE id_pendaftaran=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				$isi['kode']				= 'edit';
				$isi['id']		            = $key;
				$isi['nama_santri']			= $nama;
				$isi['filefotoktp']			= $row->filefotoktp;
				$isi['filefotoijazah']		= $row->filefotoijazah;
				$isi['filefotosehat']		= $row->filefotosehat;
				$isi['filefotoobat']		= $row->filefotoobat;
				$isi['filefotoberwarna']	= $row->filefotoberwarna;
				$isi['filefotosuratijin']	= $row->filefotosuratijin;
				$isi['filefotoaktalahir']	= $row->filefotoaktalahir;
				$isi['filefotokk']			= $row->filefotokk;
				$isi['filefotopindahan']	= $row->filefotopindahan;			

			}
		}else{
			$isi['kode']				= 'tambah';
			$isi['nama_santri']			= $nama;
			$isi['id']			        = $key;
			$isi['filefotoktp']			= '';
			$isi['filefotoijazah']		= '';
			$isi['filefotosehat']		= '';
			$isi['filefotoobat']		= '';
			$isi['filefotoberwarna']	= '';
			$isi['filefotosuratijin']	= '';
			$isi['filefotoaktalahir']	= '';
			$isi['filefotokk']			= '';
			$isi['filefotopindahan']	= '';
		}
		
		$this->load->view('v_home',$isi);
	}

	public function simpan_data()
    {
	    $this->load->library('upload');
	    $this->load->model('muq/m_kelengkapan_santri');        
		$this->m_squrity->getsqurity();
		$date = date('Y-d-m h:i:s', time());
		$nama_santri			= $this->input->post('nama');		
     	$kode					= $this->input->post('kode');

		//inisiasi gambar
		$nmfile 					= $nama_santri."_ktp_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/ktp/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotoktp');
     	$gbr = $this->upload->data();
     	$nama_file = $gbr['file_name'];
     	$tipe_file = $gbr['file_type'];
     	if($tipe_file!=''){
     		$data['filefotoktp']	= $nama_file;
     	}
     	if(($kode=='tambah')&&($tipe_file=='')){
     		$data['filefotoktp']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile2 					= $nama_santri."_ijazah_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/ijazah/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile2; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotoijazah');
     	$gbr = $this->upload->data();
     	$nama_file2 = $gbr['file_name'];
     	$tipe_file2 = $gbr['file_type'];
     	if($tipe_file2!=''){
     		$data['filefotoijazah']	= $nama_file2;
     	}
     	if(($kode=='tambah')&&($tipe_file2=='')){
     		$data['filefotoijazah']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile3 					= $nama_santri."_sehat".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/ket_sehat/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile3; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotosehat');
     	$gbr = $this->upload->data();
     	$nama_file3 = $gbr['file_name'];
     	$tipe_file3 = $gbr['file_type'];
     	if($tipe_file3!=''){
     		$data['filefotosehat']	= $nama_file3;
     	}
     	if(($kode=='tambah')&&($tipe_file3=='')){
     		$data['filefotosehat']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile4 					= $nama_santri."_obat_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/ket_obat/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile4; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotoobat');
     	$gbr = $this->upload->data();
     	$nama_file4 = $gbr['file_name'];
     	$tipe_file4 = $gbr['file_type'];
     	if($tipe_file4!=''){
     		$data['filefotoobat']	= $nama_file4;
     	}
     	if(($kode=='tambah')&&($tipe_file4=='')){
     		$data['filefotoobat']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile5 					= $nama_santri."_pasfoto_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/pasfoto/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile5; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotoberwarna');
     	$gbr = $this->upload->data();
     	$nama_file5 = $gbr['file_name'];
     	$tipe_file5 = $gbr['file_type'];
     	if($tipe_file5!=''){
     		$data['filefotoberwarna']	= $nama_file5;
     	}
     	if(($kode=='tambah')&&($tipe_file5=='')){
     		$data['filefotoberwarna']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile6 					= $nama_santri."_ijinortu_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/ijinortu/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile6; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotosuratijin');
     	$gbr = $this->upload->data();
     	$nama_file6 = $gbr['file_name'];
     	$tipe_file6 = $gbr['file_type'];
     	if($tipe_file6!=''){
     		$data['filefotosuratijin']	= $nama_file6;
     	}
     	if(($kode=='tambah')&&($tipe_file6=='')){
     		$data['filefotosuratijin']	= NULL;
     	}
     	
     	//inisiasi gambar
		$nmfile7 					= $nama_santri."_aktalahir_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/aktalahir/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile7; //nama yang terupload nantinya
 		
     	//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotoaktalahir');
     	$gbr = $this->upload->data();
     	$nama_file7 = $gbr['file_name'];
     	$tipe_file7 = $gbr['file_type'];
     	if($tipe_file7!=''){
     		$data['filefotoaktalahir']	= $nama_file7;
     	}
     	if(($kode=='tambah')&&($tipe_file7=='')){
     		$data['filefotoaktalahir']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile8 					= $nama_santri."_kk_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/kk/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile8; //nama yang terupload nantinya
 		
     	//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotokk');
     	$gbr = $this->upload->data();
     	$nama_file8 = $gbr['file_name'];
     	$tipe_file8 = $gbr['file_type'];
     	if($tipe_file8!=''){
     		$data['filefotokk']	= $nama_file8;
     	}
     	if(($kode=='tambah')&&($tipe_file8=='')){
     		$data['filefotokk']	= NULL;
     	}

     	//inisiasi gambar
		$nmfile9 					= $nama_santri."_spindahan_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/kelengkapan/surat_pindahan/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '10048'; //maksimum besar file 2M
        $config['file_name'] 		= $nmfile9; //nama yang terupload nantinya
 		
     	//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefotopindahan');
     	$gbr = $this->upload->data();
     	$nama_file9= $gbr['file_name'];
     	$tipe_file9 = $gbr['file_type'];
     	if($tipe_file9!=''){
     		$data['filefotopindahan']	= $nama_file9;
     	}
     	if(($kode=='tambah')&&($tipe_file9=='')){
     		$data['filefotopindahan']	= NULL;
     	}

     	$data['id_pendaftaran']		= $this->input->post('id');
     	$id_pendaftaran				= $this->input->post('id');		
     	if($kode=='tambah'){     		
			$this->m_kelengkapan_santri->GetInsert($data);
			$this->session->set_flashdata('info','tambah');
     	}else{
     		$key				= $this->input->post('id');
			$this->m_kelengkapan_santri->GetUpdate($key,$data);
			$this->session->set_flashdata('info','edit');
     	}

		redirect('muq/c_kelengkapan_santri/upload/'.$id_pendaftaran.'/'.$nama_santri.'');
  	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */