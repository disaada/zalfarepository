<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_riwayat_santri extends CI_Model {

	public function GetDataSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri ");
        return $query;
    }

    public function GetDataRiwayat(){
        $query=$this->db->query("SELECT t_santri_riwayat_pendidikan.`id`,
                                        t_santri_riwayat_pendidikan.`id_pendaftaran`, 
                                        t_santri_riwayat_pendidikan.`tingkat`,
                                        t_santri_riwayat_pendidikan.`nama`,
                                        t_santri_riwayat_pendidikan.`jurusan`,
                                        t_santri_riwayat_pendidikan.`no_ijazah`,
                                        t_santri_riwayat_pendidikan.`tahun`,
                                        t_pendaftaran_santri.`nama_santri`
                                 FROM t_santri_riwayat_pendidikan INNER JOIN t_pendaftaran_santri 
                                 ON t_santri_riwayat_pendidikan.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                 WHERE t_pendaftaran_santri.`nama_santri` <> 'Agen' 
                                ");
        return $query;
    }

    public function CountPendidikan($key){
        $this->db->where('id_pendaftaran',$key);
        $hasil = $this->db->get('t_santri_riwayat_pendidikan');
        return $hasil;
    }

    public function GetData($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,t_pendaftaran_santri.`nama_santri`
                                 FROM t_pendaftaran_santri INNER JOIN t_santri_riwayat_pendidikan 
                                 ON t_pendaftaran_santri.`id`=t_santri_riwayat_pendidikan.`id_pendaftaran`
                                 WHERE t_santri_riwayat_pendidikan.`id_pendaftaran`=".$key);
        return $query;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_santri_riwayat_pendidikan',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri_riwayat_pendidikan',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_santri_riwayat_pendidikan');
    }

}

/* End of file m_riwayat_santri.php */
/* Location: ./application/models/muq/m_riwayat_santri.php */