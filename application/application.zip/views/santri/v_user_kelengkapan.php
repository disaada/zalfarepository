<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'tambah' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Data berhasil ditambahkan</h4>
                  </div> 
                </div>  ';        
        break;
        case 'edit' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert1">
                    <h4><i class="fa fa-info"></i>Data berhasil diubah</h4>
                  </div> 
                </div>';           
        break;
        case 'hapus' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert6">
                    <h4><i class="fa fa-trash-o"></i>Data berhasil dihapus</h4>
                  </div> 
                </div>';           
        break;
      } 
    }
?> 
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
        <div class="col-md-3">
          <p><strong>Nama Santri</strong></p>
          <p><strong>Alamat Santri</strong></p>
        </div>
        <div class="col-md-9">
          <p><?php echo $data['nama_santri']; ?></p>
          <p><?php echo $data['alamat_pendaftaran_santri']; ?></p>
        </div>
        <div class="col-md-12"><hr></div>
              <table class="table display">
                    <thead>
                        <tr>
                            <th style='width: 25%'>Sudah di Upload</th>                            
                            <th style='width: 25%'>Belum di Upload</th>                            
                            <th style='width: 13%'>Aksi</th>
                        </tr>

                    </thead>
                 
                    <tfoot>
                        <tr>
                            <th style='width: 45%'>Sudah di Upload</th>                            
                            <th style='width: 25%'>Belum di Upload</th>                            
                            <th style='width: 13%'>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                      <?php
                            $total_upload = 9;
                            $total_supload=0;
                            $total_cekupload= $this->m_user_kelengkapan->cekKelengkapan($data['id']);
                            if(!empty($total_cekupload)){
                              $total_supload= $this->m_user_kelengkapan->TotalUpload($data['id']);
                            }
                            $total_bupload=$total_upload-$total_supload;
                        ?>  
                        <tr>
                            <td><span class="right label label-default"><?php echo $total_supload; ?> File</span></td>  
                            <td><span class="right label label-danger"><?php echo $total_bupload; ?> File</span></td>  
                            <td>
                                <a href="<?php echo base_url();?>index.php/santri/c_user_kelengkapan/upload/<?php echo $data['id']; ?>/<?php echo  str_replace(' ', '', $data['nama_santri']); ?>" 
                                   class='btn btn-sm btn-light' title='Edit'><i class='fa fa-upload'></i> Upload kelengkapan</a>  
                               
                            </td>  
                        </tr>      
                    </tbody>
                </table>   
        </div>
      </div>
    </div>
  </div>
