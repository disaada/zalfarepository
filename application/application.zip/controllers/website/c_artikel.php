<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_artikel extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_artikel');
		$getquerytable			= $this->m_artikel->GetArtikel();
		$getdatakartikel		= $this->m_artikel->GetDataKartikel();
		$isi['content'] 		= 'website/v_artikel';
		$isi['base_link'] 		= 'website/c_artikel';
		$isi['judul'] 			= 'Pengaturan Website ';
		$isi['sub_judul'] 		= 'Artikel';
		$isi['data'] 			= $getquerytable;
		$isi['data_kategori']	= $getdatakartikel;
		$this->load->view('v_home',$isi);
	}

	public function tambah()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_artikel');
		$getdatakartikel		= $this->m_artikel->GetDataKartikel();
		$isi['content'] 		= 'website/v_form_artikel';
		$isi['back_link'] 		= 'website/c_artikel';
		$isi['base_link'] 		= 'website/c_artikel/tambah';
		$isi['option'] 			= 'tambah';
		$isi['judul'] 			= 'Artikel';
		$isi['sub_judul'] 		= 'Tambah Data Artikel';
		$isi['data_kategori']	= $getdatakartikel;
		$isi['id']				= '';
		$isi['judul_artikel']	= '';
		$isi['isi_artikel']		= '';
		$isi['id_kategori']		= '';
		$isi['nama_kategori']	= 'Pilih Kategori';
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_artikel');
		$getdatakartikel		= $this->m_artikel->GetDataKartikel();
		$key 					= $this->uri->segment(4);
		$isi['content'] 		= 'website/v_form_artikel';
		$isi['back_link'] 		= 'website/c_artikel';
		$isi['base_link'] 		= 'website/c_artikel/edit';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Artikel';
		$isi['sub_judul'] 		= 'Edit Data Artikel';
		$isi['data_kategori']	= $getdatakartikel;
		$query=$this->db->query("SELECT t_kategori_artikel.`nama_kategori`,t_artikel.`id`,t_artikel.`tampilkan`,
                                        t_artikel.`id_kategori`,t_artikel.`judul_artikel`,t_artikel.`isi_artikel`, 
                                        t_artikel.`nama_gambar`   
                                 FROM t_artikel INNER JOIN t_kategori_artikel
                                 ON t_artikel.`id_kategori`=t_kategori_artikel.`id`
                                 WHERE t_artikel.`id`=".$key."
                                ");
		if($query->num_rows()>0)
		{
			foreach($query->result() as $row)
			{
				$isi['id']				= $row->id;
				$isi['judul_artikel']	= $row->judul_artikel;
				$isi['isi_artikel']		= $row->isi_artikel;
				$isi['id_kategori']		= $row->id_kategori;
				$isi['nama_kategori']	= $row->nama_kategori;
				if($row->nama_gambar==''){
					$data['nama_gambar']	= '--';
				}else
					$data['nama_gambar']	= $row->nama_gambar;
			}
		}
		
		$this->load->view('v_home',$isi);
	}

	public function tambah_data()
	{
		$this->load->library('upload');        
		$this->m_squrity->getsqurity();
		$date = date('Y-d-m h:i:s', time());

		//inisiasi gambar
		$nmfile 					= "artikel_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/artikel/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '2048'; //maksimum besar file 2M
        $config['max_width']  		= '1288'; //lebar maksimum 1288 px
        $config['max_height']  		= '768'; //tinggi maksimu 768 px
        $config['file_name'] 		= $nmfile; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefoto');
     	$gbr = $this->upload->data();
     	$nama_file = $gbr['file_name'];
     	$tipe_file = $gbr['file_type'];
     	if($tipe_file==''){
     		$nama_file = Null;
     		$tipe_file = Null;
     	}

		$data['judul_artikel']	= $this->input->post('judul_artikel');
		$data['isi_artikel']	= trim($this->input->post('isi_artikel'));
		$data['id_kategori']	= $this->input->post('id_kategori');
		$data['tampilkan']		= 'Ya';
		$data['tgl_publish']	= $date;
		$data['nama_gambar']	= $nama_file;
		$data['tipe_gambar']	= $tipe_file;

		$this->load->model('website/m_artikel');
		$this->m_artikel->GetInsert($data);
		$this->session->set_flashdata('info','tambah');
		redirect('website/c_artikel');
	}

	public function edit_data()
	{
		$this->load->library('upload');        
		$this->m_squrity->getsqurity();

		//inisiasi gambar
		$nmfile 					= "artikel_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/artikel/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '2048'; //maksimum besar file 2M
        $config['max_width']  		= '1288'; //lebar maksimum 1288 px
        $config['max_height']  		= '768'; //tinggi maksimu 768 px
        $config['file_name'] 		= $nmfile; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefoto');
     	$gbr = $this->upload->data();
     	$nama_file = $gbr['file_name'];
     	$tipe_file = $gbr['file_type'];
     	if($tipe_file==''){
     		$data['judul_artikel']	= $this->input->post('judul_artikel');
			$data['isi_artikel']	= trim($this->input->post('isi_artikel'));
			$data['id_kategori']	= $this->input->post('id_kategori');
     	}else{
     		$data['judul_artikel']	= $this->input->post('judul_artikel');
			$data['isi_artikel']	= trim($this->input->post('isi_artikel'));
			$data['id_kategori']	= $this->input->post('id_kategori');
			$data['nama_gambar']	= $nama_file;
			$data['tipe_gambar']	= $tipe_file;
     	}

		$key = $this->input->post('id');

		$this->load->model('website/m_artikel');
		$this->m_artikel->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_artikel');		
	}

	public function reset_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data_password			= $this->input->post('password_baru');
		$data['password']		= md5($data_password);

		$this->load->model('settings/m_users');
		$this->m_users->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('settings/c_user');		
	}

	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data['tampilkan'] 	= $this->uri->segment(4);

		$this->load->model('website/m_artikel');
		$this->m_artikel->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_artikel');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_artikel');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_artikel');
		if($query->num_rows()>0){
			$this->m_artikel->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('website/c_artikel');
		}		
		
	}


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */