<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_data_santri extends CI_Model {

	public function GetAktifSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.*,
                                        t_asrama.`nama_asrama`,
                                        t_jenis_santri.`jenis_santri`,
                                        t_santri.`tgl_masuk`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_asrama ON t_santri.`id_asrama`=t_asrama.`id` 
                                INNER JOIN t_jenis_santri ON t_santri.`id_jenis_santri`=t_jenis_santri.`id` 
                                ");
        return $query;
    }

    public function GetEditSantri($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.*,
                                        t_asrama.`nama_asrama`,
                                        t_jenis_santri.`jenis_santri`,
                                        t_santri.`tgl_masuk`,
                                        t_santri.`id_asrama`,
                                        t_santri.`id_jenis_santri`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_santri ON t_pendaftaran_santri.`id`=t_santri.`id_pendaftaran`
                                INNER JOIN t_asrama ON t_santri.`id_asrama`=t_asrama.`id` 
                                INNER JOIN t_jenis_santri ON t_santri.`id_jenis_santri`=t_jenis_santri.`id` 
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function GetDataSantri($key=NULL){
        if($key)
            $this->db->where('id', $key);
        $query=$this->db->get('t_pendaftaran_santri');
        return $query;
    }

    public function CekSantri($key=NULL){
        $this->db->where('id_pendaftaran', $key);
        $query=$this->db->get('t_santri');
        return $query->num_rows();
    }

    public function GetSantriWawancara(){
        $query=$this->db->query("SELECT * FROM t_wawancara WHERE t_wawancara.status='Diterima'");
        return $query;
    }

    public function GetDataMukim($where=null){
        if($where)
            $this->db->where('id',$key);
        $hasil = $this->db->get('t_asrama');
        return $hasil;
    }

    public function GetJenisSantri($where=null){
        if($where)
            $this->db->where('id',$key);
        $hasil = $this->db->get('t_jenis_santri');
        return $hasil;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_donatur');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pendaftaran_santri',$data);
    }

    public function GetUpdateSantri($key,$data){
            $this->db->where('id_pendaftaran',$key);
            $this->db->update('t_santri',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri',$data);
    }

    public function GetDelete($key){
        $this->db->where('id_pendaftaran',$key);
        $this->db->delete('t_santri');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_santri',$data);
    }

    public function listOrganisasi($key=NULL)
    {        
        $query = $this->db->query("SELECT t_pendaftaran_santri.`id`, t_pendaftaran_santri.`nama_santri`,   
                                        t_santri_p_organisasi.`organisasi`, t_santri_p_organisasi.`tahun_awal`, 
                                        t_santri_p_organisasi.`tahun_akhir`, t_santri_p_organisasi.`jabatan`
                                FROM t_pendaftaran_santri
                                INNER JOIN t_santri_p_organisasi ON t_pendaftaran_santri.`id`=t_santri_p_organisasi.`id_pendaftaran` 
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function listPrestasi($key=NULL)
    {
        $query = $this->db->query("SELECT t_pendaftaran_santri.`id`, t_pendaftaran_santri.`nama_santri`,   
                                        t_santri_prestasi.`prestasi`, t_santri_prestasi.`tahun`, 
                                        t_santri_prestasi.`instansi`
                                FROM t_pendaftaran_santri
                                INNER JOIN t_santri_prestasi ON t_pendaftaran_santri.`id`=t_santri_prestasi.`id_pendaftaran`
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function listPendidikan($key=NULL)
    {
        $query = $this->db->query("SELECT t_pendaftaran_santri.`id`, t_pendaftaran_santri.`nama_santri`,   
                                        t_santri_riwayat_pendidikan.`tingkat`, t_santri_riwayat_pendidikan.`nama` as nama_sekolah, t_santri_riwayat_pendidikan.`jurusan`, 
                                        t_santri_riwayat_pendidikan.`no_ijazah`, t_santri_riwayat_pendidikan.`tahun`
                                FROM t_pendaftaran_santri
                                INNER JOIN t_santri_riwayat_pendidikan ON t_pendaftaran_santri.`id`=t_santri_riwayat_pendidikan.`id_pendaftaran`
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    
}
