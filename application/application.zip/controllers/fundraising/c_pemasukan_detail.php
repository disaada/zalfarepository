<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_pemasukan_detail extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    //hak akses
    /*=========================
      1 : super admin
      39  : admin
      40  : keuangan
      41  : editor
      42  : sekretaris
    ==========================*/
    $this->m_squrity->check_access(array('1','40','39'));
  }

  public function index()
  {   
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_pemasukan');
    $key = $this->uri->segment(4);
    $getquerytable        = $this->m_pemasukan->GetPemasukanDetail($key);
    $getperiode           = $this->m_pemasukan->GetPeriode($key);
    $getdonatur           = $this->m_pemasukan->GetDonatur();

    $isi['content']       = 'fundraising/v_pemasukandetail';
    $isi['base_link']     = 'fundraising/c_pemasukan_detail/index/'.$key.'';
    $isi['link_back']     = 'fundraising/c_pemasukan';
    $isi['judul']         = 'Kebutuhan';
    $isi['sub_judul']     = 'Detail Pemasukan';
    $isi['data']          = $getquerytable;
    $isi['data_donatur']  = $getdonatur;
    $isi['periode']       = $getperiode;
    $isi['id']            = $key;
    //$isi['total']         = $this->m_kebutuhan->GettotKebutuhan($key);

    $data['total_pemasukan']  = $this->m_pemasukan->GettotPemasukan($key);
    $this->m_pemasukan->GetUpdatePem($key,$data);

    $this->load->view('v_home',$isi);
  }
  public function tambah_data()
  {
    $this->m_squrity->getsqurity();
    $data['id_fundraising']  = $this->input->post('id_fundraising');
    $data['id_donatur']      = $this->input->post('id_donatur');
    $data['nominal']         = $this->input->post('nominal');
    $data['tgl_pemasukan']   = $this->input->post('tgl_pemasukan');
    $data['keterangan']      = $this->input->post('keterangan');
    $id                      = $this->input->post('id_fundraising');
    $this->load->model('fundraising/m_pemasukan');
    $this->m_pemasukan->GetInsert($data);
    $this->session->set_flashdata('info','tambah');
    redirect('fundraising/c_pemasukan_detail/index/'.$id.'');
  }

  public function edit_data()
  {
    $this->m_squrity->getsqurity();
    $key                     = $this->input->post('id');
    $data['id_donatur']      = $this->input->post('id_donatur');
    $data['nominal']         = $this->input->post('nominal');
    $data['tgl_pemasukan']   = $this->input->post('tgl_pemasukan');
    $data['keterangan']      = $this->input->post('keterangan');
    $id                      = $this->input->post('id_fundraising');

    $this->load->model('fundraising/m_pemasukan');
    $this->m_pemasukan->GetUpdate($key,$data);
    $this->session->set_flashdata('info','edit');
    redirect('fundraising/c_pemasukan_detail/index/'.$id.'');   
  }

  public function hapus_data()
  {
    $this->m_squrity->getsqurity();
    $this->load->model('fundraising/m_pemasukan');

    $key    = $this->uri->segment(4);
    $id     = $this->uri->segment(5);
    $this->db->where('id',$key);
    $query = $this->db->get('t_pemasukan');
    if($query->num_rows()>0){
      $this->m_pemasukan->GetDelete($key);
      $this->session->set_flashdata('info','hapus');
      redirect('fundraising/c_pemasukan_detail/index/'.$id.'');
    }   
    
  }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
