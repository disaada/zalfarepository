<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_galeri extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_galeri');
		$getquerytable		= $this->m_galeri->GetGaleri();
		$getdataalbum		= $this->m_galeri->GetDataAlbum();
		$isi['content'] 	= 'website/v_galeri';
		$isi['base_link'] 	= 'website/c_galeri';
		$isi['judul'] 		= 'Pengaturan Website ';
		$isi['sub_judul'] 	= 'Galeri';
		$isi['data'] 		= $getquerytable;
		$isi['data_album']	= $getdataalbum;
		$this->load->view('v_home',$isi);
	}

	public function tambah_data()
	{
		$this->load->library('upload');        
		$this->m_squrity->getsqurity();

		//inisiasi gambar
		$nmfile 					= "galeri_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/galeri/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '2048'; //maksimum besar file 2M
        $config['max_width']  		= '2048'; //lebar maksimum 1288 px
        $config['max_height']  		= '2048'; //tinggi maksimu 768 px
        $config['file_name'] 		= $nmfile; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefoto');
     	$gbr = $this->upload->data();
     	$nama_file = $gbr['file_name'];
     	$tipe_file = $gbr['file_type'];
     	if($tipe_file==''){
     		$nama_file = Null;
     	}

		$data['judul_galeri']	= $this->input->post('judul_galeri');
		$data['id_album']		= $this->input->post('id_album');
		$data['keterangan']		= $this->input->post('keterangan');
		$data['tampilkan']		= 'Ya';
		$data['gambar_galeri']	= $nama_file;

		$this->load->model('website/m_galeri');
		$this->m_galeri->GetInsert($data);
		$this->session->set_flashdata('info','tambah');
		redirect('website/c_galeri');
	}

	public function edit_data()
	{
		$this->load->library('upload');
		$this->m_squrity->getsqurity();

		//inisiasi gambar
		$nmfile 					= "galeri_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] 		= './assets/images/galeri/'; //path folder
        $config['allowed_types'] 	= 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] 		= '2048'; //maksimum besar file 2M
        $config['max_width']  		= '2048'; //lebar maksimum 1288 px
        $config['max_height']  		= '2048'; //tinggi maksimu 768 px
        $config['file_name'] 		= $nmfile; //nama yang terupload nantinya
 		
 		//upload gambar
        $this->upload->initialize($config);
        $this->upload->do_upload('filefoto');
     	$gbr = $this->upload->data();
     	$nama_file = $gbr['file_name'];
     	$tipe_file = $gbr['file_type'];  	
     	if($tipe_file==''){
     		$data['judul_galeri']	= $this->input->post('judul_galeri');
			$data['id_album']		= $this->input->post('id_album');
			$data['keterangan']		= $this->input->post('keterangan');
     	}else{
     		$data['judul_galeri']	= $this->input->post('judul_galeri');
			$data['id_album']		= $this->input->post('id_album');
			$data['keterangan']		= $this->input->post('keterangan');
			$data['gambar_galeri']	= $nama_file;
     	}
		$key = $this->input->post('id');

		$this->load->model('website/m_galeri');
		$this->m_galeri->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_galeri');		
	}

	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data['tampilkan'] 	= $this->uri->segment(4);

		$this->load->model('website/m_galeri');
		$this->m_galeri->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_galeri');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_galeri');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_galeri');
		if($query->num_rows()>0){
			$this->m_galeri->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('website/c_galeri');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */