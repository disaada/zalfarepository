<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_group_user extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('settings/m_group_users');
		$getquerytable		= $this->m_group_users->GetGroupusers();
		$isi['content'] 	= 'group_user/v_group_user';
		$isi['base_link'] 	= 'settings/c_group_user';
		$isi['judul'] 		= 'Settings ';
		$isi['sub_judul'] 	= 'Group User';
		$isi['data'] 		= $getquerytable;
		$this->load->view('v_home',$isi);
	}
	public function tambah_data()
	{
		$this->m_squrity->getsqurity();
		$data['level']		= $this->input->post('level');
		$data['deskripsi']	= $this->input->post('deskripsi');

		$this->load->model('settings/m_group_users');
		$this->m_group_users->GetInsert($data);
		$this->session->set_flashdata('info','tambah');
		redirect('settings/c_group_user');
	}

	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data['id']			= $this->input->post('id');
		$data['level']		= $this->input->post('level');
		$data['deskripsi']	= $this->input->post('deskripsi');

		$this->load->model('settings/m_group_users');
		$this->m_group_users->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('settings/c_group_user');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('settings/m_group_users');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_group_users');
		if($query->num_rows()>0){
			$this->m_group_users->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('settings/c_group_user');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */