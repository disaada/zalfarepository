<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_kategori_artikel extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
			1	: super admin
			39	: admin
			40	: keuangan
			41	: editor
			42	: sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','41','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_kategori_artikel');
		$getquerytable		= $this->m_kategori_artikel->GetKategoriArtikel();
		$isi['content'] 	= 'website/v_kategori_artikel';
		$isi['base_link'] 	= 'website/c_kategori_artikel';
		$isi['judul'] 		= 'Pengaturan Website ';
		$isi['sub_judul'] 	= 'Kategori Artikel';
		$isi['data'] 		= $getquerytable;
		$this->load->view('v_home',$isi);
	}
	public function tambah_data()
	{
		$this->m_squrity->getsqurity();
		$data['nama_kategori']	= $this->input->post('nama_kategori');

		$this->load->model('website/m_kategori_artikel');
		$this->m_kategori_artikel->GetInsert($data);
		$this->session->set_flashdata('info','tambah');
		redirect('website/c_kategori_artikel');
	}

	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$key = $this->input->post('id');
		$data['nama_kategori']	= $this->input->post('nama_kategori');

		$this->load->model('website/m_kategori_artikel');
		$this->m_kategori_artikel->GetUpdate($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('website/c_kategori_artikel');		
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('website/m_kategori_artikel');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_kategori_artikel');
		if($query->num_rows()>0){
			$this->m_kategori_artikel->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('website/c_kategori_artikel');
		}		
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */