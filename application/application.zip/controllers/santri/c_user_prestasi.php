<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_prestasi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->m_squrity->check_access(array('43'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_prestasi');
		$getID		= $this->m_user_prestasi->GetSession($this->session->userdata('username'))->row_array();
		$getquerytable		= $this->m_user_prestasi->GetDataSantri($getID['id']);
		$isi['content'] 	= 'santri/v_user_prestasi';
		$isi['base_link'] 	= 'santri/c_user_prestasi';
		$isi['judul'] 		= 'Riwayat prestasi Santri';
		$isi['sub_judul'] 	= 'Data Riwayat prestasi Santri';
		$isi['data'] 		= $getquerytable->row_array();	
		
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_prestasi');		
		$getID		= $this->m_user_prestasi->GetSession($this->session->userdata('username'))->row_array();		
		$key 					= $getID['id'];
		$isi['content'] 		= 'santri/v_form_prestasi';
		$isi['back_link'] 		= 'santri/c_user_prestasi';
		$isi['base_link'] 		= 'santri/c_user_prestasi/edit';
		$isi['judul'] 			= 'Data Riwayat Prestasi Santri';
		$isi['sub_judul'] 		= 'Edit Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_prestasi 
                                 WHERE id_pendaftaran=".$key."
                                ");
		$useQuery = $query->result();
		if($query->num_rows()>0)
		{
			$isi['option']				= 'edit';
			$isi['judul'] 				= 'Data Riwayat prestasi Santri';
			$isi['sub_judul'] 			= 'Tambah Data Riwayat Santri';
			$isi['id'] 					= '';
			$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
			$isi['prestasi'] 			= ''; $isi['instansi']			= '';
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_user_prestasi->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			$isi['option']				= 'tambah';
			$isi['id'] 					= '';
			$isi['id_pendaftaran'] 		= ''; $isi['tahun'] 			= '';
			$isi['prestasi'] 			= ''; $isi['instansi']			= '';
			$isi['getData']				= $this->m_user_prestasi->GetDataSantri($key)->row_array();
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$this->load->view('v_home',$isi);
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran			  	 		= $this->input->post('id_pendaftaran');
	    $add['prestasi']  			 		= $this->input->post('prestasi');
	    $add['tahun']    					= $this->input->post('tahun');
	    $add['instansi']    				= $this->input->post('instansi');

	    $this->load->model('santri/m_user_prestasi');

		if(!$id_pendaftaran=="" || !empty($add)){
			for ($i=0; $i < count($add['prestasi']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['prestasi']  			 	= $add['prestasi'][$i];
			    $new['tahun']    				= $add['tahun'][$i];
			    $new['instansi']    			= $add['instansi'][$i];
		    	$this->m_user_prestasi->GetInsert($new);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('santri/c_user_prestasi');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('santri/c_user_prestasi/tambah');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id_edit');
		$data['prestasi']  	 				= $this->input->post('prestasi_edit');
	    $data['instansi']  				 	= $this->input->post('instansi_edit');
	    $data['tahun']       				= $this->input->post('tahun_edit');

	    for ($i=0; $i < count($data['prestasi']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['prestasi']  			 	= $data['prestasi'][$i];
		    $insert['tahun']    				= $data['tahun'][$i];
		    $insert['instansi']    				= $data['instansi'][$i];

	    	$this->load->model('santri/m_user_prestasi');
			$this->m_user_prestasi->GetUpdate($data['id'][$i],$insert);
	    }

	    $id_pendaftaran			  	 		= $this->input->post('id_pendaftaran');
	    $add['prestasi']  			 		= $this->input->post('prestasi');
	    $add['tahun']    					= $this->input->post('tahun');
	    $add['instansi']    				= $this->input->post('instansi');
	    if(!empty($add['prestasi'])){
			for ($i=0; $i < count($add['prestasi']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['prestasi']  			 	= $add['prestasi'][$i];
			    $new['tahun']    				= $add['tahun'][$i];
			    $new['instansi']    			= $add['instansi'][$i];
		    	$this->m_user_prestasi->GetInsert($new);
		    }
		}
		
		$this->session->set_flashdata('info','edit');
		redirect('santri/c_user_prestasi');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_prestasi');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_user_prestasi->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('santri/c_user_prestasi');
		}		
		
	}

}

/* End of file c_user_prestasi.php */
/* Location: ./application/controllers/santri/c_user_prestasi.php */