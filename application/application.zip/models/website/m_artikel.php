<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_artikel extends CI_Model {

	public function GetArtikel(){
        $query=$this->db->query("SELECT t_kategori_artikel.`nama_kategori`,t_artikel.`id`,t_artikel.`tampilkan`,
                                        t_artikel.`id_kategori`,t_artikel.`judul_artikel`,t_artikel.`isi_artikel`,   
                                        t_artikel.`nama_gambar`
                                 FROM t_artikel INNER JOIN t_kategori_artikel
                                 ON t_artikel.`id_kategori`=t_kategori_artikel.`id`
                                ");
        return $query;
    }

    public function GetDataKartikel(){
        $query=$this->db->query("SELECT id,nama_kategori FROM t_kategori_artikel ORDER BY id");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_artikel');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_artikel',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_artikel',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_artikel');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_artikel',$data);
    }
}
