<!-- Modal -->
<div class="modal fade" id="balas" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
      </div>
      <div class="modal-body">
        <form method="post" class="form-horizontal" action="<?php echo base_url();?>index.php/website/c_komentar_detail/tambah_data">
          <input type="hidden" name="id" value="<?php echo $row->id ?>">	
          <input type="hidden" name="id_artikel" value="<?php echo $row->id_artikel ?>">  
          <div class="form-group">
            <label class="control-label col-lg-3">balas Komentar</label>
            <div class="col-lg-9">
             <textarea name='komentar' placeholder="Tulis komentar ..."  
                       style="width:100%;" class="form-control" required></textarea>
            </div>
          </div>     
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">
          <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
        <button type="submit" class="btn-success btn">
          <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>
