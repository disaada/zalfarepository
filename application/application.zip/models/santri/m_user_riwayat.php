<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user_riwayat extends CI_Model {

	public function GetDataSantri($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri 
                                WHERE t_pendaftaran_santri.`id` = ".$key);
        return $query;
    }

    public function GetDataRiwayat(){
        $query=$this->db->query("SELECT t_santri_riwayat_pendidikan.`id`,
                                        t_santri_riwayat_pendidikan.`id_pendaftaran`, 
                                        t_santri_riwayat_pendidikan.`tingkat`,
                                        t_santri_riwayat_pendidikan.`nama`,
                                        t_santri_riwayat_pendidikan.`jurusan`,
                                        t_santri_riwayat_pendidikan.`no_ijazah`,
                                        t_santri_riwayat_pendidikan.`tahun`,
                                        t_pendaftaran_santri.`nama_santri`
                                 FROM t_santri_riwayat_pendidikan INNER JOIN t_pendaftaran_santri 
                                 ON t_santri_riwayat_pendidikan.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                 WHERE t_pendaftaran_santri.`id` = ".$key);
        return $query;
    }

    public function CountPendidikan($key=NULL){
        $this->db->where('id_pendaftaran',$key);
        $hasil = $this->db->get('t_santri_riwayat_pendidikan');
        return $hasil;
    }

    public function GetSession($key=NULL){
        $this->db->where('notelp',$key);
        $hasil = $this->db->get('t_pendaftaran_santri');
        return $hasil;
    }

    public function GetData($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,t_pendaftaran_santri.`nama_santri`
                                 FROM t_pendaftaran_santri INNER JOIN t_santri_riwayat_pendidikan 
                                 ON t_pendaftaran_santri.`id`=t_santri_riwayat_pendidikan.`id_pendaftaran`
                                 WHERE t_santri_riwayat_pendidikan.`id_pendaftaran`=".$key);
        return $query;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_santri_riwayat_pendidikan',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_santri_riwayat_pendidikan',$data);
    }
    public function GetInsertBatch($data){
    		$this->db->insert('t_santri_riwayat_pendidikan',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_santri_riwayat_pendidikan');
    }

}

/* End of file m_user_riwayat.php */
/* Location: ./application/models/santri/m_user_riwayat.php */