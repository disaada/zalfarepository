<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_fundraising extends CI_Model {

	public function GetPerFundraising(){
        $query=$this->db->query("SELECT * FROM t_fundraising");
        return $query;
    }

    public function GetPeriode(){
        $query=$this->db->query("SELECT id,periode FROM t_fundraising");
        return $query;
    }

    public function NamaBulan($periode){
        $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
     
        $bulan = substr($periode, 0, 2);
     
        $result = $BulanIndo[(int)$bulan-1];     
        return $result;
    }

    public function GetData($tanggal){
        $this->db->where('periode',$tanggal);
        $hasil = $this->db->get('t_fundraising');
        return $hasil;
    }

    public function GetInsert($data){
            $this->db->insert('t_fundraising',$data);
    }

    public function GetUpdatesel($key,$data2){
            $this->db->where('id',$key);
            $this->db->update('t_fundraising',$data2);
    }

}
