<?php
    $nama_lengkap   = $this->session->userdata('nama_user');
    $level          = $this->session->userdata('level');

    $check      = $this->m_users->GetAccessUsers($this->session->userdata('username'));
    $admin      = array('1','39');
    $keuangan   = array('1','39','40');
    $sekretaris = array('42');
    $editor     = array('1','39','41');
    $santri     = array('43');
    ?>


<div class="page-header">
    <h1 class="title"><i class="fa fa-home"></i>&nbsp;Dashboard</h1>
      <ol class="breadcrumb">
        
      </ol>
    <div class="left">
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo base_url();?>index.php/c_home" class="btn btn-default"><i class="fa fa-refresh"></i></a>
        <button disabled class="btn btn-warning" >
           <i class="fa fa-user"></i><span ><strong><?php echo $level; ?></strong></span>
        </button>
      </div>
    </div>  
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-primary">
          <i class="fa fa-home"></i>Dashboard</a>-->
        <button disabled class="btn btn-success" >
           <i class="fa fa-calendar"></i><span ><strong><?php echo $hari.", "; print date('d F Y'); ?></strong></span>
        </button>
        <button disabled class="btn btn-danger" >
          <i class="fa fa-clock-o"></i><span id="clock"><strong><?php print date('H:i:s'); ?></strong></span>
        </button>        
      </div>
    </div>     
  </div>
  
  <div class="container-default">

  <?php if(in_array($check->id_group, $admin)){ ?>
  <div class="row">
    <div class="col-md-12">
    <h4>Settings</h4>
    <ul class="panel quick-menu clearfix">
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/settings/c_group_user"><i class="fa fa-users"></i>
          Group User 
          <span class="label label-danger"><?php echo $GetJumlahGuser; ?></span></a>
      </a>

      </li>
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/settings/c_user"><i class="fa fa-user"></i>User
          <span class="label label-danger"><?php echo $GetJumlahUser; ?></span></a>
      </li>
    </ul>
    </div>
    
  </div>
  <?php } ?>

  <?php if(in_array($check->id_group, $editor)){ ?>
  <div class="row">
    <div class="col-md-6">
    <h4>Atur Galeri</h4>
    <ul class="panel quick-menu clearfix">
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/website/c_album"><i class="fa fa-file-image-o"></i>
          Album 
          <span class="label label-success"><?php echo $GetJumlahalbum; ?></span></a>
      </a>

      </li>
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/website/c_galeri"><i class="fa fa-image"></i>
          Galeri Foto
          <span class="label label-success"><?php echo $GetJumlahgaleri; ?></span></a>
      </li>
    </ul>
    </div>
    <div class="col-md-6">
    <h4>Atur Video</h4>
    <ul class="panel quick-menu clearfix">
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/website/c_kategori_video"><i class="fa fa-file-movie-o"></i>
          Kategori Video
          <span class="label label-success"><?php echo $GetJumlahkvideo; ?></span></a>
      </a>

      </li>
      <li class="col-sm-6">
        <a href="<?php echo base_url();?>index.php/website/c_video"><i class="fa fa-film"></i>
          Video
          <span class="label label-success"><?php echo $GetJumlahvideo; ?></span></a>
      </li>
    </ul>
    </div>
  </div>
  <?php } ?>

  <?php if(in_array($check->id_group, $editor)){ ?>
  <div class="row">
    <div class="col-md-9">
    <h4>Atur Artikel</h4>
    <ul class="panel quick-menu clearfix">
      <li class="col-sm-4">
        <a href="<?php echo base_url();?>index.php/website/c_kategori_artikel"><i class="fa fa-list"></i>
          Kategori Artikel 
          <span class="label label-success"><?php echo $GetJumlahkartikel; ?></span></a>
      </a>

      </li>
      <li class="col-sm-4">
        <a href="<?php echo base_url();?>index.php/website/c_artikel"><i class="fa fa-file-text"></i>
          Artikel
          <span class="label label-success"><?php echo $GetJumlahartikel; ?></span></a>
      </li>
      <li class="col-sm-4">
        <a href="<?php echo base_url();?>index.php/website/c_komentar"><i class="fa fa-comments-o"></i>
          Komentar
          <span class="label label-success"><?php echo $GetJumlahkomentar; ?></span></a>
      </li>
    </ul>
    </div>
    <?php if(in_array($check->id_group, $admin)){ ?>
    <div class="col-md-3">
    <h4>Pesan</h4>
    <ul class="panel quick-menu clearfix">
      <li class="col-sm-12">
        <a href="<?php echo base_url();?>index.php/website/c_pesan"><i class="fa fa-users"></i>
          Pesan
          <span class="label label-success"><?php echo $GetJumlahpesan; ?></span></a>
      </a>

      </li>
    </ul>
    </div>
    <?php } ?>

  </div>
  <?php } ?>

  <?php if(in_array($check->id_group, $sekretaris)){  ?>
  <div class="row">
    <div class="col-md-12">
      <h4>Dashboard</h4>

      <div class="alert alert-warning">kamu sedang menggunakan akun Sekretaris</div>
    
    </div>    
  </div> 
  <?php }?>
  <?php if(in_array($check->id_group, $santri)){  ?>
  <div class="row">
    <div class="col-md-12">
      <h4>Dashboard</h4>
      <?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'belum' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert3">
                    <h4><i class="fa fa-check"></i>Mohon menunggu verifikasi dari pihak administrator.</h4>
                  </div> 
                </div>  ';        
        break;
      } 
    }

    $user = $this->session->userdata('username');
    $data    = $this->m_user_data->GetData($user)->row_array();
?>
      <div class="alert alert-info">Selamat Datang <strong><?php echo $data['nama_santri']; ?></strong>.</div>
      
      <div class="panel panel-default">
        <div class="panel-headeing">
          <h3 class="panel-title">
            Pengumuman
          </h3>
        </div>
        <div class="panel-body">
          <p>Tidak ada Pengumuman</p>
        </div>
      </div>

      <div class="panel panel-default">
        <div class="panel-headeing">
          <h3 class="panel-title">
            Informasi Pendaftaran
          </h3>
        </div>
        <div class="panel-body">
          <p>Terima kasih kamu telah mendaftar untuk menjadi santri di Ma'had Usyaqil Qur'an, selanjutnya kamu diharuskan untuk mengisi data - data dan perlengkapan yang akan dibutuhkan kedepannya.</p>
          <ol>
            <li>Ubah terlebih dahulu katasandi / password default kamu untuk keamanan lebih lanjut <a href="<?php echo base_url('index.php/santri/c_user_setting');?>" class="btn btn-light"> Klik Disini</a> </li>
            <li>Lengkapi data pribadi kamu dengan data riil tanpa ada rekayasa <a href="<?php echo base_url('index.php/santri/c_user_data');?>" class="btn btn-light"> Klik Disini</a></li>
            <li>Siapkan scan data / foto di kelengkapan santri, adapun data yang diperlukan :
                <ul>
                  <li>Foto KTP</li>
                  <li>Foto Ijazah</li>
                  <li>Foto Surat keterangan Sehat</li>
                  <li>Foto Surat Tidak menggunakan obat terlarang</li>
                  <li>Pas Foto berwarna ukuran 3x4</li>
                  <li>Foto Surat ijin orang tua</li>
                  <li>Foto Akta Lahir</li>
                  <li>Foto Kartu Keluarga</li>
                  <li>Foto Surat Pindahan (opsional)</li>
                </ul> 
              <a href="<?php echo base_url('index.php/santri/c_user_kelengkapan');?>" class="btn btn-light"> Upload Disini</a>
            </li>
            <li>
              Lengkapi data riwayat pendidikan kamu dengan data riil tanpa ada rekayasa <a href="<?php echo base_url('index.php/santri/c_user_riwayat');?>" class="btn btn-light"> Klik Disini</a>
            </li>
            <li>
              Lengkapi data riwayat prestasi kamu dengan data riil tanpa ada rekayasa <a href="<?php echo base_url('index.php/santri/c_user_prestasi');?>" class="btn btn-light"> Klik Disini</a>
            </li>
            <li>
              Lengkapi data pengalaman berorganisasi kamu dengan data riil tanpa ada rekayasa <a href="<?php echo base_url('index.php/santri/c_user_organisasi');?>" class="btn btn-light"> Klik Disini</a>
            </li>
          </ol>
        </div>
      </div>
    
    </div>    
  </div> 
  <?php }?>


  
  <br><br><br><br><br><br><br>


