<div class="page-header">
  <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $sub_judul ?></h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
      <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
      <li class="active"><?php echo  $sub_judul; ?></li>
    </ol>
  <div class="right">
    <div class="btn-group" role="group" aria-label="...">
      <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>-->
      <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
         type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
      <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
         class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
    </div>
  </div>
</div>

<div class="container-default">
  <div class="row">

    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div><br>
          <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/<?php echo $base_link;?>/edit_data"
                 enctype="multipart/form-data">   
           <input type="hidden" name="id" value="<?php echo $data['id']; ?>">        
           <div class="panel-body">
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Nama Santri</label>
                    <div class="col-lg-10">
                      <input  type="text" name="nama_santri"  class="form-control"
                              placeholder="Nama Santri"
                              autofocus required
                              oninvalid="this.setCustomValidity('Form ini harus di isi')"
                              oninput="setCustomValidity('')"  
                              value="<?php echo $data['nama_santri']; ?>"> 
                    </div>
                </div>
              </div>  
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Tempat Lahir</label>
                    <div class="col-lg-5">
                      <input  type="text" name="tempat_lahir"  class="form-control"
                              placeholder="Tempat lahir"
                              autofocus required
                              oninvalid="this.setCustomValidity('Form ini harus di isi')"
                              oninput="setCustomValidity('')"  
                              value="<?php echo $data['tempat_lahir'];; ?>"> 
                    </div>
                <label for="judul" class="control-label col-lg-1">tgl Lahir</label>
                    <div class="col-lg-4">
                      <div class="input-prepend input-group">
                       <span class="add-on input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="date" name="tgl_lahir" placeholder="Tanggal Lahir" 
                               class="form-control" autofocus required
                                oninvalid="this.setCustomValidity('Form harus di isi')"
                                oninput="setCustomValidity('')"  
                                value="<?php echo $data['tgl_lahir']; ?>"> 
                      </div>
                    </div>
                </div>
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Jenis Kelamin</label>
                    <div class="col-lg-3">
                          <?php 

                              if($data['jk'] == 'Perempuan'){
                                $prm = 'checked';
                                $lk = '';                                
                              }elseif($data['jk'] == 'Laki-laki'){
                                $prm = '';
                                $lk = 'checked';
                              }
                              else{
                                $prm = '';
                                $lk = '';
                              }
                                                         
                        ?>
                     <div class="radio radio-info radio-inline">
                            <input type="radio" id="inlineRadio5" value="Laki-laki" name="jk" <?php echo $lk ?>>
                            <label for="inlineRadio5"> Laki-laki </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="inlineRadio6" value="Perempuan" name="jk" <?php echo $prm ?>>
                            <label for="inlineRadio6"> Perempuan </label>
                        </div>
                    </div>
                <label for="judul" class="control-label col-lg-2">Golongan Darah</label>
                    <div class="col-lg-4">
                    <?php 
                              if($data['goldar'] == 'A'){
                                $a = 'checked'; $ab = '';
                                $b = '';        $o  = '';                                
                              }elseif($data['goldar'] == 'B'){
                                $a = '';        $ab = '';
                                $b = 'checked'; $o  = ''; 
                              }
                              elseif($data['goldar'] == 'O'){
                                $a = ''; $ab = '';
                                $b = ''; $o  = 'checked'; 
                              }else{
                                $a = ''; $ab = 'checked';
                                $b = ''; $o  = ''; 
                              }                           
                        ?>
                      <div class="radio radio-info radio-inline">
                            <input type="radio" id="a" <?php echo $a; ?> value="A" name="goldar" <?php //echo $tunai ?>>
                            <label for="a"> A </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="b" <?php echo $b; ?> value="B" name="goldar" <?php //echo $nabung ?>>
                            <label for="b"> B </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="ab" <?php echo $ab; ?> value="AB" name="goldar" <?php //echo $nabung ?>>
                            <label for="ab"> AB </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="o" <?php echo $o; ?> value="O" name="goldar" <?php //echo $nabung ?>>
                            <label for="o"> O </label>
                        </div>
                    </div>
                </div> 
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Anak Ke-</label>
                    <div class="col-lg-5">
                      <input  type="text" name="anakke"  class="form-control"
                              placeholder="Anak Ke"
                                
                              value="<?php echo $data['anakke']; ?>"> 
                    </div>
                <label for="judul" class="control-label col-lg-1">Dari</label>
                    <div class="col-lg-4">
                       <input type="text" name="saudara" placeholder="Dari berapa saudara" 
                               class="form-control" autofocus 
                                value="<?php echo $data['saudara']; ?>"> 
                    </div>
                </div>   
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">No. Telp</label>
                    <div class="col-lg-10">
                       <input type="text" name="notelp" placeholder="No. telp" 
                               class="form-control" required
                                value="<?php echo $data['notelp']; ?>"> 
                    </div>
                </div>
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Email</label>
                    <div class="col-lg-4">
                      <input  type="email" name="email"  class="form-control"
                              placeholder="Email" required
                                
                              value="<?php echo $data['email']; ?>"> 
                    </div>
                <label for="judul" class="control-label col-lg-2">Alamat Fb</label>
                    <div class="col-lg-4">
                       <input type="text" name="emailfb_santri" placeholder="Alamat Fb" 
                               class="form-control"  
                                value="<?php echo $data['emailfb_santri']; ?>"> 
                    </div>
                </div>
               <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Alamat</label>
                    <div class="col-lg-10">
                      <input  type="text" name="alamat_pendaftaran_santri"  class="form-control"
                              placeholder="Alamat"
                                
                              value="<?php echo $data['alamat_pendaftaran_santri']; ?>"> 
                    </div>
                </div>
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Pendidikan Terakhir</label>
                  <div class="col-lg-10">
                    <select name            ="pendidikan_terakhir_santri" 
                            class           ="form-control selectpicker"
                            data-style      ="btn-light"
                            data-live-search="true">
                      <?php 
                        if(empty($data['pendidikan_terakhir_santri'])){
                          $detail_pendidikan = '--- Pilih Pendidikan ---'; 
                        }else
                          $detail_pendidikan = $data['pendidikan_terakhir_santri']; 
                      ?>
                      <option value="<?php echo $data['pendidikan_terakhir_santri']; ?>"><?php echo $detail_pendidikan ?></option>
                      <?php
                          $pendidikan = array("","SD (Sekolah Dasar)","SMP (Sekolah Menengah Pertama)","SMA/K (Sekolah Menengah Atas/Kejuruan)"
                                               ,"S1","S2","S3","D1","D2","D3","D4"
                                               ,"Lainnya");
                          $value = array("","SD","SMP","SMA/SMK"
                                               ,"S1","S2","S3","D1","D2","D3","D4"
                                               ,"Lainnya");
                          for($i = 1;$i <11;$i++)
                              print("<option value=\"$value[$i]\">$pendidikan[$i]</option>");
                      ?>                                   
                    </select>
                  </div>
              </div>
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Nama Wali</label>
                    <div class="col-lg-5">
                      <input  type="text" name="nama_wali"  class="form-control"
                              placeholder="Nama Orang Tua/Wali"
                                
                              value="<?php echo $data['nama_wali']; ?>"> 
                    </div>
                <label for="judul" class="control-label col-lg-1">No. Telp</label>
                    <div class="col-lg-4">
                       <input type="text" name="notelp_ortu" placeholder="No. telp Wali" 
                               class="form-control" autofocus 
                                oninvalid="this.setCustomValidity('Form harus di isi')"
                                oninput="setCustomValidity('')"  
                                value="<?php echo $data['notelp_ortu']; ?>"> 
                    </div>
                </div>
              <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Pendidikan Terakhir Wali</label>
                  <div class="col-lg-10">
                    <select name            ="pendidikanterakhir_ortu" 
                            class           ="form-control selectpicker"
                            data-style      ="btn-light"
                            data-live-search="true">
                      <?php 
                        if(empty($data['pendidikanterakhir_ortu'])){
                          $detail_pendidikan = '--- Pilih Pendidikan ---'; 
                        }else
                          $detail_pendidikan = $data['pendidikanterakhir_ortu']; 
                      ?>
                      <option value="<?php echo $data['pendidikanterakhir_ortu']; ?>"><?php echo $detail_pendidikan ?></option>
                      <?php
                          $pendidikan = array("","SD (Sekolah Dasar)","SMP (Sekolah Menengah Pertama)","SMA/K (Sekolah Menengah Atas/Kejuruan)"
                                               ,"S1","S2","S3","D1","D2","D3","D4"
                                               ,"Lainnya");
                          $value = array("","SD","SMP","SMA/SMK"
                                               ,"S1","S2","S3","D1","D2","D3","D4"
                                               ,"Lainnya");
                          for($i = 1;$i <11;$i++)
                              print("<option value=\"$value[$i]\">$pendidikan[$i]</option>");
                      ?>                                  
                    </select>
                  </div>
              </div>
              <div class="form-group">
                    <label for="judul" class="control-label col-lg-2">Pekerjaan Ortu</label>
                      <div class="col-lg-10">
                        <select name            ="pekerjaan_ortu" 
                                class           ="form-control selectpicker"
                                data-style      ="btn-light"
                                data-live-search="true">
                          <?php 
                            if(empty($data['pekerjaan_ortu'])){
                              $detail_pekerjaan_ortu = '--- Pilih Pekerjaan ---'; 
                            }else
                              $detail_pekerjaan_ortu = $data['pekerjaan_ortu']; 
                          ?>
                          <option value="<?php echo $data['pekerjaan_ortu'] ?>"><?php echo $detail_pekerjaan_ortu ?></option>
                          <?php
                              $pekerjaan = array("","Penyelenggaran Negara","PNS/TNI/POSRI","BUMN/BUMD/SWASTA"
                                                   ,"Wiraswasta","Pelajar/Mahasiswa","Ibu Rumah Tangga","Profesional"
                                                   ,"Lainnya");
                              for($i = 1;$i <9;$i++)
                                  print("<option value=\"$pekerjaan[$i]\">$pekerjaan[$i]</option>");
                          ?>                                  
                        </select>
                      </div>
                  </div>
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Nama Ayah</label>
                    <div class="col-lg-4">
                      <input  type="text" name="nama_ayah"  class="form-control"
                              placeholder="Nama Ayah"
                                
                              value="<?php echo $data['nama_ayah']; ?>"> 
                    </div>
                <label for="judul" class="control-label col-lg-2">Nama Ibu</label>
                    <div class="col-lg-4">
                       <input type="text" name="nama_ibu" placeholder="Nama Ibu" 
                               class="form-control" autofocus 
                                oninvalid="this.setCustomValidity('Form harus di isi')"
                                oninput="setCustomValidity('')"  
                                value="<?php echo $data['nama_ibu']; ?>"> 
                    </div>
                </div>
                <div class="form-group">
                <label for="judul" class="control-label col-lg-2">Alamat Orang Tua</label>
                    <div class="col-lg-10">
                      <input  type="text" name="alamat_ortu"  class="form-control"
                              placeholder="Alamat Orang Tua"
                                
                              value="<?php echo $data['alamat_ortu']; ?>"> 
                    </div>
                </div>
               <div class="form-group">
                <label for="judul" class="control-label col-lg-2">penghasilan Ortu</label>
                    <div class="col-lg-10">
                    <?php 
                              if($data['penghasilanortuperbulan'] == '<1.5'){
                                $satu = 'checked'; $empat = '';
                                $dua  = '';        $lima  = '';                                
                                $tiga  = '';                                       
                              }elseif($data['penghasilanortuperbulan'] == '1.5-3'){
                                $satu = '';        $empat = '';
                                $dua  = 'checked'; $lima  = '';                                
                                $tiga  = '';      
                              }
                              elseif($data['penghasilanortuperbulan'] == '3-6'){
                                $satu = '';        $empat = '';
                                $dua  = '';        $lima  = '';                                
                                $tiga = 'checked'; 
                              }elseif($data['penghasilanortuperbulan'] == '6-12'){
                                $satu = '';        $empat = 'checked';
                                $dua  = '';        $lima  = '';                                
                                $tiga = '';  
                              }else{
                                $satu = '';        $empat = '';
                                $dua  = '';        $lima  = 'checked';                                
                                $tiga = '';  
                              }                          
                        ?>
                      <div class="radio radio-info radio-inline">
                            <input type="radio" id="<15" <?php echo $satu; ?> value="<1.5" name="penghasilanortuperbulan">
                            <label for="<15"> dibawah 1.5 Juta </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="15-3" <?php echo $dua; ?> value="1.5-3" name="penghasilanortuperbulan">
                            <label for="15-3"> 1.5 juta sampai 3 juta </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="3-6" <?php echo $tiga; ?> value="3-6" name="penghasilanortuperbulan" >
                            <label for="3-6"> 3 juta sampai 6 juta </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="6-12" <?php echo $empat; ?> value="6-12" name="penghasilanortuperbulan" >
                            <label for="6-12"> 6 juta sampai 12 juta </label>
                        </div>
                        <div class="radio radio-inline">
                            <input type="radio" id="12>" <?php echo $lima; ?> value=">12" name="penghasilanortuperbulan" >
                            <label for="12>"> 12 juta ke atas </label>
                        </div>
                    </div>
                  </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form> 
        </div>
      </div>
    </div>
  </div>