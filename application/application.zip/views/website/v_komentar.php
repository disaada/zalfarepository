<div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $judul; ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a> -->     
        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<div class="container-default">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>

              <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Artikel</th>
                            <th>Kategori</th>
                            <th><center>Jumlah Komentar</center></th>
                            <th>Aksi</th>
                        </tr>
                    </thead>                 
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Judul Artikel</th>
                            <th>Kategori</th>
                            <th><center>Jumlah Komentar</center></th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                 
                    <tbody>
                    <?php
                        $no = 1;                                                
                        foreach ($data->result() as $row){
                          $this->load->model('website/m_komentar');
                          $kode         = $row->id;
                          $status       = '';
                          $GetJumlahKom = $this->m_komentar->GetTotalKomentar($kode);
                          if(empty($GetJumlahKom)){
                            $status     = 'disabled';
                          }
                      ?>  
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row->nama_kategori ?></td>
                            <td><?php echo $row->judul_artikel ?></td>
                            <td><center><?php echo $GetJumlahKom ?></center></td>
                            <td> 
                                <a href="<?php echo base_url();?>index.php/website/c_komentar_detail/index/<?php echo $row->id; ?>" type="button" 
                                   class="btn btn-light btn-sm" <?php echo $status; ?>><i class="fa fa-hand-o-right"></i>Lihat Komentar</a>   
                            </td>  
                        </tr>
                        <?php 
                        }
                        ?>   
                    </tbody>
                </table>               
            <?php //echo $this->load->view('syabab/v_modal_tambah_syabab'); ?>
            
        </div>
      </div>
    </div>
  </div>