<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_pesan extends CI_Model {

    public function GetPesan(){
        $query=$this->db->query("SELECT * FROM t_pesan");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_pesan');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pesan',$data);
    }

    public function GetInsert($data){
            $this->db->insert('t_pesan',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_pesan');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pesan',$data);
    }
}
