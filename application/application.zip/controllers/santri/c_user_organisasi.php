<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_organisasi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->m_squrity->check_access(array('43'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_organisasi');
		$getID				= $this->m_user_organisasi->GetSession($this->session->userdata('username'))->row_array();
		$getquerytable		= $this->m_user_organisasi->GetDataSantri($getID['id']);
		$isi['content'] 	= 'santri/v_user_organisasi';
		$isi['base_link'] 	= 'santri/c_user_organisasi';
		$isi['judul'] 		= 'Pengalaman Berorganisasi Santri';
		$isi['sub_judul'] 	= 'Data pengalaman Organisasi Santri';
		$isi['data'] 		= $getquerytable->row_array();		
		$this->load->view('v_home',$isi);
	}

	public function edit()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_organisasi');		
		$getID			= $this->m_user_organisasi->GetSession($this->session->userdata('username'))->row_array();		
		$key 					= $getID['id'];
		$isi['content'] 		= 'santri/v_form_organisasi';
		$isi['back_link'] 		= 'santri/c_user_organisasi';
		$isi['base_link'] 		= 'santri/c_user_organisasi/edit';
		$isi['option'] 			= 'edit';
		$isi['judul'] 			= 'Data Santri';
		$isi['sub_judul'] 		= 'Edit Data Santri';
		$query=$this->db->query("SELECT *   
                                 FROM t_santri_p_organisasi 
                                 WHERE id_pendaftaran=".$key."
                                ");
		if($query->num_rows()>0)
		{
			$isi['option'] 				= 'edit';
			$isi['id'] 					= $key;
			$isi['id_pendaftaran'] 		= ''; $isi['tahun_awal'] 			= '';
			$isi['organisasi'] 			= ''; $isi['tahun_akhir']			= '';
			$isi['jabatan'] 			= ''; 
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$isi['getData']				= $this->m_user_organisasi->GetData($key)->row_array();
			$this->load->view('v_home',$isi);
		}
		else{
			$isi['option']				= 'tambah';
			$isi['id'] 					= $key;
			$isi['id_pendaftaran'] 		= ''; $isi['tahun_awal'] 			= '';
			$isi['organisasi'] 			= ''; $isi['tahun_akhir']			= '';
			$isi['jabatan'] 			= '';
			$isi['getData']				= $this->m_user_organisasi->GetDataSantri($key)->row_array();
			$isi['id']					= $key;
			$isi['putData']				= $query->result();
			$this->load->view('v_home',$isi);
		}
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_pendaftaran    = $this->input->post('id_pendaftaran');
	    $add['organisasi'] = $this->input->post('organisasi');
	    $add['jabatan']    = $this->input->post('jabatan');
	    $add['tahun_awal'] = $this->input->post('tahun_awal');
	    $add['tahun_akhir']= $this->input->post('tahun_akhir');

	    $this->load->model('santri/m_user_organisasi');

	    if(!$id_pendaftaran=="" || $add==""){
		    for ($i=0; $i < count($add['organisasi']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['organisasi']  			= $add['organisasi'][$i];
			    $new['jabatan']    				= $add['jabatan'][$i];
			    $new['tahun_awal']    			= $add['tahun_awal'][$i];
			    $new['tahun_akhir']    			= $add['tahun_akhir'][$i];
		    	$this->m_user_organisasi->GetInsert($new);
		    }
		    $this->session->set_flashdata('info','tambah');
		    redirect('santri/c_user_organisasi');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('santri/c_riwayat_santri/tambah');
		}
  	}

  	public function edit_data()
	{
		$this->m_squrity->getsqurity();
		$data['id']							= $this->input->post('id_edit');
		$data['organisasi']  	 			= $this->input->post('organisasi_edit');
	    $data['tahun_awal']  				= $this->input->post('tahun_awal_edit');
	    $data['tahun_akhir'] 	         	= $this->input->post('tahun_akhir_edit');
	    $data['jabatan']       				= $this->input->post('jabatan_edit');

	    for ($i=0; $i < count($data['organisasi']) ; $i++) { 
	    	$insert['id']  	 					= $data['id'][$i];
		    $insert['organisasi']  			 	= $data['organisasi'][$i];
		    $insert['jabatan']    				= $data['jabatan'][$i];
		    $insert['tahun_akhir']    			= $data['tahun_akhir'][$i];
		    $insert['tahun_awal']    			= $data['tahun_awal'][$i];

	    	$this->load->model('santri/m_user_organisasi');
			$this->m_user_organisasi->GetUpdate($data['id'][$i],$insert);
	    }

	    $id_pendaftaran			  	 	= $this->input->post('id_pendaftaran');
	    $add['organisasi']  			= $this->input->post('organisasi');
	    $add['jabatan']    				= $this->input->post('jabatan');
	    $add['tahun_awal']    			= $this->input->post('tahun_awal');
	    $add['tahun_akhir']    			= $this->input->post('tahun_akhir');

	    if(!empty($add['organisasi'])){
		    for ($i=0; $i < count($add['organisasi']) ; $i++) { 
		    	$new['id_pendaftaran']  	 	= $id_pendaftaran;
			    $new['organisasi']  			= $add['organisasi'][$i];
			    $new['jabatan']    				= $add['jabatan'][$i];
			    $new['tahun_awal']    			= $add['tahun_awal'][$i];
			    $new['tahun_akhir']    			= $add['tahun_akhir'][$i];
		    	$this->m_user_organisasi->GetInsert($new);
		    }
		}
		
		$this->session->set_flashdata('info','edit');
		redirect('santri/c_user_organisasi');	
	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('santri/m_user_organisasi');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_santri');
		if($query->num_rows()>0){
			$this->m_user_organisasi->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('santri/c_user_organisasi');
		}		
		
	}

}

/* End of file c_user_organisasi.php */
/* Location: ./application/controllers/santri/c_user_organisasi.php */