<!-- Modal -->
<div class="modal fade" id="tambah_detail_donatur" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah <?php echo $sub_judul   ?></h4>
      </div>
      <div class="modal-body">
        <form method="post" class="form-horizontal" 
              action="<?php echo base_url();?>index.php/fundraising/c_donatur/tambah_data">
          <!--<input type="hidden" name="id_fundraising" value="<?php echo $id; ?>">  -->
          <div class="form-group">
            <label class="control-label col-lg-3">Nama </label>
            <div class="col-lg-9">
              <input type="text" id="nama_donatur" name="nama_donatur" placeholder="Nama Donatur" 
                     class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>  
          <div class="form-group">
            <label class="control-label col-lg-3">Kota </label>
            <div class="col-lg-9">
              <input type="text" id="kota" name="kota" placeholder="Kota" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>      
          <div class="form-group">
            <label class="control-label col-lg-3">Alamat </label>
            <div class="col-lg-9">
              <input type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>   
          <div class="form-group">
            <label class="control-label col-lg-3">No. Kontak </label>
            <div class="col-lg-9">
              <input type="text" id="no_kontak" name="no_kontak" placeholder="No. Kontak" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div>  
          <div class="form-group">
            <label class="control-label col-lg-3">No. Rekening </label>
            <div class="col-lg-9">
              <input type="text" id="no_rekening" name="no_rekening" placeholder="No. Rekening" class="form-control" required
                     oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')"
                     oninput="setCustomValidity('')">
            </div>
          </div> 
          <div class="form-group">
            <label class="control-label col-lg-3">Jenis Donatur </label>
            <div class="col-lg-9">
              <select style="width:397px" name="jenis_donatur" data-placeholder="Pilih Jenis Donatur ..." 
                      class           ="form-control selectpicker"
                      data-style      ="btn-default">
                      <option value="">Pilih Jenis Donatur</option>
                  <?php
                      $donatur = array("","Tetap","Tidak Tetap","Kencleng","Perusahaan");
                      for($i = 1;$i <5;$i++)
                          print("<option value=\"$donatur[$i]\">$donatur[$i]</option>");
                  ?>                   
              </select>
            </div>
          </div> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">
          <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
        <button type="submit" class="btn-success btn">
          <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
      </div>
      </form>
    </div>
  </div>
</div>