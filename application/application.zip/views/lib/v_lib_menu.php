<?php 
    $check      = $this->m_users->GetAccessUsers($this->session->userdata('username'));
    $admin      = array('1','39');
    $keuangan   = array('1','39','40');
    $sekretaris = array('1','39','42');
    $editor     = array('1','39','41');
    $santri      = array('43');
    ?>
<!-- START SIDEBAR -->
<div class="sidebar sidebar-colorful clearfix">

<ul class="sidebar-panel nav">
  <li class="sidetitle">MENU</li>
  <li><a href="<?php echo base_url();?>index.php/c_home"><span class="icon color1"><i class="fa fa-home"></i></span>Dashboard<!--<span class="label label-default">2</span>--></a></li>

<?php if(in_array($check->id_group, $admin)){ ?>
  <li><a href="#"><span class="icon color2"><i class="fa fa-wrench fa-fw"></i></span>Settings<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/settings/c_group_user"><i class="fa fa-caret-right"></i>&nbsp;Group Users</a></li>
      <li><a href="<?php echo base_url();?>index.php/settings/c_user"><i class="fa fa-caret-right"></i>&nbsp;User</a></li>
    </ul>
  </li>
</ul>

<ul class="sidebar-panel nav">
  <li class="sidetitle">PENGATURAN WEBSITE </li> 
<?php } ?>
<?php if(in_array($check->id_group, $editor)){ ?> 
  <li><a href="#"><span class="icon color5"><i class="fa fa-image"></i></span>Atur Galeri<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/website/c_album"><i class="fa fa-caret-right"></i>&nbsp;Album</a></li>
      <li><a href="<?php echo base_url();?>index.php/website/c_galeri"><i class="fa fa-caret-right"></i>&nbsp;Galeri</a></li>
    </ul>
  </li>
  <li><a href="#"><span class="icon color3"><i class="fa fa-file-video-o"></i></span>Atur Video<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/website/c_kategori_video"><i class="fa fa-caret-right"></i>&nbsp;Kategori Video</a></li>
      <li><a href="<?php echo base_url();?>index.php/website/c_video"><i class="fa fa-caret-right"></i>&nbsp;Video</a></li>
    </ul>
  </li>
  <li><a href="#"><span class="icon color4"><i class="fa fa-book"></i></span>Atur Artikel<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/website/c_kategori_artikel"><i class="fa fa-caret-right"></i>&nbsp;Kategori Artikel</a></li>
      <li><a href="<?php echo base_url();?>index.php/website/c_artikel"><i class="fa fa-caret-right"></i>&nbsp;Artikel</a></li>
      <li><a href="<?php echo base_url();?>index.php/website/c_komentar"><i class="fa fa-caret-right"></i>&nbsp;Komentar</a></li>
    </ul>
  </li>
<li><a href="<?php echo base_url();?>index.php/website/c_konten"><span class="icon color9"><i class="fa fa-book"></i></span>Konten<!--<span class="label label-default">2</span>--></a></li>
<li><a href="<?php echo base_url();?>index.php/website/c_pesan"><span class="icon color7"><i class="fa fa-envelope"></i></span>Pesan<!--<span class="label label-default">2</span>--></a></li>
<?php } ?>

<?php if(in_array($check->id_group, $admin)){ ?>
</ul>
<ul class="sidebar-panel nav">
  <li class="sidetitle">DATA FUNDRAISING</li>
<?php } ?>


<?php if(in_array($check->id_group, $keuangan)){ ?>
    <li><a href="#"><span class="icon color2"><i class="fa fa-suitcase fa-fw"></i></span>Fundraising<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/fundraising/c_fundraising"><i class="fa fa-caret-right"></i>&nbsp;Fundraising</a></li>
      <li><a href="<?php echo base_url();?>index.php/fundraising/c_kebutuhan"><i class="fa fa-caret-right"></i>&nbsp;Data Kebutuhan</a></li>
      <li><a href="<?php echo base_url();?>index.php/fundraising/c_realisasi"><i class="fa fa-caret-right"></i>&nbsp;Data Realisasi</a></li>
      <li><a href="<?php echo base_url();?>index.php/fundraising/c_pemasukan"><i class="fa fa-caret-right"></i>&nbsp;Data Pemasukan</a></li>
    </ul>
    <li><a href="<?php echo base_url();?>index.php/fundraising/c_donatur"><span class="icon color1"><i class="fa fa-male"></i></span>Donatur<!--<span class="label label-default">2</span>--></a></li>
  </li>  
<?php } ?>

<?php if(in_array($check->id_group, $admin)){ ?>
</ul>
<ul class="sidebar-panel nav">
  <li class="sidetitle">DATA MUQ</li>
<?php } ?>

<?php if(in_array($check->id_group, $sekretaris)){ ?>
  <li><a href="#"><span class="icon color7"><i class="fa fa-tasks fa-fw"></i></span>Data Master<span class="caret"></span></a>
    <ul>
      <li><a href="<?php echo base_url();?>index.php/master/c_ustad"><i class="fa fa-caret-right"></i>&nbsp;Data Ustadz</a></li>
      <li><a href="<?php echo base_url();?>index.php/master/c_asrama"><i class="fa fa-caret-right"></i>&nbsp;Data Asrama</a></li>
      <li><a href="<?php echo base_url();?>index.php/master/c_jenis_santri"><i class="fa fa-caret-right"></i>&nbsp;Data Jenis Santri</a></li>
      <li><a href="<?php echo base_url();?>index.php/master/c_matpel"><i class="fa fa-caret-right"></i>&nbsp;Data Mata Pelajaran</a></li>
      <li><a href="<?php echo base_url();?>index.php/master/c_periode_ajaran"><i class="fa fa-caret-right"></i>&nbsp;Data Periode Ajaran</a></li>
      <li><a href="<?php echo base_url();?>index.php/master/c_rentang_daftar"><i class="fa fa-caret-right"></i>&nbsp;Rentang Daftar</a></li>
    </ul>
  </li> 
    <li><a href="<?php echo base_url();?>index.php/muq/c_periode_pendaftaran"><span class="icon color7"><i class="fa fa-calendar"></i></span>Atur Periode Pendaftaran</a></li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_data_santri"><span class="icon color4"><i class="fa fa-group"></i></span>Data Santri</a></li>
    <li><a href="#"><span class="icon color5"><i class="fa fa-list"></i></span>Data Pendaftaran Santri<span class="caret"></span></a>
      <ul>
        <li><a href="<?php echo base_url();?>index.php/muq/c_pendaftaran_santri"><i class="fa fa-caret-right"></i>&nbsp;Data Pendaftar</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_kelengkapan_santri"><i class="fa fa-caret-right"></i>&nbsp;Upload Kelengkapan</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_riwayat_santri"><i class="fa fa-caret-right"></i>&nbsp;Riwayat Hidup</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_prestasi_santri"><i class="fa fa-caret-right"></i>&nbsp;Prestasi Santri</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_pengalaman_santri"><i class="fa fa-caret-right"></i>&nbsp;Pengalaman Organisasi</a></li>
      </ul>
    </li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_wawancara"><span class="icon color3"><i class="fa fa-microphone"></i></span>Wawancara</a></li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_mutabaah_santri"><span class="icon color4"><i class="fa fa-database"></i></span>Mutabaah Santri</a></li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_pengaturan_ujian"><span class="icon color10"><i class="fa fa-gear"></i></span>Pengaturan Ujian</a></li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_nilai_ujian"><span class="icon color11"><i class="fa fa-fax"></i></span>Nilai Ujian Santri</a></li>
    <li><a href="#"><span class="icon color4"><i class="fa fa-bar-chart"></i></span>Grafik Santri<span class="caret"></span></a>
      <ul>
        <li><a href="<?php echo base_url();?>index.php/muq/c_grafik_hafalan"><i class="fa fa-caret-right"></i>&nbsp;Grafik Hafalan</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_grafik_murajaah"><i class="fa fa-caret-right"></i>&nbsp;Grafik Murajaah</a></li>
        <li><a href="<?php echo base_url();?>index.php/muq/c_grafik_tilawah"><i class="fa fa-caret-right"></i>&nbsp;Grafik Tilawah</a></li>
      </ul>
    </li>
    <li><a href="<?php echo base_url();?>index.php/muq/c_laporan_santri"><span class="icon color9"><i class="fa fa-book"></i></span>Laporan Santri<!--<span class="label label-default">2</span>--></a></li>

  </li> 
<?php } ?>

<?php if(in_array($check->id_group, $santri)){ ?>
    <li><a href="#"><span class="icon color5"><i class="fa fa-list"></i></span>Data Santri<span class="caret"></span></a>
      <ul>
        <li><a href="<?php echo base_url();?>index.php/santri/c_user_data/view"><i class="fa fa-caret-right"></i>&nbsp;Lihat Data</a></li>
        <li><a href="<?php echo base_url();?>index.php/santri/c_user_kelengkapan"><i class="fa fa-caret-right"></i>&nbsp;Upload Kelengkapan</a></li>
        <li><a href="<?php echo base_url();?>index.php/santri/c_user_riwayat"><i class="fa fa-caret-right"></i>&nbsp;Riwayat Hidup</a></li>
        <li><a href="<?php echo base_url();?>index.php/santri/c_user_prestasi"><i class="fa fa-caret-right"></i>&nbsp;Prestasi Santri</a></li>
        <li><a href="<?php echo base_url();?>index.php/santri/c_user_organisasi"><i class="fa fa-caret-right"></i>&nbsp;Pengalaman Organisasi</a></li>
      </ul>
    </li>
    <li><a href="<?php echo base_url();?>index.php/santri/c_user_setting"><span class="icon color9"><i class="fa fa-gear"></i></span>Pengaturan Akun</a></li>
<?php } ?>

<?php if(in_array($check->id_group, $admin)){ ?>
</ul>
<?php } ?>
</ul>
<ul class="sidebar-panel nav">
    <li><a href="<?php echo base_url();?>index.php/c_home/logout"><span class="icon color6"><i class="fa fa-power-off"></i></span>Logout<!--<span class="label label-default">2</span>--></a></li>
</ul>
</div>

<!-- END SIDEBAR -->