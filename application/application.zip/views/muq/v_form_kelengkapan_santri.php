<?php
if ($option=='tambah'){
  $link_form='tambah_data';
}else
  $link_form='edit_data';

?>
  <div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $sub_judul ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo  $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>-->
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>/<?php echo $nama_santri ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<div class="container-default">
  <div class="row">

    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $kode; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div>
          <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/muq/c_kelengkapan_santri/simpan_data"
                 enctype="multipart/form-data">          
           <input type="hidden" name="id" value="<?php echo $id; ?>">        
           <input type="hidden" name="nama" value="<?php echo $nama_santri; ?>">        
           <input type="hidden" name="kode" value="<?php echo $kode; ?>">        
           <table id="example1" class="table display">
              <thead> 
                <tr>                       
                  <th>Nama File</th>
                  <th>Gambar</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tr>
                  <th>Foto Ktp</th>
                  <th><?php if(empty($filefotoktp)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/ktp/<?php echo $filefotoktp ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                  </th>
                  <th><input type="file" name="filefotoktp" class="form-control">
                      <?php if(!empty($filefotoktp)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Ijazah </th>
                  <th><?php if(empty($filefotoijazah)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/ijazah/<?php echo $filefotoijazah ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotoijazah" class="form-control">
                      <?php if(!empty($filefotoijazah)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Surat keterangan Sehat </th>
                  <th><?php if(empty($filefotosehat)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/ket_sehat/<?php echo $filefotosehat ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotosehat" class="form-control">
                      <?php if(!empty($filefotosehat)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Surat Tidak menggunakan obat terlarang </th>
                  <th><?php if(empty($filefotoobat)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/ket_obat/<?php echo $filefotoobat ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotoobat" class="form-control">
                      <?php if(!empty($filefotoobat)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Pas Foto berwarna ukuran 3x4 </th>
                  <th><?php if(empty($filefotoberwarna)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/pasfoto/<?php echo $filefotoberwarna ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotoberwarna" class="form-control">
                      <?php if(!empty($filefotoberwarna)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Surat ijin orang tua </th>
                  <th><?php if(empty($filefotosuratijin)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/ijinortu/<?php echo $filefotosuratijin ?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotosuratijin" class="form-control">
                      <?php if(!empty($filefotosuratijin)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Akta Lahir <?php echo $filefotoaktalahir ?></th>
                  <th><?php if(empty($filefotoaktalahir)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/aktalahir/<?php echo $filefotoaktalahir;?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotoaktalahir" class="form-control">
                      <?php if(!empty($filefotoaktalahir)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto kartu Keluarga </th>
                  <th><?php if(empty($filefotokk)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/kk/<?php echo $filefotokk;?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotokk" class="form-control">
                      <?php if(!empty($filefotokk)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
              <tr>
                  <th>Foto Surat Pindahan (Opsi) </th>
                  <th><?php if(empty($filefotopindahan)) echo '<span class="right label label-danger">Belum Diupload</span>'; else{ ?>
                      <img src="<?php echo base_url();?>assets/images/kelengkapan/surat_pindahan/<?php echo $filefotopindahan;?>" 
                       height="152" width="152">
                       <?php 
                        }
                        ?>
                    
                  </th>
                  <th><input type="file" name="filefotopindahan" class="form-control">
                      <?php if(!empty($filefotopindahan)) echo'<font color=red>*Kosongkan jika file tidak diubah !</font>' ?></th>
              </tr>
           </table>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form> 
        </div>
      </div>
    </div>
  </div>    



