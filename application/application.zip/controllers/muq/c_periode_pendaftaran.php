<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_periode_pendaftaran extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//hak akses
		/*=========================
		  1 : super admin
		  39  : admin
		  40  : keuangan
		  41  : editor
		  42  : sekretaris
		==========================*/
		$this->m_squrity->check_access(array('1','42','39'));
	}

	public function index()
	{		
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_periode_pendaftaran');
		$getquerytable           = $this->m_periode_pendaftaran->GetPeriode();
		$isi['content']          = 'muq/v_periode_pendaftaran';
		$isi['base_link']        = 'muq/c_periode_pendaftaran';
		$isi['judul']            = 'Periode Pendaftaran';
		$isi['sub_judul']        = 'Pengaturan Periode Pendaftaran Santri';
		$isi['data']             = $getquerytable;		
		$isi['getTahun']         = $this->m_periode_pendaftaran->GetTahun()->result();			
		$isi['getRentang']       = $this->m_periode_pendaftaran->GetRentang()->result();			
		$isi['id_tahun_ajaran']  = '';
		$isi['id_rentang_daftar']= '';
		
		$this->load->view('v_home',$isi);
	}

	
	public function tambah_data()
    {
	    $this->m_squrity->getsqurity();

	    $id_rentang_daftar  		= $this->input->post('id_rentang_daftar');
	    $id_tahun_ajaran    		= $this->input->post('id_tahun_ajaran');

	    $this->load->model('muq/m_periode_pendaftaran');

		if(!$id_rentang_daftar=="" || !$id_rentang_daftar==""){
			$insert['id_rentang_daftar']= $id_rentang_daftar;
			$insert['id_tahun_ajaran']  = $id_tahun_ajaran;
		    $this->m_periode_pendaftaran->GetInsert($insert);
		    $this->session->set_flashdata('info','tambah');
		    redirect('muq/c_periode_pendaftaran');
		}
		else{
			$this->session->set_flashdata('info','error');
		    redirect('muq/c_periode_pendaftaran');
		}
  	}

	public function hapus_data()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('muq/m_periode_pendaftaran');

		$key = $this->uri->segment(4);
		$this->db->where('id',$key);
		$query = $this->db->get('t_periode_pendaftaran');
		if($query->num_rows()>0){
			$this->m_periode_pendaftaran->GetDelete($key);
			$this->session->set_flashdata('info','hapus');
			redirect('muq/c_periode_pendaftaran');
		}		
		
	}

	public function stat_data()
	{
		$this->m_squrity->getsqurity();
		$key 				= $this->uri->segment(5);
		$data 			 	= $this->uri->segment(4);

		$this->load->model('muq/m_periode_pendaftaran');
		$this->m_periode_pendaftaran->GetReset($key,$data);
		$this->session->set_flashdata('info','edit');
		redirect('muq/c_periode_pendaftaran');		
	}

}

/* End of file c_periode_pendaftaran.php */
/* Location: ./application/controllers/muq/c_periode_pendaftaran.php */