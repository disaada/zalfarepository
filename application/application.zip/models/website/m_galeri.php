<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_galeri extends CI_Model {

	public function GetGaleri(){
        $query=$this->db->query("SELECT t_album.`judul_album`, t_galeri.`gambar_galeri`,t_galeri.`id`,
                                        t_galeri.`id_album`,t_galeri.`judul_galeri`,t_galeri.`keterangan`,
                                        t_galeri.`tampilkan`
                                 FROM t_galeri INNER JOIN t_album
                                 ON t_galeri.`id_album`=t_album.`id`
                                ");
        return $query;
    }

    public function GetDataAlbum(){
        $query=$this->db->query("SELECT id,judul_album FROM t_album ORDER BY id");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_galeri');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_galeri',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_galeri',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_galeri');
    }

    public function GetReset($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_galeri',$data);
    }
}
