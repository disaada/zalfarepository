<!DOCTYPE html>
<html>
<head>
  <title>Data Pendaftaran - <?php echo $nama_santri; ?></title>
  <style type="text/css">
    #outtable{
      padding: 20px;
      border:1px solid #e3e3e3;
      width:600px;
      border-radius: 5px;
    }
 
    .short{
      width: 50px;
    }
 
    .normal{
      width: 150px;
    }
 
    table{
      border-collapse: collapse;
      font-family: arial;
    }
 
    thead th{
      text-align: left;
      padding: 10px;
    }
 
    tbody td{
      padding: 10px;
    }
 
    tbody tr:nth-child(even){
      background: transparent;
    }
  table.table{
     border:2px solid;
     margin:0;
     padding:0;
  }
  table.borderless td,table.borderless th, table.borderless tr{
     border: none !important;
  }
  hr{
    margin:0;
     padding:0;
  }
  </style>
</head>
<body>
	<div id="outtable">
    <div style="text-align: center;font-weight: bold;"><h2>Detail Data Pendaftaran Santri</h2></div>
	  <table class="borderless trhead" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
              <tr>
                <td colspan="3">
                  <b>DATA DIRI</b>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="40%">Nama Lengkap</td>
                <td width="2%">:</td>
                <td><?php echo $nama_santri; ?></td>
              </tr>
              <tr>
                <td width="40%">Tempat dan Tanggal Lahir</td>
                <td width="2%">:</td>
                <td><?php echo $tempat_lahir; ?>, <?php echo tgl_indo($tgl_lahir); ?></td>
              </tr>
              <tr>
                <td width="40%">Jenis Kelamin</td>
                <td width="2%">:</td>
                <td><?php echo $jk; ?></td>
              </tr>
              <tr>
                <td width="40%">No Telepon</td>
                <td width="2%">:</td>
                <td><?php echo $notelp; ?></td>
              </tr>
              <tr>
                <td width="40%">Email</td>
                <td width="2%">:</td>
                <td><?php echo $email; ?></td>
              </tr>
              <tr>
                <td width="40%">Alamat Lengkap</td>
                <td width="2%">:</td>
                <td><?php echo $alamat_santri; ?></td>
              </tr>
              <tr>
                <td width="40%">Pendidikan Terakhir</td>
                <td width="2%">:</td>
                <td><?php echo $pendidikan_terakhir; ?></td>
              </tr>
              <tr>
                <td colspan="3">
                  <b>DATA KELUARGA</b>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="40%">Nama Ayah</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ayah; ?></td>
              </tr>
              <tr>
                <td width="40%">Nama Ibu</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ibu; ?></td>
              </tr>
              <tr>
                <td width="40%">Nama Wali</td>
                <td width="2%">:</td>
                <td><?php echo $nama_ortu_wali; ?></td>
              </tr>
              <tr>
                <td width="40%">No Telepon Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $notelp_ortu; ?></td>
              </tr>
              <tr>
                <td width="40%">Alamat Lengkap Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $alamat_ortu; ?></td>
              </tr>
              <tr>
                <td width="40%">Pendidikan Terakhir</td>
                <td width="2%">:</td>
                <td><?php echo $pendidikan_terakhir_ortu; ?></td>
              </tr>
              <tr>
                <td colspan="3">
                  <b>DATA TAMBAHAN</b>
                  <hr>
                </td>
              </tr>
              <tr>
                <td width="40%">Golongan Darah</td>
                <td width="2%">:</td>
                <td><?php echo $goldar; ?></td>
              </tr>
              <tr>
                <td width="40%">Anak Ke</td>
                <td width="2%">:</td>
                <td><?php echo $anakke; ?> dari <?php echo $saudara; ?> saudara</td>
              </tr>
              <tr>
                <td width="40%">Pekerjaan Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $pekerjaan_ortu; ?></td>
              </tr>
              <tr>
                <td width="40%">Penghasilan Orang Tua</td>
                <td width="2%">:</td>
                <td><?php echo $penghasilanortuperbulan; ?> Juta</td>
              </tr>
            </tbody>
          </table>
	 </div>
</body>
</html>