 <?php
    $nama_lengkap   = $this->session->userdata('nama_user');
    $level          = $this->session->userdata('level');
  ?>

 <!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
  <meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />
  <title>SIMUQ (Sistem Informasi MUQ) </title>

  <!-- ========== Css Files ========== -->
  
  <link href="<?php echo base_url();?>assets/css/root.css" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/star-rating.css" media="all" rel="stylesheet" type="text/css"/>
  </head>
  <script type="text/javascript">
        //set timezone
    <?php date_default_timezone_set('Asia/Jakarta'); ?>
    //buat object date berdasarkan waktu di server
    var serverTime = new Date(<?php print date('Y, m, d, H, i, s, 0'); ?>);
    //buat object date berdasarkan waktu di client
    var clientTime = new Date();
    //hitung selisih
    var Diff = serverTime.getTime() - clientTime.getTime();    
    //fungsi displayTime yang dipanggil di bodyOnLoad dieksekusi tiap 1000ms = 1detik
    function displayServerTime(){
        //buat object date berdasarkan waktu di client
        var clientTime = new Date();
        //buat object date dengan menghitung selisih waktu client dan server
        var time = new Date(clientTime.getTime() + Diff);
        //ambil nilai jam
        var sh = time.getHours().toString();
        //ambil nilai menit
        var sm = time.getMinutes().toString();
        //ambil nilai detik
        var ss = time.getSeconds().toString();
        //tampilkan jam:menit:detik dengan menambahkan angka 0 jika angkanya cuma satu digit (0-9)
        document.getElementById("clock").innerHTML = (sh.length==1?"0"+sh:sh) + ":" + (sm.length==1?"0"+sm:sm) + ":" + (ss.length==1?"0"+ss:ss);
    }
    </script>
  <body onload="setInterval('displayServerTime()', 1000);">
  <!-- Start Page Loading -->
  <div class="loading"><img src="<?php echo base_url();?>assets/img/loading.gif" alt="loading-img"></div>
  <!-- End Page Loading -->
 <!-- START TOP -->
  <div id="top" class="clearfix">

    <!-- Start App Logo -->
    <div class="applogo">
      <a href="<?php echo base_url();?>index.php/c_home" class="logo"><?php echo strtoupper($level); ?></a>
    </div>
    <!-- End App Logo -->

    <!-- Start Sidebar Show Hide Button -->
    <a href="#" class="sidebar-open-button"><i class="fa fa-windows"></i></a>
    <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-windows"></i></a>
     <!--End Sidebar Show Hide Button -->

    <!-- Start Sidepanel Show-Hide Button 
    <a href="#sidepanel" class="sidepanel-open-button"><i class="fa fa-outdent"></i></a>
     End Sidepanel Show-Hide Button -->

    <!-- Start Top Right -->
    
    <ul class="top-right">
    <li class="dropdown link">
      <a href="#" data-toggle="dropdown" class="dropdown-toggle profilebox">
        <!--<img src="<?php echo base_url();?>assets/img/profileimg.png" alt="img">-->
        <i class="fa fa-user"></i>&nbsp;&nbsp;<b><?php echo $nama_lengkap; ?></b><span class="caret"></span></a>
        <ul class="dropdown-menu dropdown-menu-list dropdown-menu-right">
          <!--<li role="presentation" class="dropdown-header">Profile</li>
          <li><a href="#"><i class="fa falist fa-inbox"></i>Inbox<span class="badge label-danger">4</span></a></li>-->
          <li><a href="#"><i class="fa falist fa-file-o"></i>Profile</a></li>
          <!--<li><a href="#"><i class="fa falist fa-wrench"></i>Settings</a></li>-->
          <li class="divider"></li>
          <!--<li><a href="#"><i class="fa falist fa-lock"></i> Lockscreen</a></li>-->
          <li><a href="<?php echo base_url();?>index.php/c_home/logout"><i class="fa falist fa-power-off"></i> Logout</a></li>
        </ul>
    </li>

    </ul>
    <!-- End Top Right -->

  </div>
  <!-- END TOP -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 
