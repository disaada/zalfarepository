<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_prestasi_santri extends CI_Model {

    public function GetDataSantri(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri");
        return $query;
    }

    public function GetDataPrestasi(){
        $query=$this->db->query("SELECT t_santri_prestasi.`id`,
                                        t_santri_prestasi.`id_pendaftaran`, 
                                        t_santri_prestasi.`prestasi`,
                                        t_santri_prestasi.`tahun`,
                                        t_santri_prestasi.`instansi`,
                                        t_pendaftaran_santri.`nama_santri`
                                 FROM t_santri_prestasi INNER JOIN t_pendaftaran_santri 
                                 ON t_santri_prestasi.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                 WHERE t_pendaftaran_santri.`nama_santri` <> 'Agen' 
                                ");
        return $query;
    }

    public function CountPrestasi($key){
        $this->db->where('id_pendaftaran',$key);
        $hasil = $this->db->get('t_santri_prestasi');
        return $hasil;
    }

    public function GetData($key=NULL){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`,t_pendaftaran_santri.`nama_santri`
                                 FROM t_pendaftaran_santri INNER JOIN t_santri_prestasi 
                                 ON t_pendaftaran_santri.`id`=t_santri_prestasi.`id_pendaftaran`
                                 WHERE t_santri_prestasi.`id_pendaftaran`=".$key);
        return $query;
    }
    
    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_santri_prestasi',$data);
    }

    public function GetInsert($data){
            $this->db->insert('t_santri_prestasi',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_santri_prestasi');
    }

}

/* End of file m_riwayat_santri.php */
/* Location: ./application/models/muq/m_riwayat_santri.php */