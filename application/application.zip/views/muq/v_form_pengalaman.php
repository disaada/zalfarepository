  <div class="page-header">
    <h1 class="title"><i class="fa fa-user"></i>&nbsp;<?php echo $sub_judul ?></h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>index.php/c_home">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>"><?php echo $judul; ?></a></li>
        <li class="active"><?php echo  $sub_judul; ?></li>
      </ol>
    <div class="right">
      <div class="btn-group" role="group" aria-label="...">
        <!--<a href="<?php echo base_url();?>index.php/c_home" class="btn btn-light"><i class="fa fa-home"></i>Dashboard</a>-->
        <a href="<?php echo base_url();?>index.php/<?php echo $back_link ?>" 
           type="button" class="btn btn-light" title="kembali"><i class="fa fa-arrow-left"></i> Kembali</a>        
        <a href="<?php echo base_url();?>index.php/<?php echo $base_link ?>" 
           class="btn btn-light"><i class="fa fa-refresh"></i>Reload</a>
      </div>
    </div>
  </div>
<div class="container-default">
  <div class="row">

<?php
if ($option=='tambah'){
  $link_form='tambah_data';
?>

    <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div><br>

<?php 
    $info = $this->session->flashdata('info');
    if(!empty($info)){
      switch($info) {
        case 'error' :
          echo '<div class="notif" style="display:none" >
                  <div class="kode-alert kode-alert-icon kode-alert-click alert2">
                    <h4><i class="fa fa-check"></i>Terdapat data yang kosong mohon isi semua data</h4>
                  </div> 
                </div>  ';        
        break;
      } 
    }
?>
<div id="pnlpesan" ><p id="isipesan"></p> <p></p></div>

          <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/muq/c_pengalaman_santri/<?php echo $link_form;?>"
                 enctype="multipart/form-data">   
           <input type="hidden" name="id" value="<?php echo $id; ?>">        
           <div class="panel-body">
              <div class="form-group">
                <label for="id_pendaftaran" class="control-label col-lg-2">Nama Santri</label>
                    <div class="col-lg-10">
                      <select name            ="id_pendaftaran" 
                              class           ="form-control selectpicker"
                              data-style      ="btn-light"
                              data-live-search="true">
                        <?php 
                          if(empty($id_pendaftaran)){
                            $nama_santri = '--- Pilih Santri ---'; 
                          }else
                            $nama_santri = $id_pendaftaran; 
                        ?>
                        <option value="<?php echo $id_pendaftaran ?>"><?php echo $nama_santri ?></option>
                        <?php
                            foreach ($getData as $santri) {
                              print("<option value=\"$santri->id\">$santri->nama_santri</option>");
                            }
                        ?>                                  
                      </select>
                    </div>
                </div>
              </div> 
              <div class="form-group">
                <h5 class="text-center">Pengalaman Organisasi</h5>
                <hr>
              </div>
                <div class="row">
                    <div class="container header-list">
                        <div class="col-md-offset-1 col-md-2 col-sm-6 col-xs-2">Organisasi</div>
                        <div class="col-md-2 col-sm-6 col-xs-2 text-left">Jabatan</div>
                        <div class="col-md-2 col-sm-6 col-xs-2 text-left">Tahun Awal</div>
                        <div class="col-md-2 col-sm-6 col-xs-2 text-left">Tahun Akhir</div>
                        <div class="col-md-2 col-sm-6 col-xs-2 text-left">&nbsp;</div>
                    </div>
                </div>
                <ul class="nav nav-pills nav-stacked">
                    <li class="list-file">
                        <div class="row">
                            <span class="col-md-offset-1 col-md-2 col-sm-6 col-xs-2">
                                <input  type="text" name="organisasi"  class="form-control"
                                        placeholder="Nama Organisasi"
                                        id="organisasi"
                                        autofocus  
                                        value="<?php echo $organisasi; ?>"> 
                            </span>

                            <span class="col-md-2 col-sm-6 col-xs-2 text-right">
                                <input  type="text" name="jabatan"  class="form-control"
                                        placeholder="Jabatan"
                                        id="jabatan"
                                        autofocus  
                                        value="<?php echo $jabatan; ?>"> 
                            </span>

                            <span class="col-md-2 col-sm-6 col-xs-2 text-right">
                                <input  type="text" name="tahun_awal"  class="form-control"
                                        placeholder="Tahun Awal"
                                        id="tahun_awal"
                                        autofocus  
                                        value="<?php echo $tahun_awal; ?>">
                            </span>

                            <span class="col-md-2 col-sm-6 col-xs-2 text-right">
                                <input  type="text" name="tahun_akhir"  class="form-control"
                                        placeholder="Tahun Akhir"
                                        id="tahun_akhir"
                                        autofocus  
                                        value="<?php echo $tahun_akhir; ?>">
                            </span>

                            <span class="col-md-2 col-sm-6 col-xs-2 text-right">
                                <button type="button" id="tambahorganisasi" class="btn btn-light pull-right btn-sm" data-dismiss="modal">
                                    <i class="fa fa-plus" title='kembali'></i>&nbsp;Tambahkan</button>
                            </span>
                        </div>
                    </li>
              </ul>
                <table class="table" id="daftar">
                  <thead>
                    <th width="20%">Organisasi</th>
                    <th width="20%">Jabatan</th>
                    <th width="20%">Tahun Awal</th>
                    <th width="20%">Tahun Akhir</th>
                    <th width="20%"></th>
                  </thead>
                  <tbody>
                    <tr id="nodata">
                      <td colspan="5" class="text-center">Belum Ada Data Riwayat Pendidikan</td>
                    </tr>
                  </tbody>
                </table>

          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form> 
        </div>
      </div>
<?php }
else{
  $link_form='edit_data';
 ?>
      
      <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          <?php echo $sub_judul; ?>
          <ul class="panel-tools">
            <li><a class="icon minimise-tool"><i class="fa fa-minus"></i></a></li>
            <li><a class="icon expand-tool"><i class="fa fa-expand"></i></a></li>
            <li><a class="icon closed-tool"><i class="fa fa-times"></i></a></li>
          </ul>
        </div><br>
          <form method="post" class="form-horizontal" 
                 action="<?php echo base_url();?>index.php/muq/c_pengalaman_santri/<?php echo $link_form;?>"
                 enctype="multipart/form-data">          
           <div class="panel-body">
              <div class="form-group">
                  <label for="id_pendaftaran" class="control-label col-lg-2">Nama Santri</label>
                    <div class="col-lg-10">                      
                      <input type="text" class="form-control" readonly value="<?php echo $getData['nama_santri']; ?>">
                    </div>
                </div>
              </div> 
              <div class="form-group">
                <h5 class="text-center">Pengalaman Organisasi</h5>
                <hr>

                <table class="table">
                  <thead>
                    <th width="20%">Organisasi</th>
                    <th width="20%">Jabatan</th>
                    <th width="20%">Tahun Awal</th>
                    <th width="20%">Tahun Akhir</th>
                  </thead>
                  <tbody>

                  <?php foreach ($putData as $key) { ?>
                    <tr>
                      <input type="hidden" name="id[]" value="<?php echo $key->id; ?>">
                      <td>
                        <input  type="text" name="organisasi[]"  class="form-control"
                                placeholder="Nama Organisasi"
                                id="organisasi"
                                autofocus  
                                value="<?php echo $key->organisasi; ?>">
                      </td>

                      <td>
                        <input  type="text" name="jabatan[]"  class="form-control"
                                placeholder="Jabatan"
                                id="jabatan"
                                autofocus  
                                value="<?php echo $key->jabatan; ?>">
                      </td>

                      <td>
                        <input  type="text" name="tahun_awal[]"  class="form-control"
                                placeholder="Tahun Awal"
                                id="tahun_awal"
                                autofocus  
                                value="<?php echo $key->tahun_awal; ?>">
                      </td>

                      <td>
                        <input  type="text" name="tahun_akhir[]"  class="form-control"
                                placeholder="Tahun Akhir"
                                id="tahun_akhir"
                                autofocus  
                                value="<?php echo $key->tahun_akhir; ?>">
                      </td>
                    </tr>

                  <?php } ?>
                  </tbody>
                </table>
                
              </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">
                <i class="fa fa-times-circle" title='kembali'></i>&nbsp;Tutup</button>
              <button type="submit" class="btn-success btn">
                <i class="fa fa-save" title='kembali'></i>&nbsp;Simpan</button>
            </div>
          </form> 
        </div>
      </div>

<?php } ?>
    </div>
  </div>    



