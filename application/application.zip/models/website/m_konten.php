<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_konten extends CI_Model {

	public function GetKonten(){
        $query=$this->db->query("SELECT * FROM t_konten");
        return $query;
    }

    public function GetData($key){
        $this->db->where('id',$key);
        $hasil = $this->db->get('t_konten');
        return $hasil;
    }
    
    public function GetUpdate($key,$data){
    		$this->db->where('id',$key);
    		$this->db->update('t_konten',$data);
    }

    public function GetInsert($data){
    		$this->db->insert('t_konten',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_konten');
    }
}
