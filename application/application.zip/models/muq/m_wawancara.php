<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_wawancara extends CI_Model {

	public function GetKelengkapan(){
        $query=$this->db->query("SELECT t_pendaftaran_santri.`id`, 
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri");
        return $query;
    }

    public function CekPeriode(){
    	$this->db->where('status','terpilih');
    	$query = $this->db->get('t_periode_pendaftaran');
    	return $query;
    }

    public function GetWawancara($key=NULL){
        $query=$this->db->query("SELECT t_wawancara.*, t_pendaftaran_santri.`id` AS pendaftaran_id,
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri 
                                LEFT JOIN t_wawancara ON t_wawancara.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                WHERE t_pendaftaran_santri.`id`=".$key);
        return $query;
    }

    public function GetWawancaraSort(){
        $query=$this->db->query("SELECT t_wawancara.*, t_pendaftaran_santri.`id` AS pendaftaran_id,
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_wawancara ON t_wawancara.`id_pendaftaran`=t_pendaftaran_santri.`id` 
                                ORDER BY t_wawancara.`komulatif` DESC");
        return $query;
    }

    public function GetWawancaraSortID($key){
        $query=$this->db->query("SELECT t_wawancara.*, t_pendaftaran_santri.`id` AS pendaftaran_id,
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri 
                                INNER JOIN t_wawancara ON t_wawancara.`id_pendaftaran`=t_pendaftaran_santri.`id`
                                WHERE t_pendaftaran_santri.`id_periode`=$key 
                                ORDER BY t_wawancara.`komulatif` DESC");
        return $query;
    }

    public function DataWawancara(){
    	$query=$this->db->query("SELECT t_wawancara.*, t_pendaftaran_santri.`id` AS pendaftaran_id,
                                        t_pendaftaran_santri.`nama_santri`,
                                        t_pendaftaran_santri.`alamat_pendaftaran_santri`
                                FROM t_pendaftaran_santri 
                                LEFT JOIN t_wawancara ON t_wawancara.`id_pendaftaran`=t_pendaftaran_santri.`id`");
        return $query;
    }

    public function cekKelengkapan($key){
        $this->db->where('id_pendaftaran',$key);
        $query = $this->db->get('t_kelengkapan_santri');      
        $total = $query->num_rows();
        return $total;
    }

    public function periode($key=NULL){
        if($key)
            $this->db->where('id', $key);
        $query = $this->db->query('SELECT   t_periode_pendaftaran.`id`, t_rentang_daftar.`tgl_dibuka`, 
                                            t_rentang_daftar.`tgl_ditutup`, t_periode_pendaftaran.`id_rentang_daftar`
                                   FROM t_periode_pendaftaran
                                   INNER JOIN t_rentang_daftar 
                                   ON t_rentang_daftar.`id`=t_periode_pendaftaran.`id_rentang_daftar` 
                                   ORDER BY t_periode_pendaftaran.`id` ASC');
        return $query;
    }

    public function GetPeriode($periode){
    	$query=$this->db->query("SELECT t_pendaftaran_santri.`id`, t_pendaftaran_santri.`nama_santri`,
    									t_rentang_daftar.`tgl_dibuka`, t_rentang_daftar.`tgl_ditutup`, 
    									t_pendaftaran_santri.`id_periode`, t_periode_pendaftaran.`id_rentang_daftar`, 
                                        t_pendaftaran_santri.`status`
								FROM t_periode_pendaftaran
								INNER JOIN t_pendaftaran_santri ON t_pendaftaran_santri.`id_periode`=t_periode_pendaftaran.`id`
					            INNER JOIN t_rentang_daftar ON t_rentang_daftar.`id`=t_periode_pendaftaran.`id_rentang_daftar`
					            WHERE t_pendaftaran_santri.`id_periode`=".$periode);
        return $query;
    }

    public function TotalSantri(){
    	$this->db->where('status','1');
    	$total = $this->db->get('t_pendaftaran_santri');
    	return $total;
    }

    public function TotalWawancara(){
    	$total = $this->db->get('t_wawancara');
    	return $total;
    }

    public function TotalUpload($key){
        $query=$this->db->query("SELECT * FROM t_kelengkapan_santri WHERE id_pendaftaran=$key");
        $total = 0;
        foreach ($query->result() as $row){
            if(!empty($row->filefotoktp))$total++;
            if(!empty($row->filefotoijazah))$total++;        
            if(!empty($row->filefotosehat))$total++;        
            if(!empty($row->filefotoobat))$total++;        
            if(!empty($row->filefotoberwarna))$total++;        
            if(!empty($row->filefotosuratijin))$total++;        
            if(!empty($row->filefotoaktalahir))$total++;        
            if(!empty($row->filefotokk))$total++;        
            if(!empty($row->filefotopindahan))$total++;                
        }
        return $total;
    }

    public function tWawancara($key=NULL){
        $query=$this->db->query("SELECT * FROM t_wawancara WHERE id_pendaftaran=$key");
        $total = 0;
        foreach ($query->result() as $row){
            if(!empty($row->motivasi))$total++;
            if(!empty($row->komitmen))$total++;        
            if(!empty($row->akhlak))$total++;              
        }
        return $total;
    }

    public function GetInsert($data=NULL){
    	$this->db->insert('t_wawancara',$data);
    }

    public function GetUpdate($key,$data){
            $this->db->where('id_pendaftaran',$key);
            $this->db->update('t_wawancara',$data);
    }

    public function GetReset($key,$data){
        $this->db->where('id_pendaftaran',$key);
        $this->db->update('t_wawancara',$data);
    }

    public function ResetSantri($key,$data){
        $this->db->where('id',$key);
        $this->db->update('t_pendaftaran_santri',$data);
    }

    public function DeleteSantri($key){
        $this->db->where('id_pendaftaran',$key);
        $this->db->delete('t_santri');
    }

}

/* End of file m_wawancara.php */
/* Location: ./application/models/muq/m_wawancara.php */