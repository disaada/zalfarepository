<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_pemasukan extends CI_Model {

	public function GetPemasukan(){
        $query=$this->db->query("SELECT * FROM t_pemasukan");
        return $query;
    }

    public function GetDonatur(){
        $query=$this->db->query("SELECT id,nama_donatur FROM t_donatur");
        return $query;
    }

    public function GetPemasukanDetail($key){
        $query=$this->db->query("SELECT t_pemasukan.`id`,t_pemasukan.`id_fundraising`, t_donatur.`nama_donatur`,
                                        t_pemasukan.`nominal`, t_pemasukan.`tgl_pemasukan`, t_pemasukan.`keterangan`,
                                        t_pemasukan.`id_donatur`
                                 FROM t_pemasukan JOIN t_donatur 
                                 ON(t_pemasukan.`id_donatur`=t_donatur.`id`)
                                 WHERE t_pemasukan.`id_fundraising`=$key");
        return $query;
    }

    public function GetidFundraising(){
        $query=$this->db->query("SELECT id FROM t_fundraising
                                 WHERE periode = DATE_FORMAT(NOW(),'%m-%Y')");
        return $query;
    }

    public function GettotPemasukan($key){
        $query=$this->db->query("SELECT SUM(nominal) AS total 
                                 FROM t_pemasukan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetPeriode($key){
        $query=$this->db->query("SELECT periode FROM t_fundraising where id=$key");
        foreach ($query->result() as $row){
            $periode = $row->periode;        
        }
        return $periode;
    }

    public function GetTotalPemasukan($key){
        $query=$this->db->query("SELECT COUNT(*) AS total FROM t_pemasukan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function GetBiayaPemasukan($key){
        $query=$this->db->query("SELECT SUM(nominal) AS total FROM t_pemasukan WHERE id_fundraising=$key");
        foreach ($query->result() as $row){
            $total = $row->total;        
        }
        return $total;
    }

    public function NamaBulan($periode){
        $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
     
        $bulan = substr($periode, 0, 2);
     
        $result = $BulanIndo[(int)$bulan-1];     
        return $result;
    }

    public function GetData($tanggal){
        $this->db->where('periode',$tanggal);
        $hasil = $this->db->get('t_fundraising');
        return $hasil;
    }

    public function GetInsert($data){
            $this->db->insert('t_pemasukan',$data);
    }

    public function GetUpdate($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_pemasukan',$data);
    }

    public function GetDelete($key){
        $this->db->where('id',$key);
        $this->db->delete('t_pemasukan');
    }

    public function GetUpdatePem($key,$data){
            $this->db->where('id',$key);
            $this->db->update('t_fundraising',$data);
    }
}
