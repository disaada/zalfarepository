<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_home extends CI_Controller {

	public function index()
	{
		$this->m_squrity->getsqurity();
		$this->load->model('m_home');
		$this->load->model('settings/m_users');
		$this->load->model('santri/m_user_data');
		$GetTotalGuser				= $this->m_home->GetJumlahGuser();
		$GetTotalUser				= $this->m_home->GetJumlahUser();
		$Gethari					= $this->m_home->GetHari();
		$isi['content'] 			= 'v_dashboard';
		$isi['base_link'] 			= 'c_home';
		$isi['judul'] 				= 'Dashboard';
		$isi['sub_judul'] 			= '';
		$isi['GetJumlahGuser']		= $GetTotalGuser;
		$isi['GetJumlahUser']		= $GetTotalUser;		
		$isi['hari']				= $Gethari;
		$isi['GetJumlahalbum']		= $this->m_home->GetJumlahAlbum();
		$isi['GetJumlahgaleri']		= $this->m_home->GetJumlahGaleri();
		$isi['GetJumlahkvideo']		= $this->m_home->GetJumlahKvideo();
		$isi['GetJumlahvideo']		= $this->m_home->GetJumlahVideo();
		$isi['GetJumlahkartikel']	= $this->m_home->GetJumlahKartikel();
		$isi['GetJumlahartikel']	= $this->m_home->GetJumlahArtikel();
		$isi['GetJumlahkomentar']	= $this->m_home->GetJumlahKomentar();
		$isi['GetJumlahpesan']		= $this->m_home->GetJumlahPesan();
		$this->load->view('v_home',$isi);
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('c_login');
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
